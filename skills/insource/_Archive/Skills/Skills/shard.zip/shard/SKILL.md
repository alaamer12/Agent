---
name: shard
description: Reorganize documentation into a folder of single-concern files, so each concern lives in its own file and can be loaded on its own. The input can be one file, a handful of files, or the full documentation of an entire system (a docs folder, a wiki export, a pile of specs, READMEs, runbooks, contracts, notes), which gets processed file by file. Invoke as "/shard this [file or folder]". Use this whenever the user says shard, split this doc, break these docs into pieces by concern, reorganize our documentation, make our docs agent-friendly or loadable in parts, or hands over documentation and wants it restructured, even if they never say "shard". Also use it when a sharded folder already exists and the user asks to update it, record a change, or keep a history of what changed and why.
---

# Shard

Turn documentation into a folder where every file holds one concern. The folder is the unit you ship, review, or mount; each file inside it is a concern. A reader (human or agent) then opens only the file that answers the question in front of it, instead of loading everything.

The input is whatever documentation the user hands over: one file, several related files, or a whole system's docs. Shard works on any kind of document, in any domain and any language. Folder names, file names, and file contents are all free-form. Examples here are illustrations, not a closed menu; a hybrid or unlisted choice is always acceptable.

## Concerns decide, not size

Never split by length, line count, or word count, and never skip splitting because something is short. The only question is how many distinct concerns the material holds. A short note that mixes purpose, data shape, and rules gets sharded. A very long document about a single concern stays one file. File sizes are whatever the concerns turn out to be.

## Workflow: split

1. **Survey the sources before moving anything.** List the files in scope and read enough of each to see the shape of the whole: what subjects exist (e.g. [a feature], [a service], [a module], [a process]) and which source files talk about which. When the sources span many subjects, state the plan in a few lines (subjects, rough folder layout) before starting so the user can redirect cheaply.
2. **Choose the layout.** Typically one folder per subject, each holding that subject's concern files; nest folders if the system has natural hierarchy. For material about a single subject this collapses to one folder. The user's chosen path always wins; default to placing output beside the sources.
3. **Name files after the concern they hold**, e.g. [existence.md], [table.md], [facts.md], [behavior.md]. A concern is a part that answers one kind of question and changes for one kind of reason. Pick names that fit this material and that someone could guess without opening the folder.
4. **Iterate source file by file.** Read one source completely, then route each passage to the shard it belongs to, creating the shard if it does not exist yet and adding to it if it does. A source covering several subjects feeds several folders; a subject spread across several sources gathers into one. Keep a running map of source to destinations so nothing is lost.
5. **Move, do not rewrite.** Each passage lands in exactly one place. If it serves two concerns, keep it where it belongs most and link to it from the other. Fix headings and add a one-line context sentence only where a shard would be unreadable alone.
6. **Handle overlap and conflict openly.** If two sources repeat the same fact, keep one copy. If they disagree (say, two different values for the same limit), do not silently pick one: keep both, labeled with where each came from, and flag it in the report or in an open-questions shard.
7. **Create only shards with real content.** No placeholders for concerns the sources do not cover.
8. **Choose a history mode per file** (next section), then apply it.
9. **Indexes are optional.** Add an `index.md` (top-level or per folder) only when a folder holds enough distinct concerns that a reader cannot tell from the names alone where to look, or when the user asks. It is a plain list of names with one line each.
10. **Keep the originals.** Never delete sources. Leave them in place or move them to an archive path, and say which.
11. **Verify and report.** Check each source against the map: every passage accounted for, nothing duplicated by accident. Report what was created, what each folder holds, conflicts found, and any judgment calls.

## Free-form content

The format inside a file is whatever fits its concern: SQL, a table, prose, a diagram, a code block, a checklist. Do not normalize formats across files and do not convert the source's own style.

Keep rationale next to the thing it explains (for instance, why an identifier is a [UUID] rather than a [serial integer]). Record reasons that come from the sources, the user, or the commit message. If you infer a reason, say it is inferred. Never invent history.

## History modes

Each file gets one of three modes. Decide with this question: *if someone reads only the current file, would they miss something they need to understand why it is this way?*

| Mode | When | What to do |
|---|---|---|
| **Override** | No (history has no value, e.g. a feature moved from a top bar to a side panel) | Rewrite the content. Leave no trace. |
| **In-line log** | Yes, and changes are additive or stack up (e.g. migrations adding columns) | Append a banner line carrying the metadata, then the new content below it. |
| **File log** | Yes, but changes replace old content or do not fit inside the file (e.g. behavior rules) | Write an entry to `<concern>.log.md` beside the file (`behavior.md` gets `behavior.log.md`). |

Details, banner variants for different file types, and entry formats are in `references/history-modes.md`. Copyable skeletons are in `assets/templates/history-templates.md`.

The first split needs no logs because no history exists yet. Logging starts with the first later change.

## Metadata is free

Banner lines and log entries carry whatever is useful and cheaply known: app version, branch, commit, author, date, reason, ticket. There is no fixed field set, and two entries in the same file may carry different fields.

Find the version in the project's own manifest [package.json] [pyproject.toml] [Cargo.toml] [pom.xml] [*.csproj] [go.mod plus a tag], and take branch, commit, author, and date from version control when available. If a value is unavailable, leave it out rather than guess.

## Workflow: update

When something changes in an already sharded folder:

1. Find the shard that owns the concern. If none fits, create one or ask.
2. Pick the mode with the question above.
3. Gather the metadata and the reason (ask the user if the reason is not obvious from the request or commit).
4. Apply the change in that mode. Touch only the affected files.

If new documentation arrives later (a new spec, a new service), run the split workflow on it and merge into the existing layout instead of starting a second folder.

## Reading a sharded folder

When loading a folder to answer a question, open only the files whose names match the concern. Skip `*.log.md` files unless the question is about history. That is the point of sharding: a focused context for a focused question.

For worked examples across different kinds of documentation, see `examples/shard-walkthrough.md`.
