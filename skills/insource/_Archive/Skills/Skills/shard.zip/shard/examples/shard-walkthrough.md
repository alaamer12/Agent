# Shard walkthroughs

Shard is not tied to one kind of document, one input size, one language, or one folder convention. The input can be a single file or an entire documentation set. Each example below uses a different domain. File names, folder names, and history choices are illustrative; a hybrid or unlisted choice is always acceptable.

## Contents

1. A whole system's documentation (many files)
2. A single feature spec
3. An incident runbook
4. A library design document
5. A legal or policy document
6. Size does not decide
7. An update after the split

---

## 1. A whole system's documentation

**Source:** a `docs/` folder of many files: `architecture.md`, `auth.md`, `billing.md`, `deploy.md`, `faq.md`, `glossary.md`, meeting notes, and old design memos. Topics overlap and some files cover several subjects.

**Process:**

1. **Survey.** Skim every file and list the subjects that exist (here: auth, billing, deployment, plus shared glossary). State the plan in a few lines and let the user adjust it.
2. **Iterate file by file.** Open `architecture.md`, and route its auth passages to `auth/`, its billing passages to `billing/`, and its infrastructure passages to `deployment/`. Move on to `auth.md`, which merges into the shards already started. Continue through `faq.md`, where each answer goes to the subject it belongs to.
3. **Keep a running map** of source file to destination shards, so coverage can be checked at the end.
4. **Surface conflicts.** If `auth.md` says tokens last 15 minutes and an old memo says 60, keep both in `auth/facts.md`, each labeled with its source file, and flag it in the final report. Do not silently choose.

**Result:**

```text
system/
├── auth/
│   ├── existence.md
│   ├── facts.md
│   └── behavior.md
├── billing/
│   ├── existence.md
│   ├── table.md
│   └── behavior.md
├── deployment/
│   ├── existence.md
│   ├── commands.md
│   └── edge-cases.md
├── glossary.md
└── open-questions.md
```

A top-level `index.md` is optional. With many sources feeding many folders it may help, but it is the user's call.

---

## 2. A single feature spec

**Source:** `notifications-spec.md`, one document mixing purpose, schema, rules, flows, and open questions.

**Result:**

```text
notifications/
├── existence.md       what it is, where it lives in the product, scope
├── table.md           schema (SQL, or any format the source used)
├── facts.md           limits, constants, retention rules
├── behavior.md        triggers, batching, delivery flow
├── edge-cases.md      failures, retries, duplicates
└── open-questions.md  undecided items
```

**History choices:**

- `existence.md`: [override]. Moving the entry point from a top bar to a side panel needs no trace.
- `table.md`: [in-line log]. Migrations stack up; each gets a banner and the new columns below it.
- `behavior.md`: [file log] in `behavior.log.md`. A rule change replaces the old rule.
- `table.md` may also explain design choices in prose, for example why identifiers are UUIDs rather than serial integers.

Same idea in other schema languages, to show the content format is free:

```sql
-- table.md could hold SQL
CREATE TABLE notifications (
  id uuid PRIMARY KEY,
  user_id uuid NOT NULL,
  body text NOT NULL
);
```

```go
// or a Go struct, if the source documented it that way
type Notification struct {
    ID     uuid.UUID
    UserID uuid.UUID
    Body   string
}
```

```python
# or a Python dataclass
@dataclass
class Notification:
    id: UUID
    user_id: UUID
    body: str
```

---

## 3. An incident runbook

**Source:** `payments-outage-runbook.md`, a long mix of symptoms, diagnosis steps, commands, contacts, and past incidents.

**Result:**

```text
payments-outage/
├── symptoms.md
├── diagnosis.md
├── commands.md        shell, SQL, or API calls, in whatever language the source used
├── escalation.md      who to call and when
└── past-incidents.md
```

**History choices:** `symptoms.md` and `escalation.md` are [override] (only the current truth matters). `past-incidents.md` is naturally an in-line, append-only file. `commands.md` uses [file log] when a command is replaced and the reason it changed matters.

---

## 4. A library design document

**Source:** `cache-library-design.md`, covering goals, public API, eviction policy, concurrency model, and benchmarks.

**Result:**

```text
cache-library/
├── goals.md
├── api.md
├── eviction.md        e.g. [LRU], [LFU], [TTL-based expiry], or a hybrid
├── concurrency.md
└── benchmarks.md
```

**History choices:** `eviction.md` and `concurrency.md` use [file log], because a design decision that was reversed is exactly what future readers will ask about. `benchmarks.md` uses [in-line log], where each run is dated beneath a banner.

---

## 5. A legal or policy document

**Source:** a long internal data-retention policy.

**Result:**

```text
data-retention/
├── scope.md
├── definitions.md
├── retention-periods.md
├── exceptions.md
└── review-process.md
```

**History choices:** `retention-periods.md` uses [file log] because auditors may need to know what applied when. `scope.md` is [override]. Shard moves the text as written; it never rewrites legal wording.

---

## 6. Size does not decide

Two sources, opposite sizes:

- **A short note** of a few paragraphs says what a feature is, lists its table columns, and states two business rules. It holds three concerns, so it becomes `existence.md`, `table.md`, and `facts.md`, even though it was tiny.
- **A very long reference** is an exhaustive list of error codes with descriptions. It holds one concern, so it stays as a single `error-codes.md`. Cutting it by length would create files that answer no distinct question.

The count of files follows from the concerns present, never from the length of the source.

---

## 7. An update after the split

The user says: "We added a `read_at` column to notifications for the unread badge."

1. The concern is the data shape, so the file is `notifications/table.md`.
2. The question "would a reader miss why this exists?" is yes, and the change is additive, so use an [in-line log].
3. Gather metadata: version from the project manifest, branch, commit, and date from version control. The reason comes from the user.
4. Append to `table.md`:

```text
******************** v2.4.0 | main | a1b2c3d | 2026-11-06 | unread badge needs a read timestamp ********************
read_at: timestamptz, nullable
```

If the same change also altered when notifications are marked as read, `behavior.md` gets a separate entry in `behavior.log.md`, using the same version and reason so the two can be matched later.
