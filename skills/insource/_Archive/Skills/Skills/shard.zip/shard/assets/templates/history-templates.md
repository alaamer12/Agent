# History templates

Placeholders are in `<angle-brackets>`. Every field is optional and the set is free: drop what is unknown, add whatever helps (author, ticket, branch, environment). Adapt comment syntax to the file's format.

## In-line banner (one line)

```text
******************** <version> | <branch> | <commit> | <date> | <short reason> ********************
```

With a longer reason underneath:

```text
******************** <version> | <commit> | <date> ********************
<one or two sentences on why this change was made>
```

## File log entry (`<concern>.log.md`)

```markdown
## <version> | <branch> | <commit> | <date> | <author>
Changed: <what is different now>
Why: <the reason>
Replaced: <what the old behavior or content was, if it helps>
```

## Inferred reason marker

When the reason is not stated by the source or the user, mark it:

```markdown
Why (inferred from commit message): <reason>
```
