# History modes in depth

All choices below are illustrative, not exhaustive. A hybrid or unlisted approach is acceptable whenever it serves the reader better.

## Contents

1. Choosing a mode
2. Override
3. In-line log
4. File log
5. Edge cases

---

## 1. Choosing a mode

Ask: *if someone reads only the current file, would they miss something they need to understand why it is this way?*

- **No** means [override]. The past adds nothing.
- **Yes, and changes stack up** (each change adds to the content rather than replacing it) means [in-line log].
- **Yes, but changes replace earlier content**, or the history would clutter the file, means [file log].

The judgment is about the reader's need, not the file's name. A `table.md` that never changes shape may be override; a `facts.md` full of rules that were tuned over time may deserve a file log.

## 2. Override

Rewrite the file so it describes the present state only. Example: a feature's location moved from a top bar to a side panel. Nobody needs the old location to understand the current design, so the old text is simply replaced.

Use override as the default for concerns that describe *what is true now* (existence, location, naming, scope).

## 3. In-line log

The history is part of the content, so it lives in the file. Append a **banner line** and put the new content below it. Older content stays above, untouched.

A banner is one long rule of filler characters with the metadata embedded in it, so it is easy to spot when scanning and cheap to grep. Fill character, length, and field order are free. Adapt the banner to the file's syntax so it stays valid in that format.

**Markdown or plain text**

```text
******************** v2.4.0 | main | a1b2c3d | 2026-11-06 | unread badge needs a read timestamp ********************
```

**SQL**

```sql
-- ******************** v2.4.0 | main | a1b2c3d | 2026-11-06 | unread badge needs a read timestamp ********************
ALTER TABLE notifications ADD COLUMN read_at timestamptz NULL;
```

**YAML or TOML or shell**

```yaml
# ******************** v2.4.0 | main | a1b2c3d | 2026-11-06 | unread badge needs a read timestamp ********************
read_at: { type: timestamptz, nullable: true }
```

**C-family, Go, Rust, TypeScript, Java, C#**

```typescript
// ******************** v2.4.0 | main | a1b2c3d | 2026-11-06 | unread badge needs a read timestamp ********************
readAt: Date | null;
```

The reason belongs in the banner when it is short. When it needs a paragraph, put one or two sentences right under the banner.

Good fits: table or schema evolution, configuration keys, constants that gain new entries, lists of supported items.

## 4. File log

When history should not sit inside the file, write it to a sibling file named `<concern-file>.log.md` (for example `behavior.md` gets `behavior.log.md`). The log is ordinary free-form Markdown. A simple, scan-friendly entry:

```markdown
## v2.4.0 | main | a1b2c3d | 2026-11-06
Changed: notifications are batched every 5 minutes instead of sent instantly.
Why: users were flooded during bulk imports.
```

Newest-first or oldest-first is a free choice; keep one order per log. Entries may carry any metadata that helps. The concern file itself shows only the current truth, so it stays short and readable.

Good fits: flows, rules, state machines, anything where a change replaces older content.

## 5. Edge cases

- **A file switches modes.** That is fine. If an override file starts needing history, begin an in-line or file log from that change on; do not reconstruct the past.
- **An in-line file grows unwieldy.** Move older stacked history into `<concern>.log.md` and leave a one-line note pointing to it.
- **A change touches several concerns.** Apply the right mode to each file separately, and let the entries share the same version and reason so they can be correlated.
- **No metadata is available.** Write the entry with only what is known (a date and a reason is enough). Do not fabricate a version or commit.
- **The reason is unknown.** Ask the user. If they do not know, record the change without a reason, or mark an inferred reason as inferred.
- **Reading for a normal question.** Skip log files. Open them only when the question is about what changed, when, or why.
