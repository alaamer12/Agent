# Scale arithmetic

Do the arithmetic before reasoning. A stated target usually pins down several design decisions on its own, and the numbers also reveal when a target is really a peak, a marketing figure, or an unmeasurable promise.

## Availability

One year is about 31,536,000 seconds. Allowed downtime is that figure multiplied by the unavailability fraction.

| Target | Allowed downtime per year |
|---|---|
| 99.9% | about 8.8 hours |
| 99.99% | about 52.6 minutes |
| 99.999% | about 5.3 minutes |
| 99.9999% | about 31.5 seconds |
| 99.99999% | about 3.2 seconds |
| 99.999999% | about 0.3 seconds |

What this forces:
- Below roughly five minutes a year, no human can be in the recovery loop. Failover, deploys, and rollbacks must be automatic and must not drop traffic.
- Availability composes multiplicatively across serial dependencies. Five dependencies at 99.99% each give about 99.95% together, so every hard dependency in the request path costs you. Remove it, cache it, or let it degrade gracefully.
- At the extreme end the figure is a design constraint, not a promise you can measure. Say that plainly, then design for small blast radius, redundancy across failure domains, and automated recovery.

## Throughput and users

Convert every target to the same unit before comparing. Seconds per day is 86,400.

- Requests per second to requests per day: multiply by 86,400.
- Daily users to users per second: divide by 86,400.
- Requests per user per day: daily requests divided by daily users. If the answer is implausibly high, either clients are very chatty or the target is a peak, and the average is several times lower. Ask which, and state the assumption.
- Peak-to-average ratio matters more than the headline. Size for the peak, pay for the average.
- Capacity per node: divide the peak by a realistic per-node rate. Treat any per-node figure as illustrative and say so.

Worked example with made-up numbers: a peak of 2 million requests per second is about 173 billion requests per day if sustained. Spread over 50 million daily users, that is roughly 3,500 requests per user per day, which is too high for typical clients, so the peak is probably several times the average. If the average is a fifth of the peak, the sustained figure drops to about 700 per user per day, which is plausible for a busy client. At an illustrative 25,000 requests per second per node, the peak needs on the order of 80 nodes before any redundancy.

What large numbers tend to force:
- A single primary database cannot take the write volume, so writes need partitioning by a key that matches access patterns, and hot keys need special handling.
- Reads usually dominate, so read models, caching, and replicas carry the load, with a deliberate consistency story for users who just wrote something.
- Anything that fans out per user needs a bounded strategy for large groups.
- A global user base means multiple regions, so data placement, replication lag, and regulatory boundaries become design questions.

## How to present it

State each figure, the arithmetic, and the decision it forces, in one line. Example shape: "Target X per second means Y per node across Z nodes, so a single writer is impossible and we partition by W."
