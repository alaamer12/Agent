# Concept atlas

A curated vocabulary of generic concepts, with their precise boundaries and the domain facts that specialize each one. Use it at the derivation step only: after a failure is named, find the nearest entry, then specialize it. Starting from this list produces catalog recitation. It is a floor, not a ceiling, so derive beyond it when the failure demands.

Entries keep the boundaries that people usually blur, because category confusion is a real failure mode. Each ends with **Specialize by**: the domain facts that turn the generic concept into a derived one.

## Contents
1. Twice, and Partial or late: reliable processing
2. Together: simultaneous change
3. Whose truth: versions and conflicting views
4. Over time: history and correction
5. Many: load, reads, and growth
6. Allowed: authorization models
7. Mistake or malice: enforced and auditable change
8. Change: boundaries and flexibility
9. Entries that are already specialized

---

## 1. Twice, and Partial or late

**Webhook Event Reconciliation.** Compare events received from an external system against the real state of your application, detect missing, duplicated, delayed, and out-of-order events, and repair the difference against the authoritative source. Specialize by: which system is authoritative, how you query it, how often you reconcile.

**Transactional Outbox.** Record the event in an outbox table inside the same database transaction as the state change, then deliver it from a separate process. It addresses the dual-write problem. Specialize by: ordering needs, what consumers do with duplicates, outbox retention.

**Saga / Distributed Workflow.** Coordinate a business transaction across independent services without one distributed transaction. Each step commits locally, and compensating actions reverse earlier business effects when a later step fails. Real workflows also need retries, timeouts, and explicit recovery states. Specialize by: what "compensate" means for each step, since some effects cannot be undone.

**Reliable Event Delivery.** Delivery and processing that survive network failures, crashes, retries, and unavailability: durable queues, acknowledgments, retries, dead-letter queues, idempotent consumers, reconciliation. Guarantees are at-most-once, at-least-once, or effectively-once at the application level. Specialize by: which guarantee each event type actually needs.

**Domain Eventual Consistency.** Different parts of the system may briefly hold different views of the same business state but are expected to converge. The decision is per domain: what must be settled inside the main transaction (for example whether a payment succeeded) and what may converge later (notifications, secondary read models). Specialize by: the exact line between settled and convergent state.

**Sync Queue / Conflict Resolution / Atomic Completion.** Three related but distinct concerns for systems that synchronize asynchronously or work offline. The sync queue stores pending operations. Conflict resolution decides competing changes using version checks, domain-specific merging, or explicit user decisions. Atomic completion means an operation counts as complete only when all required changes succeeded together, or enough was recorded to resume or recover; across independent services this needs a workflow, protocol, or recovery mechanism, not a local transaction. Specialize by: what a merge means for each field.

## 2. Together

**Concurrency Control.** Techniques that coordinate simultaneous operations on shared data to prevent conflicting updates, lost changes, and invalid states. Pessimistic control assumes conflicts and uses locks. Optimistic control (OCC) proceeds without long-lived locks, checks whether the data changed before committing, and rejects or retries on conflict. They are two strategies within one field, not competing categories. Specialize by: conflict frequency and the cost of a retry.

**Aggregate Boundaries.** From domain-driven design: which objects must stay consistent together inside one transactional boundary, controlled through a root entity. Good boundaries protect business invariants without large transactions or needless coordination between unrelated parts. Specialize by: the actual invariants of the domain.

**Locking-Based Authorization.** An operation acquires a lock or exclusive claim before touching a protected resource. This is primarily a concurrency-control technique, not a standalone authorization model: holding a lock does not prove the holder is permitted to act. Specialize by: pairing it with a real permission check.

**Dispatch / Assignment Algorithm.** Assigning tasks or resources to available workers, optimizing some mix of capacity, distance, latency, fairness, priority, cost, and balance. Production versions must also handle unavailable workers, retries, duplicate assignments, changing capacity, and concurrent claims. Specialize by: which objective dominates and what a claim race costs.

## 3. Whose truth

**Configuration Versioning, Desired State, and Monotonic Versioning.** Each configuration has an explicit version, and the system separates the state it wants a client to reach from the state the client reports. Monotonic versioning means accepted versions only move forward, so a client can reject a stale update and never apply an older configuration after a newer one. Specialize by: how stale updates arise on your network.

**Availability and Consistency Trade-offs.** The CAP theorem describes a trade-off during a network partition: for the affected operations a system chooses consistency or availability. It does not force every system to give one up permanently, and different operations can choose differently. Specialize by: the correctness cost of each operation being wrong versus unavailable.

## 4. Over time

**Temporal Data Modeling.** Preserve changes over time rather than storing only the latest state, so the system can reconstruct what a record, offer, configuration, or workflow looked like at a given moment. Bitemporal modeling is one specialized form. Specialize by: which entities are ever asked "as of when".

**Bitemporal Data Modeling.** Track two independent timelines: valid time (when a fact was true in the world) and transaction time (when the system recorded it). It answers both what was believed at a moment and what is now known about what was true then. Useful for auditing, financial records, compliance, and correcting history. Specialize by: how often corrections arrive late.

## 5. Many

**CQRS.** Separate operations that change state (commands) from operations that read it (queries), with different models and, when needed, different storage. Useful when read and write needs differ a lot, and it adds complexity when synchronization is asynchronous. Specialize by: the read-to-write ratio and the tolerable staleness.

**Cursor-Based Pagination.** Retrieve records relative to a stable position instead of an offset. Often cheaper on large datasets and immune to some inconsistencies when rows are inserted or deleted between requests. Reliable versions use deterministic ordering with a unique tie-breaker such as an ID. Specialize by: the sort orders users actually need.

**Control Plane / Data Plane Separation.** The control plane manages configuration, policy, desired state, scheduling, and coordination. The data plane handles operational traffic using what the control plane supplies. Common in infrastructure, networking, fleet management, and large distributed services. Specialize by: what must keep working when the control plane is down.

**Hot Path / Cold Path.** Keep latency-sensitive, frequent operations (client requests, authorization checks) apart from expensive or infrequent work (analytics, reconciliation, bulk updates), while preserving correctness. Specialize by: which checks truly cannot leave the hot path.

**Materialized Read State.** Maintain a precomputed representation of the state that frequent requests need, so they avoid repeated expensive joins. It acts as a read model or materialized view and needs a defined update strategy and an acceptable consistency delay. Specialize by: the request shape that dominates traffic.

**Fleet-Level Rate Limiting.** Control the total request rate across a whole fleet of clients rather than limiting each independently. When many clients reconnect together after an outage, fleet-level limits combined with exponential backoff, randomized jitter, and staged recovery prevent a thundering herd from overwhelming the service. Specialize by: how synchronized client behavior really is.

## 6. Allowed

**Fine-Grained Authorization.** Evaluate access at a detailed level: a particular resource, action, field, record, or workflow state, under current conditions, instead of one decision about the whole application. Specialize by: which attributes of the situation change the answer.

**Policy-Based Access Control.** Authorization governed by explicit policies instead of checks scattered through application code. Policies can combine established models: RBAC (permissions assigned to roles), ABAC (decisions from attributes of user, resource, action, and environment), and ReBAC (decisions from relationships such as ownership or membership). Specialize by: which relationships and attributes your domain turns on.

**Lease-Based Authorization.** A permission, grant, or lock stays valid for a limited period and must be renewed. Useful for temporary access, distributed ownership, and coordination; expiry and clock-related edge cases need careful handling. Specialize by: acceptable clock skew and what happens mid-operation at expiry.

**Offline Grace / Eventual Authorization.** Permit limited operation while a client cannot reach the central authorization system, using previously issued permissions, cached decisions, or short-lived credentials, then refresh and reconcile on reconnect. The design must define expiry, revocation behavior, allowed offline operations, and the security risk accepted. Specialize by: the worst thing an offline client can do in the grace window.

**Capability-Based Authorization.** Possession of a specific, unforgeable capability grants authority over defined operations on a resource, and can encode both the resource and the permitted actions. For example, a short-lived upload capability lets a client upload one file without access to the wider storage system. Specialize by: the narrowest useful scope and lifetime.

**Entitlement Management and Entitlement Graphs.** Represent and evaluate the rights that users, devices, services, or organizations hold over resources. A graph relating principals, groups, roles, resources, and permissions helps with inherited access, delegation, subscriptions, and organizational membership. The graph is one implementation of entitlement management, not a separate universal standard. Specialize by: how deep inheritance and delegation go.

## 7. Mistake or malice

**Double-Entry Ledger.** Every transaction is recorded as balanced debit and credit entries, with total debits equal to total credits. It creates an auditable record of movement and exposes inconsistencies without trusting a single mutable balance field. Specialize by: what the accounts and the invariants are.

**Approval Workflow.** A state-driven process where an operation moves through defined states by explicit approval decisions and transition rules. Approval need not involve a human: an application layer, policy engine, or automated service can approve or reject. Usually a state machine (pending, approved, rejected, completed) where only valid transitions are allowed and every approval is recorded and enforced consistently. Specialize by: who or what may approve at each state.

## 8. Change

**Polymorphic Domain Modeling.** Several domain types share a common interface while keeping distinct behavior and rules, so different kinds of resources, payments, assignments, or workflow steps need not be forced into one identical structure. It must preserve type-specific constraints and avoid excessive conditionals or an over-generic data model. Specialize by: which behavior genuinely differs between the types.

**Integration-Ready Architecture.** Prepare to integrate with external services without tying core logic to specific providers: explicit integration boundaries, provider adapters, stable internal interfaces, timeouts, retries, idempotency, and defined failure handling. Specialize by: how likely each provider is to change.

**Anti-Corruption Layer.** A boundary that translates an external system's models, terminology, and behavior into the internal domain's own language, so the provider's model does not spread through business logic. For example, a provider's payment states may not match your domain's states. Specialize by: where the two models disagree.

**Hexagonal Architecture / Ports and Adapters.** Core logic sits behind ports, and external technologies connect through adapters such as database adapters, HTTP controllers, provider integrations, and queue consumers. The domain stays independent of infrastructure and easier to test and replace. Specialize by: which dependencies you realistically expect to swap.

## 9. Entries that are already specialized

Several entries above are not generic patterns. Each is a generic concept plus one domain fact. Copy the move, not the names.

| Entry | Generic base | Domain fact that specialized it |
|---|---|---|
| Webhook Event Reconciliation | reliable delivery | an external system is the authority and its feed is unreliable |
| Domain Eventual Consistency | eventual consistency | each domain has a settled core and a convergent edge |
| Materialized Read State | materialized view | one request shape dominates and must stay cheap |
| Monotonic Configuration Versioning | versioning | updates reach clients late, out of order, or twice |
| Offline Grace Authorization | authorization | clients are disconnected for real stretches of time |
| Fleet-Level Rate Limiting | rate limiting | clients fail and recover in synchronized waves |
| Atomic Completion | transaction | the steps live in independent services |
