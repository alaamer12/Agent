# Worked derivations

These show the level of specificity to aim for. Each chain runs Pressure, Failure, Derived concept, Decision. Domain detail lives here on purpose, so the core workflow in SKILL.md stays domain-neutral. The systems are unrelated to each other deliberately: the move is the same everywhere, the names are not.

## Contents
1. A small app grown rung by rung (scale ladder)
2. Event seat reservations
3. Subscription billing
4. Delivery dispatch
5. A fleet of remote clients
6. Contrast: catalog recitation vs derivation

---

## 1. A small app grown rung by rung

Starting point: a task-tracking app. Each rung asks what assumption stops holding.

**Rung 0: one user, one device.** Nothing is needed. Say so. Machinery here is over-engineering.

**Rung 1: one user, two devices.**
- Pressure: Partial or late, Together.
- Failure: the user completes a task on the phone while offline, edits its title on the laptop, and one change silently overwrites the other.
- Derived: **Per-Field Task Merge Semantics**. Merge per field, and treat "completed" as an intent with a timestamp rather than a value to overwrite.
- Decision: version each field of a task, not the whole record.

**Rung 2: shared lists, thousands of users.**
- Pressure: Together, Allowed.
- Failure: two people reorder the same list at once and a completed task reappears.
- Derived: **Task-Level Optimistic Concurrency** (the conflict unit is the task, not the list) and **Membership-Based List Access** (permission comes from belonging to this list).
- Obligations: a conflict response needs a defined resolution path in the client.

**Rung 3: millions of users.**
- Pressure: Many.
- Failure: one popular shared list becomes a hot partition, and every member's notification fans out in one burst.
- Derived: **Hot List Partitioning** and **Fan-Out on Read for Large Lists**.
- Gate: only worth it above a list-size threshold. Keep the simple path for the long tail.

**Rung 4: very large daily user counts and very high peak throughput.**
- Pressure: Many, Partial or late.
- Failure: reads dominate, and a user who just completed a task refreshes and sees it undone.
- Derived: **Read-Your-Writes Session Consistency** over cached read models, with writes acknowledged only after a durable log append.
- Do the arithmetic first (see scale-arithmetic.md).

**Rung 5: extreme availability.**
- Pressure: Partial or late.
- Failure: a region fails mid-write and an acknowledged completion is lost.
- Derived: **Cell-Based Isolation** (a failure takes down one slice of users, never all of them) plus **Replicated Write Log Before Acknowledgement**.
- Honest note: at the extreme end the availability figure is mostly a design constraint rather than something you can measure and promise. Say that, then design for small blast radius and automated recovery.

---

## 2. Event seat reservations

- Pressure: Together.
- Failure: two buyers select the last seat at the same moment and both are told it is theirs.
- Derived: **Seat-Level Optimistic Claim**: a claim succeeds only against the seat's current version, and the loser gets an immediate, specific answer.
- Pressure: Partial or late.
- Failure: a buyer holds a seat, abandons checkout, and the seat stays blocked until the event.
- Derived: **Time-Boxed Seat Hold**, a lease on the seat that expires on its own.
- Obligations: define what happens when payment completes a moment after the hold expires.
- Pressure: Many.
- Failure: a popular on-sale makes everyone request the same seats in the same second.
- Derived: **Admission Queue with Fleet-Level Rate Limiting**, so the seat service sees a steady flow instead of a stampede.
- Dropped on purpose: event sourcing for the whole venue model. The failures only exist in the claim path.

## 3. Subscription billing

- Pressure: Twice.
- Failure: the payment provider re-delivers a payment-succeeded event and the invoice is marked paid twice, extending access twice.
- Derived: **Idempotent Payment Processing**, keyed on the provider's event identity.
- Pressure: Whose truth.
- Failure: the customer's browser closes right after paying, so the success page never loads and the account looks unpaid.
- Derived: **Webhook Event Reconciliation**: the provider's event is the truth, the browser redirect is only a hint.
- Pressure: Over time.
- Failure: a customer disputes a charge from three months ago, but the plan price was edited since.
- Derived: **Temporal Plan Pricing**: record what each price was and when it applied, so any past invoice can be reproduced.
- Pressure: Mistake or malice.
- Failure: a refund is issued by editing the balance, leaving no trace of why the number changed.
- Derived: **Double-Entry Ledger for Account Credits**: corrections are balanced new entries.

## 4. Delivery dispatch

- Pressure: Together.
- Failure: two dispatchers assign the same order to different couriers.
- Derived: **Single-Claim Order Assignment**: an assignment is a versioned claim on the order, and the second claim fails visibly.
- Pressure: Partial or late.
- Failure: a courier accepts a job and then goes offline, and the order sits unassigned while the customer waits.
- Derived: **Acceptance Lease with Reassignment**: acceptance expires unless the courier's client confirms progress.
- Pressure: Allowed.
- Failure: a courier sees customer contact details for orders they no longer hold.
- Derived: **Assignment-Scoped Visibility**: access follows the current assignment and ends when it does.
- Pressure: Change.
- Failure: a new kind of job (scheduled pickup) needs different rules, and the order model is full of special cases.
- Derived: **Polymorphic Job Modeling**: shared lifecycle, type-specific constraints.

## 5. A fleet of remote clients

- Pressure: Whose truth.
- Failure: a configuration is pushed twice in quick succession, the packets cross, and a client ends up on the older one.
- Derived: **Monotonic Configuration Versioning**: a client rejects any version lower than the one it holds.
- Pressure: Many.
- Failure: the service restarts and the entire fleet reconnects in the same minute.
- Derived: **Fleet-Level Rate Limiting with Jittered Backoff** and staged recovery.
- Pressure: Allowed.
- Failure: a client with no connectivity cannot validate its permissions and stops all work.
- Derived: **Offline Grace Authorization**: a short-lived signed grant that allows a defined set of actions.
- Obligations: define expiry, what revocation means while offline, and which actions are excluded.

---

## 6. Contrast: catalog recitation vs derivation

Recitation: "I'll apply domain-driven design, CQRS, and event sourcing for scalability."
Why it fails: nothing in it says what breaks, and it fits any project.

Derivation: "When the provider re-delivers a payment event, the same invoice would be settled twice and access extended twice, so I'll reconcile on the provider's event identity instead of trusting the browser redirect."
Why it works: it names the failure in domain nouns, commits to a decision, and a person who knows payments recognizes the problem immediately.
