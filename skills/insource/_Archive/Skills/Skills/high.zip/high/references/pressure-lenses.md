# Pressure lenses

Each lens is a family of questions to push at a lifecycle transition. The right column is a map from the lens to the generic concepts it tends to touch. Consult that column only at the derivation step, after you have a named failure. Starting from it produces catalog recitation.

| Lens | Questions | Generic concepts it tends to touch |
|---|---|---|
| Twice | Can this request be retried, redelivered, or double-clicked? Does the other side retry on its own? What counts as "the same" request? | Idempotency keys, deduplication, exactly-once illusions, reconciliation |
| Together | Can two actors change this at once? What is the unit that must stay consistent? What happens to the loser? | Optimistic or pessimistic concurrency, aggregate boundaries, transactions, merge semantics |
| Partial or late | Which steps can succeed while others fail? Can events arrive out of order? What if the other system is down for an hour? | Outbox, sagas, compensation, queues, retries with backoff, dead letters, offline-first sync |
| Whose truth | Where are the copies? Which one is authoritative? How do copies converge? Who maps identity between systems? | Source of truth, entity mapping, eventual consistency, conflict resolution, reconciliation jobs |
| Over time | Will anyone ask "what was true last month" or "who changed this"? Do corrections rewrite history or add to it? | Event history, append-only records, temporal or bitemporal modeling, audit trail, versioning |
| Many | What is the hot spot? What grows without bound? What fans out? What is read far more than written? | Partitioning, caching and read models, pagination, backpressure, rate limits, cell-based isolation |
| Allowed | Does permission depend on role alone, or on a relationship between this actor and this record? Can it vary by tenant, time, or state? | RBAC, relationship-based or attribute-based authorization, tenant isolation |
| Mistake or malice | Can this be undone? Can it be traced after the fact? What is the worst a confused or hostile actor can do with it? | Reversibility, immutability, audit, validation at boundaries, abuse limits |
| Change | What will the business most likely ask for next? What would that cost today? | Extension points, versioned contracts, modular boundaries, polymorphic modeling |

## Using a lens well

- Ask the question about a specific transition, not about the system in general. "What if the payment confirmation arrives twice?" finds a failure. "What about reliability?" finds nothing.
- A lens that produces no failure is a result, not a miss. Record it as "not needed here" and move on.
- If two lenses expose the same failure, you have found something central. Derive it first.
- Prefer failures the user would feel (a duplicated charge, a lost task, a teacher seeing the wrong students) over failures only an engineer would notice.
