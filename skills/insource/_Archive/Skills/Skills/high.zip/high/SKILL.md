---
name: high
description: Derive the domain-specific concepts a system actually needs, instead of reciting well-known patterns. Start from the failures the system's own domain creates, then specialize the nearest generic concept until it fits. Use this whenever the user says /high, asks for deeper or staff-level design thinking, wants to know what would break as a system grows, asks for reliability, availability, consistency or scale analysis, reviews an architecture or spec for depth, or wants a small system reasoned about as if it had to run at much larger scale. Use it even if the user never says "high". Skip it for trivial one-step coding tasks and for questions with a single factual answer.
---

# High

Most design advice is a catalog of named patterns. Reciting one shows you know the vocabulary and nothing more, because a generic concept fits every system equally well. Real systems don't adopt a pattern unchanged. They bend it around the forces of their own domain until it only makes sense there.

This skill does that bending deliberately. Concepts are derived from pressure on a specific system, and the final name carries that system's own nouns.

Two kinds of concept, so you can tell which one you hold:

- **Advanced concept:** generic, portable, widely documented. Example: *idempotency*.
- **High concept:** an advanced concept specialized by a domain force, so it names a failure and carries domain nouns. Example: *Webhook Event Reconciliation* is idempotency plus the discovery that an external system re-delivers, drops, and reorders events, so its feed cannot be trusted as the only truth.

Rule of thumb: never open with a concept name. Open with the failure. The name comes last.

## The chain

Run these in order. Each step feeds the next, which is what makes it a chain rather than a checklist.

1. **Ground the system in plain nouns.** Who acts, what thing of value moves, and what "done" means. If you don't know the domain well enough to do this, ask one question or state your assumption out loud. Never invent domain facts.

2. **Trace the lifecycle of each thing of value.** Where it is created, which states it passes through, who changes it, and in what order. Failures live at the transitions.

3. **Apply pressure.** Push each transition through the lenses below. Skip a lens when it plainly doesn't apply, because forcing every lens everywhere is how over-engineering starts. `references/pressure-lenses.md` has the question sets.
   - **Twice:** what if this happens two times?
   - **Together:** what if two actors do it at the same moment?
   - **Partial or late:** what if it half-completes, arrives out of order, or the other side never answers?
   - **Whose truth:** when two places disagree, which one wins and why?
   - **Over time:** will someone later need to know what was true then, not just now?
   - **Many:** what stops holding at 10x, 100x, 1000x?
   - **Allowed:** who may see or do this, and does that depend on a relationship, a state, or a time window rather than a fixed role?
   - **Mistake or malice:** can it be undone, traced, or abused?
   - **Change:** what requirement will most likely arrive next?

4. **Name the failure in domain nouns.** One sentence: "When X happens, Y breaks, and the user sees Z." If you can't write that sentence, there is no failure yet, so stop. A concept without a failure is decoration.

5. **Derive the concept.** Find the generic concept closest to the failure (`references/concept-atlas.md` is a vocabulary for this step), then specialize it with the domain's nouns and constraints until the name could only belong to this system. Check the result:
   - It names a failure, not a technique.
   - Strip the domain nouns and it collapses back into a generic concept.
   - It changes what you would build.
   - Someone who knows the domain would recognize the problem on sight.

6. **State the obligations, then follow one more link.** Every concept you adopt obliges the design to define something: expiry, ordering, ownership, retention, behavior on conflict. List those. They also create a second-order problem of their own (stored keys expire, a log grows, a cache goes stale), so decide whether that problem earns another derivation. Stop when the next link costs more than the failure it prevents.

7. **Gate and rank.** Keep a concept only if all of these hold:
   - It answers a real failure from step 4.
   - It changes a concrete decision.
   - Its cost is proportional to the blast radius of the failure.

   Then rank what survives and keep the top few. Five strong concepts beat thirty names. Listing what you rejected and why shows judgment, and it is what separates depth from over-engineering.

## Depth follows the target

The stated target sets how far the chain runs. A small personal tool earns two or three chains, and "nothing needed here" is a valid answer for a rung that doesn't need anything. A target stated in numbers (availability, throughput, user count) earns the **scale ladder**: run the *Many* lens one order of magnitude at a time and ask what assumption stops holding at each rung. Do the arithmetic first, because the numbers often dictate the concepts. See `references/scale-arithmetic.md`.

## Output

For each kept concept:

**Derived concept name**
- Pressure: which lens exposed it
- Failure: the one-sentence failure in domain nouns
- Decision: what you would build or change
- Obligations: what the design must now define
- Cost and when to skip: what it costs, and the condition under which it isn't worth it

Then one short line listing the generic concepts you considered and dropped, each with a reason.

Fit the form to the audience. An engineer reviewing a design wants the structure above. A non-technical reader wants the failure and the decision in plain language, with the concept name as a footnote. Any text meant to persuade should lead with the failure the reader will recognize and keep the technical detail in support, rather than listing practices.

## Failure modes to avoid

- **Catalog recitation:** a list of well-known pattern names with the domain left out.
- **Term without failure:** a name that doesn't say what breaks.
- **Domain-free concept:** it would fit any system equally well.
- **Category confusion:** filing a concept under the wrong family, such as treating a lock as authorization when it is concurrency control. Be precise about what is a kind of what.
- **Pressure everywhere:** every lens applied to every thing, producing a design far beyond the target.
- **Invented domain facts:** deriving from assumptions you never stated or checked.
- **Hiding the work:** presenting only the concept name, so the reader can't verify the derivation.

## Language

Reply in the user's language. Keep established concept names in English even inside text written in another language, since that is how engineers search for and recognize them.

## Reference files

- `references/pressure-lenses.md`: expanded question sets per lens, and which generic concepts each lens tends to touch. Use that map only at step 5, never as a starting list.
- `references/concept-atlas.md`: a curated vocabulary of generic concepts with their precise boundaries and the domain facts that specialize each one. Consult it after a failure is named, never before.
- `references/derivation-examples.md`: worked chains from several unrelated systems, including a small app grown rung by rung. Read it to calibrate the level of specificity.
- `references/scale-arithmetic.md`: turning availability, throughput, and user targets into concrete forces.
