---
type: llm
focus: trace
weight: 1
---

The response states at least one assumption about the domain or asks a question about it, instead of presenting guesses as facts.
