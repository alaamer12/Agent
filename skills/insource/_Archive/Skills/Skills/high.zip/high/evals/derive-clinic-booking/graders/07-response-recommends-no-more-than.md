---
type: llm
focus: trace
weight: 1
---

The response recommends no more than seven primary concepts and says which common patterns it deliberately left out.
