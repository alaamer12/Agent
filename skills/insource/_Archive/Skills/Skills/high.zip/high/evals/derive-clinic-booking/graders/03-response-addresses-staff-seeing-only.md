---
type: llm
focus: trace
weight: 1
---

The response addresses staff seeing only the patients and appointments of their own clinic, and describes authorization based on membership or relationship rather than a single global role.
