---
tags: [skill-creator]
max_turns: 20
timeout_seconds: 600
allowed_tools: [Read, Glob, Grep, Skill, Write, Edit, Bash]
---

I'm building a note-taking app that syncs across a user's phone and laptop. Leadership says it has to handle 40 million daily users and 99.999% availability. All I have today is a simple version. How should I think about getting there?
