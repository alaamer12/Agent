---
type: llm
focus: trace
weight: 1
---

The response does not open with a bare list of pattern names; its first substantive content describes a failure or the lifecycle of a booking.
