---
type: llm
focus: trace
weight: 1
---

The response says that at this availability level recovery cannot depend on a human acting manually, or that the figure is largely a design constraint rather than something that can be measured and promised.
