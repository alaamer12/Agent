---
type: llm
focus: trace
weight: 1
---

The response states that 99.999% availability allows roughly 5 minutes of downtime per year (anything from 5 to 6 minutes counts).
