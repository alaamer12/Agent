---
type: llm
focus: trace
weight: 1
---

The response says what it chose not to add and why, or says that nothing more is needed.
