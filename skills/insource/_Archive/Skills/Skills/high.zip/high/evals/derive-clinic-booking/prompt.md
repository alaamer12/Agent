---
tags: [skill-creator]
max_turns: 20
timeout_seconds: 600
allowed_tools: [Read, Glob, Grep, Skill, Write, Edit, Bash]
---

/high We're building appointment booking for a network of about 200 clinics, with reminders by SMS and email. Walk me through the concepts we'll actually need. I don't want a list of well-known patterns.
