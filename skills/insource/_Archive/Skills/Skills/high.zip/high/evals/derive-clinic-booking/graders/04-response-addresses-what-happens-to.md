---
type: llm
focus: trace
weight: 1
---

The response addresses what happens to appointment history when a booking is rescheduled or cancelled, and proposes recording the change rather than overwriting it.
