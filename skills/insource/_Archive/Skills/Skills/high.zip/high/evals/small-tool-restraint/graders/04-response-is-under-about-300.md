---
type: llm
focus: trace
weight: 1
---

The response is under about 300 words.
