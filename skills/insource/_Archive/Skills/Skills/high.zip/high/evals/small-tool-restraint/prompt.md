---
tags: [skill-creator]
max_turns: 20
timeout_seconds: 600
allowed_tools: [Read, Glob, Grep, Skill, Write, Edit, Bash]
---

/high I'm building a small internal tool where about 15 coworkers log what they want for the Friday lunch order. What do I need to worry about?
