---
type: llm
focus: trace
weight: 1
---

Every concept the response recommends is tied to a failure described in the app's own terms (notes, devices, sync, edits), not only introduced by its generic pattern name.
