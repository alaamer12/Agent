---
type: llm
focus: trace
weight: 1
---

The response is organized as a progression of stages from the current simple version upward, and each stage says what assumption stops holding.
