---
type: llm
focus: trace
weight: 1
---

The response identifies what goes wrong when the same note is edited on two devices (for example while one is offline) and proposes a merge or conflict-handling approach specific to notes.
