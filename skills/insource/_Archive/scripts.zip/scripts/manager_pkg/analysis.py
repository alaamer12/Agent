"""Metadata linting, README catalog verification, reporting, lookup, and crossreferences."""

from __future__ import annotations

import argparse
import json
import os
import posixpath
import re
from collections import Counter
from pathlib import Path
from typing import Any, Iterable, Sequence
from urllib.parse import unquote

from .agents import agent_names, agent_skill_dir
from .config import (
    DOCS_CATALOG_FILES,
    DOCS_NAME,
    LINT_RULE_IDS,
    ManagerError,
    README_NAME,
    REFERENCE_SUFFIXES,
    REFERENCE_TOKEN_RE,
    SEMVER_RE,
    SKILL_LENGTH_LIMIT,
    SKILL_TYPES,
    SKIP_NAMES,
    SPECIALIZED_ALIASES,
    SPECIALIZED_GENERAL,
    SPECIALIZED_RE,
    SPECIALIZED_REJECTED,
    STANDALONE_CATEGORY,
    yaml,
)
from .deploy import SyncIssue, audit_all, resolve_into
from .registry import (
    SkillStructure,
    _norm_version,
    check_versions,
    git_head,
    git_last_commit,
    git_status_map,
    inspect_directory,
    iter_files,
    map_concurrent,
    read_frontmatter,
    registry_skills,
    skill_git_state,
    skill_parent,
    skill_snapshot,
    walk_skills,
)
from .remotes import remote_root, remotes_all
from .reporting import (
    _DISPLAY,
    display_info,
    display_kv,
    display_ok,
    display_table,
    display_warn,
)
from .storage import (
    CopyRecord,
    _key,
    has_skill,
    is_link_like,
    is_under,
    load_installs,
    load_lockfile,
    load_records,
    prune_installs,
)


_README_QI_RE = re.compile(r"^- \[([^\]]+)\]\(([^)]+)\)(?: — (.*))?$")


_README_FIELD_RE = re.compile(r"^- \*\*([^*]+):\*\* (.*)$")


_README_PATH_RE = re.compile(r"\]\(([^)]+)\)")


_README_LINK_RE = re.compile(r"(?<!!)\[[^\]]*\]\(([^)]+)\)")


def _squash(value: Any) -> str:
    return " ".join(str(value).split()) if isinstance(value, str) else ""


def _readme_path(target: str) -> str:
    """A README link target as a registry-relative posix path: decoded, no './', no anchor or title."""
    target = target.strip()
    if ' "' in target:
        target = target.split(' "', 1)[0]
    path = unquote(target.split("#", 1)[0]).replace("\\", "/").strip()
    while path.startswith("./"):
        path = path[2:]
    return path.lstrip("/")


def _path_key(path: str) -> str:
    return _readme_path(path).casefold()


def _resolve_readme_target(rel: str, base: str) -> str:
    """A cleaned (_readme_path'd) link target made registry-relative from a part's base dir."""
    return posixpath.normpath(posixpath.join(base, rel)) if base and rel else rel


def expected_catalog(registry: Path) -> dict[str, dict[str, Any]]:
    """rel SKILL.md path -> what the README must say about that skill."""
    dirs = walk_skills(registry, prune=False)
    catalog: dict[str, dict[str, Any]] = {}
    for path in dirs:
        rel = path.relative_to(registry)
        data, _ = read_frontmatter(path / "SKILL.md")
        data = data or {}
        ancestors = [other for other in dirs if other != path and is_under(path, other)]
        parent = max(ancestors, key=lambda p: len(p.parts)) if ancestors else None
        catalog[(rel / "SKILL.md").as_posix()] = {
            "dir": path,
            "name": data.get("name") if isinstance(data.get("name"), str) else path.name,
            "description": _squash(data.get("description")),
            "use_case": _squash(data.get("when_to_use")),
            "hint": _squash(data.get("argument-hint")),
            "category": rel.parts[1] if rel.parts[0] == "Groups" and len(rel.parts) > 2 else STANDALONE_CATEGORY,
            "parent": parent,
        }
    by_dir = {info["dir"]: info for info in catalog.values()}
    for info in catalog.values():
        info["parent_name"] = by_dir[info["parent"]]["name"] if info["parent"] in by_dir else None
        info["children"] = sorted(
            other["name"] for other in catalog.values() if other["parent"] == info["dir"]
        )
    return catalog


def readme_parts(registry: Path) -> list[tuple[str, str]] | None:
    """(base_dir, text) parts the catalog is parsed from, in order, or None if README is missing.

    The legacy layout keeps every catalog section inside README.md; the split
    layout keeps only the slim entry point there and carries Quick Index,
    Skill Details and Archive as files under _Docs/ (links rebased ../).
    """
    readme = registry / README_NAME
    if not readme.is_file():
        return None
    text = readme.read_text(encoding="utf-8", errors="replace")
    if "## Quick Index" in text:
        return [("", text)]
    parts = [("", text)]
    for name in DOCS_CATALOG_FILES:
        part = registry / DOCS_NAME / name
        if part.is_file():
            parts.append((DOCS_NAME, part.read_text(encoding="utf-8", errors="replace")))
    return parts


def parse_readme(text: str, base: str = "") -> dict[str, Any]:
    header, _, rest = text.partition("## Quick Index")
    quick, _, rest = rest.partition("## Skill Details")
    details_text, _, archive_text = rest.partition("## Archive")
    parsed: dict[str, Any] = {"header": header, "quick": [], "details": [], "archive": []}

    category = None
    for line in quick.splitlines():
        if line.startswith("### "):
            category = line[4:].strip()
        elif match := _README_QI_RE.match(line):
            parsed["quick"].append({"name": match[1], "path": _resolve_readme_target(_readme_path(match[2]), base), "summary": match[3] or "", "category": category})

    category, block = None, None
    for line in details_text.splitlines():
        if line.startswith("#### "):
            block = {"name": line[5:].strip().strip("`"), "category": category, "fields": {}, "base": base}
            parsed["details"].append(block)
        elif line.startswith("### "):
            category, block = line[4:].strip(), None
        elif block is not None and (match := _README_FIELD_RE.match(line)):
            block["fields"][match[1].strip()] = match[2].strip()

    for line in archive_text.splitlines():
        if match := _README_QI_RE.match(line):
            parsed["archive"].append({"name": match[1], "path": _resolve_readme_target(_readme_path(match[2]), base)})
    return parsed


def check_readme(registry: Path) -> list[tuple[str, str, str]]:
    """Return (skill, section, issue) rows where README.md/_Docs disagree with the skills on disk."""
    parts = readme_parts(registry)
    if parts is None:
        return [("-", "readme", f"{README_NAME} not found in {registry}")]
    issues: list[tuple[str, str, str]] = []
    legacy = len(parts) == 1 and "## Quick Index" in parts[0][1]
    if not legacy:
        for name in DOCS_CATALOG_FILES:
            if not (registry / DOCS_NAME / name).is_file():
                issues.append(("-", "readme", f"catalog file missing: {DOCS_NAME}/{name}"))
    header = parts[0][1].partition("## Quick Index")[0]
    if legacy:
        sub = parse_readme(parts[0][1])
    else:
        # _Docs carries the three sections in order; parse them as one flow.
        sub = parse_readme("\n".join(part_text for _, part_text in parts[1:]), DOCS_NAME)
    parsed: dict[str, Any] = {"header": header, "quick": sub["quick"], "details": sub["details"], "archive": sub["archive"]}
    catalog = expected_catalog(registry)

    archive_root = next(
        (registry / name for name in ("_Archive", "Archive") if (registry / name).is_dir()),
        registry / "Archive",
    )
    archived = sorted(
        (path / "SKILL.md").relative_to(registry).as_posix()
        for path in walk_skills(archive_root, prune=False)
    ) if archive_root.is_dir() else []
    standalone = sum(1 for info in catalog.values() if info["category"] == STANDALONE_CATEGORY)
    groups = len({info["category"] for info in catalog.values()} - {STANDALONE_CATEGORY})
    claims = [
        (r"Total active skills: \*\*(\d+)\*\*", len(catalog), "active skills"),
        (r"(\d+) standalone", standalone, "standalone skills"),
        (r"(\d+) topic groups", groups, "topic groups"),
        (r"(\d+) archived", len(archived), "archived skills"),
    ]
    for pattern, actual, label in claims:
        match = re.search(pattern, parsed["header"])
        if match is None:
            issues.append(("-", "header", f"no count of {label} (on disk: {actual})"))
        elif int(match[1]) != actual:
            issues.append(("-", "header", f"claims {match[1]} {label}, on disk: {actual}"))

    quick_by_path: dict[str, dict[str, Any]] = {}
    for entry in parsed["quick"]:
        if _path_key(entry["path"]) in quick_by_path:
            issues.append((entry["name"], "quick-index", f"listed twice ({entry['path']})"))
        quick_by_path[_path_key(entry["path"])] = entry
    details_by_path: dict[str, dict[str, Any]] = {}
    for block in parsed["details"]:
        match = _README_PATH_RE.search(block["fields"].get("Path", ""))
        if match is None:
            issues.append((block["name"], "details", "detail block has no Path link"))
            continue
        block["path"] = _resolve_readme_target(_readme_path(match[1]), block.get("base", ""))
        if _path_key(block["path"]) in details_by_path:
            issues.append((block["name"], "details", f"listed twice ({block['path']})"))
        details_by_path[_path_key(block["path"])] = block

    def check_case(name: str, section: str, listed: str, actual: str) -> None:
        if listed != actual:
            issues.append((name, section, f"path case differs: README has {listed}, disk has {actual}"))

    for rel, info in sorted(catalog.items()):
        name = info["name"]
        entry = quick_by_path.get(_path_key(rel))
        if info["parent"] is None:
            if entry is None:
                issues.append((name, "quick-index", f"missing ({rel})"))
            else:
                check_case(name, "quick-index", entry["path"], rel)
                if entry["category"] != info["category"]:
                    issues.append((name, "quick-index", f"under '{entry['category']}', expected '{info['category']}'"))
                if entry["name"] != name:
                    issues.append((name, "quick-index", f"listed as '{entry['name']}'"))
                summary = _squash(entry["summary"]).rstrip("…").rstrip()
                if summary and not info["description"].startswith(summary):
                    issues.append((name, "quick-index", "summary does not match the current description"))
        elif entry is not None:
            issues.append((name, "quick-index", f"nested under '{info['parent_name']}'; only top-level skills belong here"))

        block = details_by_path.get(_path_key(rel))
        if block is None:
            issues.append((name, "details", f"missing ({rel})"))
            continue
        check_case(name, "details", block["path"], rel)
        fields = block["fields"]
        if block["name"] != name:
            issues.append((name, "details", f"headed '{block['name']}'"))
        if block["category"] != info["category"]:
            issues.append((name, "details", f"under '{block['category']}', expected '{info['category']}'"))
        if _squash(fields.get("Description")) != info["description"]:
            issues.append((name, "details", "description differs from SKILL.md"))
        if _squash(fields.get("Use-case")) != info["use_case"]:
            issues.append((name, "details", "use-case differs from when_to_use"))
        usage = _squash(fields.get("Usage")).strip("`")
        expected_usage = f"/{name} {info['hint']}" if info["hint"] else ""
        if usage != expected_usage:
            issues.append((name, "details", "usage differs from argument-hint"))
        if (fields.get("Parent") or "").strip("`") != (info["parent_name"] or ""):
            issues.append((name, "details", f"parent should be '{info['parent_name'] or 'none'}'"))
        listed_children = sorted(part.strip().strip("`") for part in fields.get("Sub-skills", "").split(",") if part.strip())
        if listed_children != info["children"]:
            issues.append((name, "details", f"sub-skills should be {', '.join(info['children']) or 'none'}"))

    active_keys = {_path_key(rel) for rel in catalog}
    for key, entry in quick_by_path.items():
        if key not in active_keys:
            issues.append((entry["name"], "quick-index", f"stale entry: no active skill at {entry['path']}"))
    for key, block in details_by_path.items():
        if key not in active_keys:
            issues.append((block["name"], "details", f"stale entry: no active skill at {block['path']}"))

    listed_archive = {_path_key(entry["path"]): entry for entry in parsed["archive"]}
    archived_keys = {_path_key(rel): rel for rel in archived}
    for key, rel in archived_keys.items():
        entry = listed_archive.get(key)
        if entry is None:
            issues.append((Path(rel).parent.name, "archive", f"missing ({rel})"))
        else:
            check_case(entry["name"], "archive", entry["path"], rel)
    for key, entry in listed_archive.items():
        if key not in archived_keys:
            issues.append((entry["name"], "archive", f"stale entry: no archived skill at {entry['path']}"))

    reported = set(quick_by_path) | set(details_by_path) | set(listed_archive)
    scan = list(parts)
    docs_dir = registry / DOCS_NAME
    if docs_dir.is_dir():
        catalog_names = set(DOCS_CATALOG_FILES)
        for doc in sorted(docs_dir.glob("*.md")):
            if doc.name not in catalog_names:
                scan.append((DOCS_NAME, doc.read_text(encoding="utf-8", errors="replace")))
    for base, part_text in scan:
        for match in _README_LINK_RE.finditer(part_text):
            target = match[1].strip()
            if not target or target.startswith("#") or re.match(r"^[a-z][a-z0-9+.-]*:", target, re.I):
                continue
            rel = _resolve_readme_target(_readme_path(target), base)
            if _path_key(rel) not in reported and not (registry / rel).exists():
                issues.append(("-", "links", f"broken link: {DOCS_NAME}/{target}" if base == DOCS_NAME else f"broken link: {target}"))
    return issues


_HINT_INTERFACE_RE = re.compile(r"\b(?:sub-?)?(?:commands?|modes?)\b", re.I)


_HINT_NOISE_RE = re.compile(r"\b(?:than|via|without|needs?|need|step|why|adding|every|each)\b", re.I)


_HINT_ENUM_RE = re.compile(
    r"\b(?:one|two|three|four|five|six|both|several)\s+(?:distinct\s+)?(?:sub-?)?(?:commands?|modes?)\b",
    re.I)


_HINT_MODE_LETTER_RE = re.compile(r"\b[Mm]odes?\s+[A-Z]\b")


_HINT_COLON_LABEL_RE = re.compile(r"^\s*[-*]?\s*\**\s*(?:sub-?)?(?:commands?|modes?)\s*:\**", re.M | re.I)


def lint_skill_dirs(
    registry: Path,
    extra_roots: Sequence[Path],
    records: Iterable[CopyRecord],
    remote_roots: Sequence[tuple[Path, str]] = (),
) -> list[tuple[str, Path, str]]:
    seen: dict[str, tuple[str, Path, str]] = {}

    def add(name: str, path: Path, label: str) -> None:
        if not has_skill(path):
            return
        key = os.path.normcase(os.path.realpath(path))
        seen.setdefault(key, (name, path, label))

    for record in records:
        if record.kind == "dir":
            add(record.skill, Path(record.target), "hard-copy")
    for path in walk_skills(registry, prune=False):
        add(path.name, path, "registry")
    roots = [(agent_skill_dir(agent), f"agent:{agent}") for agent in agent_names()]
    roots.extend((root, f"into:{root}") for root in extra_roots)
    roots.extend(remote_roots)
    for root, label in roots:
        if not root.is_dir():
            continue
        add(root.name, root, label)
        for path in walk_skills(root, prune=False):
            add(path.name, path, label)
        for path in sorted(root.iterdir()):
            if is_link_like(path) and has_skill(path):
                add(path.name, path, label)
                for nested in walk_skills(path, prune=False):
                    add(nested.name, nested, label)
    return list(seen.values())


def command_surface_evidence(skill_md: Path, name: str) -> str:
    """Evidence that a skill presents user-facing commands or modes; '' when none.

    Strong (fires alone): an interface heading naming commands/modes, or use of the
    skill's own slash address with an argument (`/name <thing>`). Weak (two needed):
    enumeration of N commands/modes, Mode A/Mode B letters, bold Commands:/Modes: labels.
    Prose vocabulary ("dark mode", "shell commands", doc-outline headings) never counts:
    the signals are structural - headings, self-slash usage, explicit enumerations.
    """
    try:
        text = skill_md.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return ""
    body = text.split("---", 2)[2] if text.count("---") >= 2 else text
    strong: list[str] = []
    weak = 0
    for line in body.splitlines():
        title = re.match(r"^\s{0,3}#{1,6}\s+(.+?)\s*$", line)
        if title:
            words = re.findall(r"[\w'’.-]+", title.group(1))
            if (len(words) <= 7
                    and not (re.match(r"^\d+[.)]\s", title.group(1)) and len(words) >= 5)
                    and _HINT_INTERFACE_RE.search(title.group(1))
                    and not _HINT_NOISE_RE.search(title.group(1))):
                strong.append(f'heading "{title.group(1)}"')
    for pat, label, kind in (
        (re.compile(rf"(?:^|[\s|`(])/{''.join(re.escape(c) for c in name)}(?=\s+[^\s`])[^`\n]*`?"),
         "self-slash usage", "strong"),
        (_HINT_ENUM_RE, "command/mode enumeration", "weak"),
        (_HINT_MODE_LETTER_RE, None, "weak"),
        (_HINT_COLON_LABEL_RE, "commands/modes label", "weak"),
    ):
        hits = pat.findall(body)
        if not hits:
            continue
        if kind == "strong":
            strong.append(f"{label} x{len(hits)}")
        elif label is None:
            letters = {h.split()[-1].upper() for h in hits}
            if len(letters) >= 2:
                strong.append(f"mode letters {sorted(letters)}")
        else:
            weak += 1
    if strong:
        return "; ".join(strong[:3])
    return f"enumeration+label x{weak}" if weak >= 2 else ""


def specialized_problem(data: dict[str, Any]) -> str | None:
    if "specialized" not in data or data["specialized"] is None:
        return "missing specialized (one technology, or none)"
    value = data["specialized"]
    items = [item.strip() for item in value.split(",")] if isinstance(value, str) else []
    if (not items or any(not SPECIALIZED_RE.fullmatch(item) or item in SPECIALIZED_REJECTED
                         for item in items)
            or (len(items) > 1 and SPECIALIZED_GENERAL in items)):
        return (f"invalid specialized {value!r} (one lowercase technology such as "
                f"'scss' or 'react-native', or '{SPECIALIZED_GENERAL}')")
    if len(items) > 1:
        return f"specialized lists {len(items)} technologies; prefer one per skill"
    canonical = SPECIALIZED_ALIASES.get(items[0])
    if canonical:
        return f"specialized {items[0]!r} is an alias; use {canonical!r}"
    return None


def skill_size(path: Path) -> tuple[int, bool]:
    """SKILL.md line count and whether the skill is nothing but that file."""
    try:
        files = list(iter_files(path))
    except OSError:
        return 0, False
    solo = len(files) == 1 and files[0].name == "SKILL.md"
    try:
        text = (path / "SKILL.md").read_text(encoding="utf-8", errors="replace")
    except OSError:
        return 0, solo
    return len(text.splitlines()), solo


def lint_acceptances(data: dict[str, Any] | None) -> tuple[dict[str, str], list[str]]:
    """Parse `lint-accept` (rule id -> reason). Returns (accepted, problems)."""
    raw = (data or {}).get("lint-accept")
    if raw is None:
        return {}, []
    if not isinstance(raw, dict):
        return {}, ["lint-accept must be a mapping of rule id to reason"]
    accepted: dict[str, str] = {}
    problems: list[str] = []
    for rule, reason in raw.items():
        if rule not in LINT_RULE_IDS:
            problems.append(f"lint-accept names unknown rule '{rule}'")
        elif not isinstance(reason, str) or not reason.strip():
            problems.append(f"lint-accept for '{rule}' needs a non-empty reason")
        else:
            accepted[rule] = reason.strip()
    return accepted, problems


def _collect_lint_state(
    args: argparse.Namespace,
    registry: Path,
    jobs: int,
    issues: Sequence[SyncIssue],
) -> dict[str, Any]:
    """Run all lint analyzers and return structured warnings, findings, and metrics."""
    limit = args.max_description
    extra_roots = [resolve_into(value) for value in (args.into or [])]
    remote_roots: list[tuple[Path, str]] = []
    if getattr(args, "remote", False):
        for info in remotes_all().values():
            root = remote_root(info)
            if root is not None:
                remote_roots.append((root, f"remote:{info['name']}"))
            else:
                display_warn(
                    f"remote '{info['name']}' is not fetched yet; skipped "
                    "(run `manager.py remote --update`)"
                )
    records = list(load_records(registry).values())
    skills = lint_skill_dirs(registry, extra_roots, records, remote_roots)
    if not skills:
        display_warn(f"no SKILL.md files found in {registry} or the configured skill folders")

    frontmatters = map_concurrent(
        lambda item: read_frontmatter(item[1] / "SKILL.md"), skills, jobs
    )
    sizes = map_concurrent(lambda item: skill_size(item[1]), skills, jobs)
    warnings: list[tuple[str, str, Path, int | None, str]] = []
    accepted: list[tuple[str, str, Path, str, str, str]] = []
    checked_rows: list[list[str]] = []
    registry_names: dict[str, Path] = {}
    type_counts: Counter[str] = Counter()
    tracked_paths = set(registry_skills(registry).values())
    total_checked = 0

    from .fixer import LintFinding

    findings: list[LintFinding] = []
    if yaml is None:
        warnings.append(("-", "environment", registry, None, "YAML validation unavailable; install PyYAML for full validation"))

    for (name, path, label), (data, error), (lines, solo) in zip(skills, frontmatters, sizes):
        total_checked += 1
        structure = inspect_directory(path)
        skill_type = SKILL_TYPES[structure.kind]
        type_counts[structure.kind] += 1
        accept, accept_problems = lint_acceptances(data)

        def emit(rule: str, reason: str, length: int | None = None, *, extra: dict[str, Any] | None = None) -> None:
            if rule in accept:
                accepted.append((name, label, path, reason, rule, accept[rule]))
            else:
                warnings.append((name, label, path, length, reason))
                findings.append(LintFinding(
                    rule=rule,
                    category="version" if rule.startswith("version-") else "metadata",
                    target_name=name,
                    path=path,
                    detail=reason,
                    location=label,
                    extra=extra or {},
                ))

        if accept_problems:
            for problem in accept_problems:
                warnings.append((name, label, path, None, problem))
            findings.append(LintFinding(
                rule="lint-accept",
                category="metadata",
                target_name=name,
                path=path,
                detail="; ".join(accept_problems),
                location=label,
            ))

        for issue in structure.issues:
            emit("mixed-composition", issue)
        if data is not None and not args.no_version and path not in tracked_paths:
            version = _norm_version(data.get("version"))
            if version is None:
                emit("version-missing", "missing or invalid version (expected semver X.Y.Z)", extra={"version": ""})
            elif SEMVER_RE.fullmatch(version) is None:
                emit("version-invalid", "missing or invalid version (expected semver X.Y.Z)", extra={"version": version})
        if data is None:
            emit("frontmatter", error or "missing frontmatter")
            checked_rows.append([name, skill_type, label, "missing", "missing", str(path)])
            continue
        if label == "registry":
            problem = specialized_problem(data)
            if problem:
                emit("specialized", problem)
            if not solo and lines >= SKILL_LENGTH_LIMIT:
                emit(
                    "skill-length",
                    f"SKILL.md has {lines} lines (limit {SKILL_LENGTH_LIMIT}); "
                    "split depth into references/ or modules",
                )
            if not str(data.get("argument-hint") or "").strip():
                evidence = command_surface_evidence(
                    path / "SKILL.md", str(data.get("name") or path.name)
                )
                if evidence:
                    emit(
                        "argument-hint",
                        f"presents commands/modes ({evidence}); declare argument-hint",
                    )
        skill_name = data.get("name")
        if not isinstance(skill_name, str) or not re.fullmatch(r"[a-z0-9-]+", skill_name):
            emit("name", "missing or invalid name (use lowercase letters, digits and hyphens)")
        else:
            if skill_name != path.name:
                emit("name-mismatch", f"name '{skill_name}' does not match folder '{path.name}'")
            if label == "registry":
                previous = registry_names.setdefault(skill_name, path)
                if previous != path:
                    emit("duplicate-name", f"duplicate name '{skill_name}' also at {previous}")
        description = data.get("description")
        if not isinstance(description, str) or not description.strip():
            emit("description", "missing description")
            checked_rows.append([name, skill_type, label, "missing", "missing", str(path)])
            continue
        if "\n" in description.strip() or "\r" in description.strip():
            emit("description-multiline", "description must be a single-line string")
        length = len(description)
        state = "over" if length > limit else "ok"
        checked_rows.append([name, skill_type, label, str(length), state, str(path)])
        if length > limit:
            emit("description-length", "over limit", length)

    version_warnings: list[tuple[str, str, str, str, str]] = []
    version_stats: Counter = Counter()
    if not args.no_version:
        version_warnings, version_stats = check_versions(registry, jobs)
        for n, ver, sugg, reason, rel in version_warnings:
            if reason == "missing version":
                v_rule = "version-missing"
            elif reason.startswith("invalid version"):
                v_rule = "version-invalid"
            else:
                v_rule = "version-unbumped"
            findings.append(LintFinding(
                rule=v_rule,
                category="version",
                target_name=n,
                path=registry / rel,
                detail=reason,
                location="registry",
                extra={"version": "" if ver == "-" else ver, "suggested": sugg, "rel": rel},
            ))

    for issue in issues:
        findings.append(LintFinding(
            rule=issue.state,
            category="sync",
            target_name=issue.skill,
            path=Path(issue.target),
            detail=issue.detail,
            location=issue.kind,
            extra={"issue": issue},
        ))

    readme_issues = check_readme(registry) if args.readme else []
    for r_skill, r_section, r_issue in readme_issues:
        if r_section == "header":
            findings.append(LintFinding(
                rule="readme-counts",
                category="readme",
                target_name=r_skill,
                path=registry / README_NAME,
                detail=r_issue,
                location="readme",
            ))

    return {
        "limit": limit,
        "extra_roots": extra_roots,
        "records": records,
        "warnings": warnings,
        "accepted": accepted,
        "checked_rows": checked_rows,
        "type_counts": type_counts,
        "total_checked": total_checked,
        "version_warnings": version_warnings,
        "version_stats": version_stats,
        "issues": list(issues),
        "readme_issues": readme_issues,
        "findings": findings,
    }


def cmd_lint(args: argparse.Namespace, registry: Path, jobs: int, issues: Sequence[SyncIssue]) -> int:
    from .fixer import (
        apply_lint_fixes,
        display_fix_catalog,
        parse_fix_styles,
        parse_rule_filter,
    )

    if getattr(args, "list_fixes", False):
        display_fix_catalog()
        return 0

    limit = args.max_description
    if limit <= 0:
        raise ManagerError("--max-description must be a positive number")

    do_fix = bool(getattr(args, "fix", False))
    allow_unsafe = bool(getattr(args, "unsafe", False))
    dry_run = bool(getattr(args, "dry_run", False))
    no_backup = bool(getattr(args, "no_backup", False))
    raw_styles = getattr(args, "fix_style", None)
    raw_only = getattr(args, "only", None)
    raw_skip = getattr(args, "skip_fix", None)

    if allow_unsafe and not do_fix:
        raise ManagerError("--unsafe requires --fix")
    if (raw_styles or raw_only or raw_skip or dry_run) and not do_fix:
        raise ManagerError("--fix-style, --only, --skip-fix, and --dry-run require --fix")

    style_overrides = parse_fix_styles(raw_styles) if do_fix else {}
    only_rules = parse_rule_filter(raw_only, "--only") if do_fix else set()
    skip_rules = parse_rule_filter(raw_skip, "--skip-fix") if do_fix else set()

    state = _collect_lint_state(args, registry, jobs, issues)

    if do_fix:
        outcomes = apply_lint_fixes(
            state["findings"],
            registry=registry,
            unsafe=allow_unsafe,
            dry_run=dry_run,
            no_backup=no_backup,
            style_overrides=style_overrides,
            only_rules=only_rules,
            skip_rules=skip_rules,
            description_limit=limit,
        )
        applied_count = sum(1 for o in outcomes if o.status == "fixed")
        if applied_count and not dry_run:
            # Re-run checks so the tables & --strict exit status reflect post-fix reality
            fresh_issues = audit_all(registry, agent_names(), jobs)
            state = _collect_lint_state(args, registry, jobs, fresh_issues)

    warnings = state["warnings"]
    accepted = state["accepted"]
    checked_rows = state["checked_rows"]
    type_counts = state["type_counts"]
    total_checked = state["total_checked"]
    version_warnings = state["version_warnings"]
    version_stats = state["version_stats"]
    current_issues = state["issues"]
    readme_issues = state["readme_issues"]
    extra_roots = state["extra_roots"]
    records = state["records"]

    if version_warnings:
        display_table(
            ["Skill", "Version", "Suggested bump", "Reason", "Path"],
            [[n, ver, sugg, reason, str(registry / rel / "SKILL.md")]
             for n, ver, sugg, reason, rel in version_warnings],
            title=f"version warnings ({len(version_warnings)})",
            always=True,
        )
    if _DISPLAY.verbose and version_stats:
        display_kv(
            [(k, str(v)) for k, v in sorted(version_stats.items())],
            title="version tracking", always=True,
        )

    if warnings:
        rows = []
        for name, label, path, length, reason in warnings:
            rows.append([name, label, str(length) if length is not None else "-", reason, str(path / "SKILL.md")])
        display_table(
            ["Skill", "Location", "Chars", "Issue", "Path"],
            rows,
            title=f"skill warnings ({len(warnings)})",
            always=True,
        )
    if _DISPLAY.verbose and accepted:
        display_table(
            ["Skill", "Location", "Rule", "Finding", "Accepted because"],
            [[n, lab, rule, reason, why] for n, lab, _p, reason, rule, why in accepted],
            title=f"accepted findings ({len(accepted)})",
            always=True,
        )
    if _DISPLAY.verbose and checked_rows:
        display_table(
            ["Skill", "Type", "Location", "Chars", "State", "Path"],
            checked_rows,
            title="all checked skills",
            always=True,
        )
    if current_issues:
        display_table(
            ["Skill", "State", "Target", "Detail"],
            [[issue.skill, issue.state, issue.target, issue.detail] for issue in current_issues],
            title=f"synchronization issues ({len(current_issues)})",
            always=True,
        )
    if readme_issues:
        display_table(
            ["Skill", "Section", "Issue"],
            [list(row) for row in readme_issues],
            title=f"README issues ({len(readme_issues)})",
            always=True,
        )

    hard_copies = sum(1 for record in records if record.kind == "dir")
    summary = [
        ("Registry", str(registry)),
        ("Roots scanned", str(1 + len(extra_roots) + sum(
            1 for agent in agent_names() if agent_skill_dir(agent).is_dir()
        ))),
        ("SKILL.md files checked", str(total_checked)),
        *[(title, str(type_counts[kind])) for kind, title in SKILL_TYPES.items()],
        ("Hard copies tracked", str(hard_copies)),
        ("Skill warnings", str(len(warnings))),
        ("Accepted findings", str(len(accepted))),
        ("Synchronization issues", str(len(current_issues))),
    ]
    if args.readme:
        summary.append(("README issues", str(len(readme_issues))))
    if not args.no_version:
        summary.append(("Version warnings", str(len(version_warnings))))
    summary.append(("Description limit", f"{limit} characters"))
    display_kv(summary, title="lint summary", always=True)

    # Note: do not treat the PyYAML advisory line as a fixable failure unless real findings remain
    real_warnings = [w for w in warnings if w[1] != "environment"]
    if not warnings and not current_issues and not readme_issues and not version_warnings:
        tail = " and README.md matches the registry" if args.readme else ""
        display_ok(
            f"all {total_checked} SKILL.md files passed metadata checks and no synchronization issues were found{tail}"
        )
    elif not do_fix and (real_warnings or current_issues or version_warnings or readme_issues):
        display_info(
            "tip: run `python manager.py lint --fix` for safe fixes, `--fix --unsafe` for all fixes, "
            "or `lint --list-fixes` to inspect styles"
        )

    return 1 if (args.strict and (warnings or current_issues or readme_issues or version_warnings)) else 0


def cmd_report(args: argparse.Namespace, registry: Path, jobs: int) -> int:
    roots: list[tuple[str, Path]] = [("", registry)]
    if getattr(args, "remote", False):
        for info in remotes_all().values():
            root = remote_root(info)
            if root is None:
                display_warn(f"remote '{info['name']}' is not fetched yet; skipped "
                             "(run `manager.py remote --update`)")
                continue
            roots.append((f"remote:{info['name']}/", root))

    wanted = set(args.skills)
    missing = set(wanted)
    rows: list[dict[str, Any]] = []
    counted_files: set[Path] = set()
    heads: list[tuple[str, str | None]] = []
    for prefix, base in roots:
        inventory = walk_skills(base, prune=False)
        if prefix and has_skill(base):
            inventory.insert(0, base)
        paths = [p for p in inventory if p.name in wanted] if wanted else list(inventory)
        for path in paths:
            missing.discard(path.name)
        status_map = git_status_map(base)
        head = git_head(base)
        heads.append((prefix.rstrip("/") or "registry", head))
        frontmatters = map_concurrent(lambda path: read_frontmatter(path / "SKILL.md"), paths, jobs)
        snaps = map_concurrent(skill_snapshot, paths, jobs)
        for path, (data, _err), snap in zip(paths, frontmatters, snaps):
            ver, desc_len = "-", 0
            if isinstance(data, dict):
                v = data.get("version")
                ver = str(v) if v is not None else "-"
                d = data.get("description")
                desc_len = len(d) if isinstance(d, str) else 0
            structure = inspect_directory(path)
            parent = skill_parent(path, inventory)
            rel = path.relative_to(base).as_posix()
            counted_files.update(path / name for name in snap["files"])
            row = {
                "name": path.name, "type": structure.kind,
                "parent": parent.relative_to(base).as_posix() if parent else None,
                "children": [child.relative_to(path).as_posix() for child in structure.children],
                "modules": [module.relative_to(path).as_posix() for module in structure.modules],
                "issues": list(structure.issues),
                "version": ver, "files": snap["file_count"], "desc": desc_len,
                "solo": snap["file_count"] == 1 and "SKILL.md" in snap["files"],
                "git": skill_git_state(rel, status_map), "path": prefix + rel,
            }
            if _DISPLAY.verbose:
                row["last_commit"] = git_last_commit(base, rel) or "-"
            rows.append(row)
    if wanted:
        for name in sorted(missing):
            display_warn(f"no {'registry or remote ' if len(roots) > 1 else 'registry '}skill named '{name}'")
    head = heads[0][1] if heads else None
    sort_key = args.sort
    rows.sort(key=lambda r: r[sort_key] if sort_key != "name" else r["name"].lower(),
              reverse=args.reverse)
    type_counts = {kind: sum(row["type"] == kind for row in rows) for kind in SKILL_TYPES}
    if args.json:
        print(json.dumps({"registry": str(registry), "head": head, "skills": rows,
                          "types": type_counts, "total_files": len(counted_files),
                          "remote_heads": {label: h for label, h in heads[1:]}}, indent=2))
        return 0
    headers = ["Skill", "Type", "Parent", "Version", "Files", "SKILL.md only", "Desc chars", "Git", "Path"]
    table_rows = [[r["name"], SKILL_TYPES[r["type"]], r["parent"] or "-", r["version"],
                   str(r["files"]), "yes" if r["solo"] else "-", str(r["desc"]), r["git"], r["path"]]
                  for r in rows]
    if _DISPLAY.verbose:
        headers.append("Last commit")
        for r, tr in zip(rows, table_rows):
            tr.append(r.get("last_commit", "-"))
    display_table(headers, table_rows, title=f"skill report ({len(rows)})", always=True)
    display_table(["Skill", "Issue"], [[r["path"], issue] for r in rows for issue in r["issues"]],
                  title="composition warnings", always=True)
    avg_desc = round(sum(r["desc"] for r in rows) / len(rows)) if rows else 0
    summary = [
        ("Skills", str(len(rows))),
        *[(title, str(type_counts[kind])) for kind, title in SKILL_TYPES.items()],
        ("Total files (unique)", str(len(counted_files))),
        ("Solo SKILL.md skills", str(sum(1 for r in rows if r["solo"]))),
        ("Avg description chars", str(avg_desc)),
        ("Sorted by", f"{sort_key}{' (desc)' if args.reverse else ' (asc)'}"),
        ("Git HEAD", head or "-"),
        *[("Git HEAD " + label, h or "-") for label, h in heads[1:]],
    ]
    display_kv(summary, title="report summary", always=True)
    return 0


def cmd_find(args: argparse.Namespace, registry: Path, jobs: int) -> int:
    removed = prune_installs(registry)
    if removed:
        display_info(f"[installs] pruned {len(removed)} stale --into record(s)")
    locked = load_lockfile(registry).get("locked", {})
    locations: list[tuple[str, Path]] = []
    structures: dict[Path, SkillStructure] = {}

    def structure(path: Path) -> SkillStructure:
        if path not in structures:
            structures[path] = inspect_directory(path)
        return structures[path]

    def add_tree(label: str, root: Path, include_root: bool = True) -> None:
        paths = walk_skills(root, prune=False)
        if include_root:
            paths.insert(0, root)
        for path in paths:
            locations.append((label, path))
            for module in structure(path).modules:
                locations.append((label, module))
            for parent in path.parents:
                if parent == root or not is_under(parent, root):
                    break
                locations.append((label, parent))

    add_tree("registry", registry, include_root=False)
    for agent in agent_names():
        directory = agent_skill_dir(agent)
        if directory.is_dir():
            for entry in sorted(directory.iterdir()):
                if entry.is_dir() or is_link_like(entry):
                    add_tree(f"agent:{agent}", entry)
    for entry in load_installs(registry).get("into", {}).values():
        add_tree("into (recorded)", Path(entry["target"]))
    if getattr(args, "remote", False):
        for info in remotes_all().values():
            root = remote_root(info)
            if root is None:
                display_warn(f"remote '{info['name']}' is not fetched yet; skipped "
                             "(run `manager.py remote --update`)")
                continue
            add_tree(f"remote:{info['name']}", root)

    found_any = False
    for item in dict.fromkeys(args.skills):
        candidate = Path(os.path.abspath(Path(item).expanduser()))
        explicit = candidate.is_dir() or is_link_like(candidate)
        name = candidate.name if explicit else item
        matches = [(label, path) for label, path in locations if path.name == name]
        if explicit:
            matches.append(("path argument", candidate))
        rows: list[list[str]] = []
        seen: set[str] = set()
        for label, path in matches:
            key = _key(path)
            if key in seen:
                continue
            seen.add(key)
            info = structure(path)
            kind = SKILL_TYPES.get(info.kind, info.kind)
            notes: list[str] = []
            parent = skill_parent(path, (p for p in path.parents if has_skill(p)))
            if info.kind in SKILL_TYPES:
                if parent:
                    notes.append(f"sub-skill of {parent.name}")
                if info.children:
                    notes.append(f"{len(info.children)} independent sub-skill(s)")
                if info.modules:
                    notes.append(f"{len(info.modules)} internal module(s), not independent")
            elif info.kind == "group":
                notes.append(f"not a skill; holds {len(info.children)} skill(s)")
            elif info.kind == "plain":
                if parent and path in structure(parent).modules:
                    notes.append(f"internal module of {parent.name}; not an independent skill")
                else:
                    notes.append("no SKILL.md; not a skill")
            else:
                notes.append("BROKEN link; no live skill verified")
            if is_link_like(path):
                link_kind = "symlink" if path.is_symlink() else "junction"
                notes.append(f"{link_kind} -> {os.path.realpath(path)}")
            elif label.startswith("agent:") and info.kind in SKILL_TYPES:
                notes.append("hard copy")
            notes.extend(info.issues)
            shown = path.relative_to(registry).as_posix() if is_under(path, registry) else str(path)
            rows.append([label, kind, shown, "; ".join(notes)])
        if name in locked:
            rows.append(["database", "lock record", ", ".join(sorted(locked[name])),
                         "record only; not proof of a live skill"])
        if rows:
            found_any = True
            display_table(["Where", "Type", "Path", "Note"], rows,
                          title=f"find: {item} ({len(rows)} match(es))", always=True)
        else:
            display_warn(f"find: '{item}' not in the registry, agent folders, or recorded --into installs")
    return 0 if found_any else 1


def scan_crossreferences(registry: Path, skills: Sequence[Path]) -> dict[str, Any]:
    index: dict[str, list[Path]] = {}
    for skill in skills:
        index.setdefault(skill.name.casefold(), []).append(skill)
    skill_set = set(skills)
    owners: dict[Path, Path | None] = {}
    edges: dict[tuple[Path, Path], dict[str, Any]] = {}
    ambiguous: dict[tuple[Path, str], dict[str, Any]] = {}
    errors: list[dict[str, str]] = []
    files_scanned = characters_scanned = 0

    def walk_error(error: OSError) -> None:
        errors.append({"file": str(error.filename), "error": str(error)})

    for dirpath, dirnames, filenames in os.walk(registry, onerror=walk_error):
        directory = Path(dirpath)
        dirnames[:] = sorted(name for name in dirnames
                             if name not in SKIP_NAMES and not name.startswith(".")
                             and not is_link_like(directory / name))
        owner = directory if directory in skill_set else owners.get(directory.parent)
        owners[directory] = owner
        if owner is None:
            continue
        source = owner.relative_to(registry).as_posix()
        owner_name = owner.name.casefold()
        for filename in sorted(filenames):
            path = directory / filename
            if filename.startswith(".") or path.suffix.lower() not in REFERENCE_SUFFIXES or is_link_like(path):
                continue
            relative = path.relative_to(registry).as_posix()
            try:
                with path.open(encoding="utf-8-sig") as stream:
                    for line_number, line in enumerate(stream, 1):
                        characters_scanned += len(line)
                        seen: set[str] = set()
                        for match in REFERENCE_TOKEN_RE.finditer(line):
                            name = match.group().casefold()
                            if name in seen or name == owner_name:
                                continue
                            seen.add(name)
                            targets = index.get(name)
                            if not targets:
                                continue
                            start = max(0, match.start() - 80)
                            end = max(start + 240, match.end())
                            evidence = {"file": relative, "line": line_number,
                                        "text": line[start:end].strip()}
                            if len(targets) > 1:
                                key = (owner, name)
                                if key not in ambiguous:
                                    ambiguous[key] = {
                                        "source": source, "name": name,
                                        "candidates": [p.relative_to(registry).as_posix() for p in targets],
                                        "evidence": [],
                                    }
                                record = ambiguous[key]
                            else:
                                target = targets[0]
                                edge_key = (owner, target)
                                if edge_key not in edges:
                                    edges[edge_key] = {
                                        "from": owner.name, "to": target.name, "source": source,
                                        "target": target.relative_to(registry).as_posix(), "evidence": [],
                                    }
                                record = edges[edge_key]
                            record["evidence"].append(evidence)
                files_scanned += 1
            except (OSError, UnicodeError) as error:
                errors.append({"file": relative, "error": str(error)})

    for (source, target), edge in edges.items():
        edge["mutual"] = (target, source) in edges
        edge["count"] = len(edge["evidence"])
    return {
        "edges": sorted(edges.values(), key=lambda edge: (edge["source"], edge["target"])),
        "ambiguous": sorted(ambiguous.values(), key=lambda item: (item["source"], item["name"])),
        "errors": errors,
        "stats": {"skills": len(skills), "files_scanned": files_scanned,
                  "characters_scanned": characters_scanned, "edges": len(edges)},
    }


def cmd_crossreference(args: argparse.Namespace, registry: Path) -> int:
    result = scan_crossreferences(registry, walk_skills(registry, prune=False))
    result["registry"] = str(registry)
    if args.json:
        print(json.dumps(result, indent=2))
    else:
        rows = []
        for edge in result["edges"]:
            first = edge["evidence"][0]
            rows.append([edge["from"], edge["to"], str(edge["count"]),
                         "yes" if edge["mutual"] else "no", f"{first['file']}:{first['line']}"])
        display_table(["From", "To", "Mention lines", "Mutual", "First evidence"], rows,
                      title="skill crossreferences (textual mentions, not proven dependencies)", always=True)
        if _DISPLAY.verbose:
            display_table(["From", "To", "Evidence", "Text"],
                          [[edge["from"], edge["to"], f"{item['file']}:{item['line']}", item["text"]]
                           for edge in result["edges"] for item in edge["evidence"]],
                          title="reference evidence", always=True)
        display_table(["Source", "Ambiguous name", "Candidates"],
                      [[item["source"], item["name"], ", ".join(item["candidates"])]
                       for item in result["ambiguous"]], title="ambiguous references", always=True)
        display_table(["File", "Read error"],
                      [[item["file"], item["error"]] for item in result["errors"]],
                      title="incomplete scan", always=True)
        display_kv([(key.replace("_", " "), value) for key, value in result["stats"].items()],
                   title="crossreference summary", always=True)
    return 1 if result["errors"] or result["ambiguous"] else 0
