"""Shared constants, regular expressions, exceptions, and optional dependencies.

All other modules inside ``manager_pkg`` import shared configuration from here
so constants and optional dependency probes live in one canonical place.
"""

from __future__ import annotations

import re
from pathlib import Path
from typing import Any

__version__ = "2.14.0"

# ---------------------------------------------------------------------------
# Optional third-party dependencies
# ---------------------------------------------------------------------------

try:  # rich provides styled tables, panels, rules, and Live redraws
    from rich import box as rich_box
    from rich.console import Console
    from rich.live import Live
    from rich.panel import Panel
    from rich.rule import Rule
    from rich.table import Table
    from rich.text import Text

    RICH_AVAILABLE = True
except Exception:  # pragma: no cover - exercised only without rich
    Console = None  # type: ignore[assignment]
    Live = None  # type: ignore[assignment]
    Panel = None  # type: ignore[assignment]
    Rule = None  # type: ignore[assignment]
    Table = None  # type: ignore[assignment]
    Text = None  # type: ignore[assignment]
    rich_box = None  # type: ignore[assignment]
    RICH_AVAILABLE = False

try:  # PyYAML parses every frontmatter shape; minimal fallback exists without it
    import yaml
except Exception:  # pragma: no cover
    yaml = None  # type: ignore[assignment]


# ---------------------------------------------------------------------------
# Limits, schemas, and pattern constants
# ---------------------------------------------------------------------------

DEFAULT_DESCRIPTION_LIMIT = 1024
DEFAULT_TABLE_ROW_LIMIT = 40
SKILL_LENGTH_LIMIT = 200
INITIAL_VERSION = "1.0.0"

SEMVER_RE = re.compile(r"^\d+\.\d+\.\d+(?:[-+][0-9A-Za-z.-]+)?$")
SPECIALIZED_GENERAL = "none"
SPECIALIZED_RE = re.compile(r"[a-z0-9][a-z0-9.+#-]*")
SPECIALIZED_REJECTED = {"general", "generic", "any", "all"}
SPECIALIZED_ALIASES = {
    "tailwindcss": "tailwind", "tw": "tailwind",
    "react native": "react-native", "rn": "react-native",
    "nextjs": "next.js",
    "vuejs": "vue", "vue.js": "vue",
    "nodejs": "node.js", "node": "node.js",
    "ts": "typescript", "js": "javascript",
    "postgres": "postgresql",
    "mmd": "mermaid", "gh": "github",
    "windows": "win32", "winapi": "win32",
    ".net": "dotnet", "csharp": "c#",
}
LINT_RULE_IDS = {
    "mixed-composition", "frontmatter", "version", "specialized",
    "name", "name-mismatch", "duplicate-name",
    "description", "description-multiline", "description-length",
    "skill-length", "argument-hint",
}

DB_APP_DIR = "insource-manager"
DB_FILE_NAME = "manager.db"
LEGACY_STORE_FILES = {
    "copies": "manager-copies.json",
    "lock": "skills-lock.json",
    "versions": "manager-versions.json",
}
SKIP_NAMES = {
    "Archive", "_Archive", "_Resources", "__pycache__",
    "node_modules", ".git", ".venv", "venv",
}
AGENT_SOURCE = Path("_Resources") / "AGENTS.md"
VIBER_MANIFEST = Path("../../projects/viber/viber.json")
README_NAME = "README.md"
DOCS_NAME = "_Docs"
DOCS_CATALOG_FILES = ("quick-index.md", "skill-details.md", "archive.md")
STANDALONE_CATEGORY = "Standalone (repository root)"
REFERENCE_SUFFIXES = {".md", ".mdx", ".txt", ".rst"}
REFERENCE_TOKEN_RE = re.compile(r"[\w-]+")
SKILL_SUPPORT_DIRS = {
    "reference", "references", "examples", "assets", "scripts", "templates",
    "research", "docs", "tests", "evals", "fixtures", "data", "resources", "legacy",
}
SKILL_TYPES = {"skill": "Skill", "meta-skill": "Meta-Skill", "battery-skill": "Battery-Skill"}
MIGRATION_AGENTS = {"qoder", "gemini"}

AGENT_SKILL_SUBDIRS: dict[str, Path] = {
    "qoder": Path(".qoder") / "skills",
    "junie": Path(".junie") / "skills",
    "gemini": Path(".gemini") / "config" / "skills",
    "opencode": Path(".config") / "opencode" / "skills",
    "claude": Path(".claude") / "skills",
}

AGENT_MD_SUBDIRS: dict[str, list[Path]] = {
    "qoder": [Path(".qoder") / "agents.md"],
    "gemini": [
        Path(".gemini") / "AGENTS.md",
        Path(".gemini") / "antigravity" / "AGENTS.md",
        Path(".gemini") / "antigravity" / "global_rules.md",
    ],
    "claude": [Path(".claude") / "CLAUDE.md", Path(".claude") / "agents.md"],
    "junie": [Path(".junie") / "agents.md"],
    "opencode": [Path(".config") / "opencode" / "AGENTS.md"],
}

ALIASES = {
    "claude-code": "claude",
    "claudecode": "claude",
    "gemini-cli": "gemini",
    "geminicli": "gemini",
    "open-code": "opencode",
}

AGENT_NAME_RE = re.compile(r"^[a-z0-9][a-z0-9._-]{0,31}$")
REMOTE_URL_RE = re.compile(r"^(https://|ssh://|git@)")
REMOTE_NAME_RE = re.compile(r"^[a-z0-9][a-z0-9._-]{0,63}$")

COMMANDS = {
    "skill", "agent", "agents", "claim", "remote", "interactive",
    "lint", "viber", "report", "find", "crossreference",
}

# Default registry root: folder containing manager.py (parent of manager_pkg/)
REGISTRY = Path(__file__).resolve().parent.parent


def set_registry(path: Path) -> None:
    """Update the default registry root (called by the entrypoint script)."""
    global REGISTRY
    REGISTRY = path.resolve()


class ManagerError(Exception):
    """A user-facing error; main() renders it cleanly without a traceback."""
