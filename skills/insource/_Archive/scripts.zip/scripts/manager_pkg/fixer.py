"""Extensible lint auto-fixer with safe/unsafe tiers and selectable fix styles.

Overview
--------
Every lint condition emitted by ``cmd_lint`` (metadata rules, semver version
checks, synchronization issues, and README header counts) is registered in
``FIX_CATALOG`` with:

- ``rule``          -- canonical rule identifier (e.g. ``broken-link``, ``specialized``)
- ``category``      -- ``metadata`` | ``version`` | ``sync`` | ``readme``
- ``default_style`` -- strategy applied when no ``--fix-style`` override is given
- ``styles``        -- mapping of ``style_name -> FixStyleInfo(safety, summary)``

Safety Model
------------
- **safe**: Deterministic, non-destructive repairs (relinking to a known source,
  restoring a missing locked link or missing hard-copy, updating an unedited
  hard-copy, collapsing multiline descriptions, canonicalizing aliases, setting
  initial semver, bumping unbumped semver, pruning invalid ``lint-accept`` keys,
  updating README numeric counts, or explicitly ignoring a rule).
- **unsafe**: Potentially lossy, opinionated, or destructive changes (deleting
  files/folders/links, overwriting locally modified hard-copies, truncating
  descriptions, stubbing missing frontmatter, inferring ``argument-hint``,
  writing ``lint-accept`` suppressions, rebaselining without a version bump,
  unlocking locked skills, or renaming directories). Unsafe fixes are skipped
  unless ``--unsafe`` is explicitly passed.

Frontmatter Preservation
------------------------
All ``SKILL.md`` edits operate surgically on the YAML frontmatter block,
preserving original line endings, UTF-8 BOM, comments, untouched keys, and
markdown body text — and work with or without PyYAML installed.
"""

from __future__ import annotations

import os
import re
from collections import Counter
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Sequence

from .agents import agent_md_targets, agent_names, agent_skill_dir
from .config import (
    AGENT_SOURCE,
    DEFAULT_DESCRIPTION_LIMIT,
    INITIAL_VERSION,
    LINT_RULE_IDS,
    ManagerError,
    README_NAME,
    SEMVER_RE,
    SPECIALIZED_ALIASES,
    SPECIALIZED_GENERAL,
    SPECIALIZED_RE,
    SPECIALIZED_REJECTED,
    STANDALONE_CATEGORY,
)
from .deploy import (
    SyncIssue,
    deploy_agent_file,
    install_copy,
    remember_copy,
    sync_copy,
)
from .registry import (
    FRONTMATTER_RE,
    _norm_version,
    git_head,
    load_versions,
    nested_skill_index,
    read_frontmatter,
    registry_skills,
    save_versions,
    skill_snapshot,
    walk_skills,
)
from .remotes import remote_skill_index
from .reporting import (
    display_counts,
    display_info,
    display_table,
    display_warn,
)
from .storage import (
    _key,
    backup_dirs,
    drop_install,
    drop_record,
    get_record,
    has_skill,
    is_link_like,
    is_under,
    load_lockfile,
    load_records,
    make_link,
    record_copy,
    remove_entry,
    remove_lock_entry,
    remove_tree_local,
    same_path,
)


# ---------------------------------------------------------------------------
# Data models & fix catalog
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class FixStyleInfo:
    """Metadata describing one selectable fix strategy for a lint rule."""

    safety: str  # "safe" or "unsafe"
    summary: str


@dataclass(frozen=True)
class FixRuleSpec:
    """Declarative specification of how one lint condition can be fixed."""

    rule: str
    category: str  # "metadata" | "version" | "sync" | "readme"
    default_style: str
    styles: dict[str, FixStyleInfo]
    description: str


@dataclass
class LintFinding:
    """Unified finding representation passed from cmd_lint to the fixer engine."""

    rule: str
    category: str  # "metadata" | "version" | "sync" | "readme"
    target_name: str
    path: Path
    detail: str
    location: str = "registry"
    extra: dict[str, Any] = field(default_factory=dict)


@dataclass
class FixOutcome:
    """Result of attempting to fix a single LintFinding."""

    rule: str
    target_name: str
    safety: str
    style: str
    status: str  # fixed | would fix | ignored | unsafe-skipped | skipped | failed
    detail: str
    path: str


FIX_CATALOG: dict[str, FixRuleSpec] = {
    # --- Metadata rules ---
    "frontmatter": FixRuleSpec(
        rule="frontmatter",
        category="metadata",
        default_style="stub",
        styles={
            "stub": FixStyleInfo("unsafe", "prepend minimal YAML frontmatter from folder & heading"),
            "ignore": FixStyleInfo("safe", "leave SKILL.md untouched"),
        },
        description="Missing or unparsable YAML frontmatter block",
    ),
    "name": FixRuleSpec(
        rule="name",
        category="metadata",
        default_style="match-folder",
        styles={
            "match-folder": FixStyleInfo("safe", "set frontmatter name to sanitized folder slug"),
            "accept": FixStyleInfo("unsafe", "add lint-accept.name suppression"),
            "ignore": FixStyleInfo("safe", "leave untouched"),
        },
        description="Missing or invalid skill name (must match [a-z0-9-]+)",
    ),
    "name-mismatch": FixRuleSpec(
        rule="name-mismatch",
        category="metadata",
        default_style="match-folder",
        styles={
            "match-folder": FixStyleInfo("safe", "update frontmatter name to match folder name"),
            "rename-folder": FixStyleInfo("unsafe", "rename directory on disk to match frontmatter name"),
            "accept": FixStyleInfo("unsafe", "add lint-accept.name-mismatch suppression"),
            "ignore": FixStyleInfo("safe", "leave untouched"),
        },
        description="Frontmatter name differs from enclosing folder name",
    ),
    "duplicate-name": FixRuleSpec(
        rule="duplicate-name",
        category="metadata",
        default_style="accept",
        styles={
            "accept": FixStyleInfo("unsafe", "add lint-accept.duplicate-name suppression"),
            "disambiguate": FixStyleInfo("unsafe", "prefix frontmatter name with parent folder slug"),
            "ignore": FixStyleInfo("safe", "leave untouched"),
        },
        description="Multiple registry skills share the same frontmatter name",
    ),
    "description": FixRuleSpec(
        rule="description",
        category="metadata",
        default_style="from-body",
        styles={
            "from-body": FixStyleInfo("unsafe", "synthesize description from first body paragraph/heading"),
            "placeholder": FixStyleInfo("unsafe", "insert TODO placeholder description"),
            "accept": FixStyleInfo("unsafe", "add lint-accept.description suppression"),
            "ignore": FixStyleInfo("safe", "leave untouched"),
        },
        description="Missing or empty description in frontmatter",
    ),
    "description-multiline": FixRuleSpec(
        rule="description-multiline",
        category="metadata",
        default_style="collapse",
        styles={
            "collapse": FixStyleInfo("safe", "collapse newlines into a single normalized line"),
            "accept": FixStyleInfo("unsafe", "add lint-accept.description-multiline suppression"),
            "ignore": FixStyleInfo("safe", "leave untouched"),
        },
        description="Description spans multiple lines",
    ),
    "description-length": FixRuleSpec(
        rule="description-length",
        category="metadata",
        default_style="truncate",
        styles={
            "truncate": FixStyleInfo("unsafe", "trim on word boundary to fit --max-description"),
            "accept": FixStyleInfo("unsafe", "add lint-accept.description-length suppression"),
            "ignore": FixStyleInfo("safe", "leave untouched"),
        },
        description="Description exceeds character limit",
    ),
    "specialized": FixRuleSpec(
        rule="specialized",
        category="metadata",
        default_style="auto",
        styles={
            "auto": FixStyleInfo("safe", "canonicalize aliases/case or set missing/rejected to 'none' (multi-tech reduction requires --unsafe)"),
            "set-none": FixStyleInfo("unsafe", "force specialized to 'none'"),
            "first": FixStyleInfo("unsafe", "keep only the first technology in a comma-separated list"),
            "accept": FixStyleInfo("unsafe", "add lint-accept.specialized suppression"),
            "ignore": FixStyleInfo("safe", "leave untouched"),
        },
        description="Missing, aliased, rejected, or multi-valued specialized field",
    ),
    "skill-length": FixRuleSpec(
        rule="skill-length",
        category="metadata",
        default_style="accept",
        styles={
            "accept": FixStyleInfo("unsafe", "add lint-accept.skill-length suppression"),
            "ignore": FixStyleInfo("safe", "leave untouched"),
        },
        description="Non-solo SKILL.md reaches or exceeds line limit",
    ),
    "argument-hint": FixRuleSpec(
        rule="argument-hint",
        category="metadata",
        default_style="infer",
        styles={
            "infer": FixStyleInfo("unsafe", "infer argument-hint from command/mode headings or self-slash usage"),
            "accept": FixStyleInfo("unsafe", "add lint-accept.argument-hint suppression"),
            "ignore": FixStyleInfo("safe", "leave untouched"),
        },
        description="Skill exposes commands/modes without declaring argument-hint",
    ),
    "mixed-composition": FixRuleSpec(
        rule="mixed-composition",
        category="metadata",
        default_style="accept",
        styles={
            "accept": FixStyleInfo("unsafe", "add lint-accept.mixed-composition suppression"),
            "ignore": FixStyleInfo("safe", "leave untouched"),
        },
        description="Skill mixes independent sub-skills with internal battery modules",
    ),
    "lint-accept": FixRuleSpec(
        rule="lint-accept",
        category="metadata",
        default_style="prune",
        styles={
            "prune": FixStyleInfo("safe", "remove unknown rule IDs or empty-reason lint-accept entries"),
            "fill-reason": FixStyleInfo("unsafe", "fill empty reasons with a placeholder note"),
            "ignore": FixStyleInfo("safe", "leave untouched"),
        },
        description="Malformed lint-accept block, unknown rule ID, or blank reason",
    ),
    # --- Version rules ---
    "version-missing": FixRuleSpec(
        rule="version-missing",
        category="version",
        default_style="set-initial",
        styles={
            "set-initial": FixStyleInfo("safe", f"set version to {INITIAL_VERSION} and update baseline"),
            "accept": FixStyleInfo("unsafe", "add lint-accept.version suppression"),
            "ignore": FixStyleInfo("safe", "leave untouched"),
        },
        description="Skill has no version field in frontmatter",
    ),
    "version-invalid": FixRuleSpec(
        rule="version-invalid",
        category="version",
        default_style="normalize",
        styles={
            "normalize": FixStyleInfo("safe", "coerce common non-semver strings (v1.2, 1.0) to X.Y.Z"),
            "set-initial": FixStyleInfo("unsafe", f"reset version to {INITIAL_VERSION}"),
            "accept": FixStyleInfo("unsafe", "add lint-accept.version suppression"),
            "ignore": FixStyleInfo("safe", "leave untouched"),
        },
        description="Skill version is not valid semver X.Y.Z",
    ),
    "version-unbumped": FixRuleSpec(
        rule="version-unbumped",
        category="version",
        default_style="bump",
        styles={
            "bump": FixStyleInfo("safe", "bump version by suggested semver increment (patch/minor/major)"),
            "bump-patch": FixStyleInfo("safe", "bump patch version (X.Y.Z+1)"),
            "bump-minor": FixStyleInfo("safe", "bump minor version (X.Y+1.0)"),
            "rebaseline": FixStyleInfo("unsafe", "keep version string and update stored baseline snapshot"),
            "ignore": FixStyleInfo("safe", "leave untouched"),
        },
        description="Skill files changed since last baseline without a version bump",
    ),
    # --- Synchronization rules ---
    "missing-locked": FixRuleSpec(
        rule="missing-locked",
        category="sync",
        default_style="restore",
        styles={
            "restore": FixStyleInfo("safe", "recreate missing symlink/junction from registry"),
            "unlock": FixStyleInfo("unsafe", "remove lock record from database instead of restoring"),
            "ignore": FixStyleInfo("safe", "leave untouched"),
        },
        description="Locked skill is missing from an agent skills folder",
    ),
    "broken-link": FixRuleSpec(
        rule="broken-link",
        category="sync",
        default_style="restore",
        styles={
            "restore": FixStyleInfo("safe", "relink to valid registry/remote/AGENTS.md source (orphans skipped unless --unsafe)"),
            "remove": FixStyleInfo("unsafe", "delete the broken link and prune stale index/lock rows"),
            "ignore": FixStyleInfo("safe", "leave untouched"),
        },
        description="Symlink or junction points to a target that no longer exists",
    ),
    "wrong-target": FixRuleSpec(
        rule="wrong-target",
        category="sync",
        default_style="relink",
        styles={
            "relink": FixStyleInfo("safe", "point the link back to the canonical registry/AGENTS.md target"),
            "remove": FixStyleInfo("unsafe", "delete the misdirected link"),
            "ignore": FixStyleInfo("safe", "leave untouched"),
        },
        description="Link points to a different path than expected",
    ),
    "missing-skill": FixRuleSpec(
        rule="missing-skill",
        category="sync",
        default_style="relink",
        styles={
            "relink": FixStyleInfo("safe", "relink to matching registry skill (replacing real dir requires --unsafe)"),
            "remove": FixStyleInfo("unsafe", "remove the non-skill link or directory (backed up first)"),
            "ignore": FixStyleInfo("safe", "leave untouched"),
        },
        description="Agent folder entry or link target has no top-level SKILL.md",
    ),
    "source-changed": FixRuleSpec(
        rule="source-changed",
        category="sync",
        default_style="update",
        styles={
            "update": FixStyleInfo("safe", "re-copy updated source into unmodified hard-copy"),
            "relink": FixStyleInfo("unsafe", "back up hard-copy and replace with a symlink"),
            "ignore": FixStyleInfo("safe", "leave untouched"),
        },
        description="Tracked hard-copy is behind its source (copy untouched locally)",
    ),
    "missing-target": FixRuleSpec(
        rule="missing-target",
        category="sync",
        default_style="restore",
        styles={
            "restore": FixStyleInfo("safe", "re-copy tracked hard-copy from its recorded source"),
            "forget": FixStyleInfo("unsafe", "drop the missing copy record from the database"),
            "ignore": FixStyleInfo("safe", "leave untouched"),
        },
        description="Tracked hard-copy is missing from disk",
    ),
    "missing-source": FixRuleSpec(
        rule="missing-source",
        category="sync",
        default_style="forget",
        styles={
            "forget": FixStyleInfo("unsafe", "drop orphaned copy record from database (keeps copy on disk)"),
            "remove": FixStyleInfo("unsafe", "back up and delete the orphaned copy + drop record"),
            "ignore": FixStyleInfo("safe", "leave untouched"),
        },
        description="Tracked hard-copy's recorded source no longer exists",
    ),
    "target-modified": FixRuleSpec(
        rule="target-modified",
        category="sync",
        default_style="overwrite",
        styles={
            "overwrite": FixStyleInfo("unsafe", "back up local edits and overwrite hard-copy from source"),
            "accept-local": FixStyleInfo("unsafe", "update stored copy fingerprint to accept local edits"),
            "forget": FixStyleInfo("unsafe", "stop tracking this copy in the database"),
            "ignore": FixStyleInfo("safe", "leave untouched"),
        },
        description="Tracked hard-copy was edited locally",
    ),
    "both-changed": FixRuleSpec(
        rule="both-changed",
        category="sync",
        default_style="overwrite",
        styles={
            "overwrite": FixStyleInfo("unsafe", "back up local copy and overwrite from source"),
            "accept-local": FixStyleInfo("unsafe", "update stored copy fingerprints to accept current local copy"),
            "forget": FixStyleInfo("unsafe", "stop tracking this copy in the database"),
            "ignore": FixStyleInfo("safe", "leave untouched"),
        },
        description="Both source and tracked hard-copy changed since last sync",
    ),
    "target-replaced": FixRuleSpec(
        rule="target-replaced",
        category="sync",
        default_style="forget",
        styles={
            "forget": FixStyleInfo("safe", "drop obsolete hard-copy DB record because a live link now exists"),
            "restore": FixStyleInfo("unsafe", "remove symlink and restore tracked hard-copy"),
            "ignore": FixStyleInfo("safe", "leave untouched"),
        },
        description="Tracked hard-copy path was replaced by a live symlink",
    ),
    "stale-copy": FixRuleSpec(
        rule="stale-copy",
        category="sync",
        default_style="relink",
        styles={
            "relink": FixStyleInfo("unsafe", "back up existing AGENTS.md (.bak) and relink to registry source"),
            "update": FixStyleInfo("unsafe", "back up existing AGENTS.md (.bak) and copy latest registry source"),
            "ignore": FixStyleInfo("safe", "leave untouched"),
        },
        description="Agent instruction file copy differs from _Resources/AGENTS.md",
    ),
    # --- README catalog rules ---
    "readme-counts": FixRuleSpec(
        rule="readme-counts",
        category="readme",
        default_style="update-counts",
        styles={
            "update-counts": FixStyleInfo("safe", "update active/standalone/group/archived counts in README header"),
            "ignore": FixStyleInfo("safe", "leave untouched"),
        },
        description="README header statistics disagree with skills on disk",
    ),
}

# Friendly aliases users may pass to --fix-style / --only / --skip-fix
FIX_RULE_ALIASES: dict[str, str] = {
    "version": "version-unbumped",
    "readme": "readme-counts",
}


# ---------------------------------------------------------------------------
# Style & filter parsing helpers
# ---------------------------------------------------------------------------


def normalize_rule_id(raw: str) -> str:
    """Resolve user-supplied rule name or alias into a canonical FIX_CATALOG key."""
    key = raw.strip().lower()
    return FIX_RULE_ALIASES.get(key, key)


def parse_fix_styles(raw_items: Sequence[str] | None) -> dict[str, str]:
    """Parse ``--fix-style RULE=STYLE`` arguments (repeatable or comma-separated).

    Supports ``all=ignore`` as a wildcard override alongside per-rule overrides.
    """
    overrides: dict[str, str] = {}
    if not raw_items:
        return overrides
    tokens: list[str] = []
    for item in raw_items:
        for part in item.split(","):
            part = part.strip()
            if part:
                tokens.append(part)
    for token in tokens:
        if "=" not in token:
            raise ManagerError(
                f"invalid --fix-style '{token}': expected RULE=STYLE "
                f"(run `lint --list-fixes` to see all rules and styles)"
            )
        raw_rule, raw_style = token.split("=", 1)
        rule = normalize_rule_id(raw_rule)
        style = raw_style.strip().lower()
        if rule == "all":
            overrides["all"] = style
            continue
        if rule not in FIX_CATALOG:
            known = ", ".join(sorted(FIX_CATALOG))
            raise ManagerError(
                f"unknown fix rule '{raw_rule.strip()}' in --fix-style. "
                f"Known rules: {known}"
            )
        spec = FIX_CATALOG[rule]
        if style not in spec.styles:
            valid = ", ".join(spec.styles)
            raise ManagerError(
                f"invalid style '{style}' for rule '{rule}'; valid styles: {valid}"
            )
        overrides[rule] = style
    return overrides


def parse_rule_filter(raw_items: Sequence[str] | None, flag_name: str) -> set[str]:
    """Parse comma-separated/repeatable rule lists for ``--only`` and ``--skip-fix``."""
    selected: set[str] = set()
    if not raw_items:
        return selected
    for item in raw_items:
        for part in item.split(","):
            part = part.strip()
            if not part:
                continue
            key = normalize_rule_id(part)
            if key == "version":
                selected.update({"version-missing", "version-invalid", "version-unbumped"})
                continue
            if part.strip().lower() == "version":
                selected.update({"version-missing", "version-invalid", "version-unbumped"})
                continue
            if key not in FIX_CATALOG:
                raise ManagerError(
                    f"unknown rule '{part}' in {flag_name}; run `lint --list-fixes` to inspect rules"
                )
            selected.add(key)
    return selected


def display_fix_catalog() -> None:
    """Render every fixable lint condition grouped by category, readable even at 80 columns."""
    from .reporting import _DISPLAY, display_rule

    categories = [
        ("metadata", "metadata rules"),
        ("version", "version rules"),
        ("sync", "synchronization rules"),
        ("readme", "README catalog rules"),
    ]
    display_info(
        f"lint fix catalog ({len(FIX_CATALOG)} conditions) — "
        "use `lint --fix` (safe), `--fix --unsafe`, or `--fix-style RULE=STYLE`"
    )
    for cat_key, cat_title in categories:
        specs = sorted(
            (s for s in FIX_CATALOG.values() if s.category == cat_key),
            key=lambda s: s.rule,
        )
        if not specs:
            continue
        rows: list[list[str]] = []
        for spec in specs:
            default_safety = spec.styles[spec.default_style].safety
            styles_list = ", ".join(
                f"{name}*" if name == spec.default_style else name
                for name in spec.styles
            )
            if _DISPLAY.verbose or _DISPLAY.full:
                rows.append([spec.rule, default_safety, spec.default_style, styles_list, spec.description])
            else:
                rows.append([spec.rule, default_safety, spec.default_style, styles_list])
        headers = (
            ["Rule", "Safety", "Default", "Styles", "Condition"]
            if (_DISPLAY.verbose or _DISPLAY.full)
            else ["Rule", "Safety", "Default", "Styles"]
        )
        display_table(headers, rows, title=f"{cat_title} ({len(rows)})", always=True, max_rows=0)
    if not (_DISPLAY.verbose or _DISPLAY.full):
        display_info("tip: pass --verbose or --full to also show condition descriptions")


# ---------------------------------------------------------------------------
# Surgical YAML frontmatter editor (zero-dependency, preserves formatting)
# ---------------------------------------------------------------------------

_YAML_SIMPLE_SAFE_RE = re.compile(r"^[A-Za-z0-9._/+ -]+$")


def _yaml_quote_scalar(value: str) -> str:
    """Format a single-line YAML scalar cleanly without unnecessary quoting."""
    clean = " ".join(value.splitlines()).strip()
    if not clean:
        return '""'
    lower = clean.lower()
    needs_quote = (
        lower in {"true", "false", "null", "yes", "no", "on", "off", "~"}
        or clean[0] in "-?:,[]{}#&*!|>'\"%@`"
        or ": " in clean
        or clean.endswith(":")
        or "#" in clean
        or not _YAML_SIMPLE_SAFE_RE.fullmatch(clean)
    )
    if not needs_quote:
        return clean
    escaped = clean.replace("\\", "\\\\").replace('"', '\\"')
    return f'"{escaped}"'


def _split_frontmatter(text: str) -> tuple[str, str, str, str] | None:
    """Split ``text`` into (bom, nl, raw_frontmatter, rest_of_doc), or None if absent."""
    bom = "\ufeff" if text.startswith("\ufeff") else ""
    body = text[len(bom):]
    nl = "\r\n" if "\r\n" in body else "\n"
    match = FRONTMATTER_RE.match(body)
    if not match:
        return None
    raw = match.group(1)
    rest = body[match.end():]
    return bom, nl, raw, rest


def _set_frontmatter_scalar(raw: str, key: str, value: str, nl: str) -> str:
    """Replace or insert a top-level scalar ``key: value`` in raw frontmatter text."""
    lines = raw.splitlines()
    key_re = re.compile(rf"^{re.escape(key)}\s*:(.*)$")
    formatted = f"{key}: {_yaml_quote_scalar(value)}"

    idx = 0
    while idx < len(lines):
        if key_re.match(lines[idx]):
            # Consume any indented continuation lines (block scalars / folded strings)
            end = idx + 1
            while end < len(lines) and (
                lines[end].startswith((" ", "\t")) or not lines[end].strip()
            ):
                # Stop before a trailing blank line that precedes the next top-level key
                if not lines[end].strip():
                    nxt = end + 1
                    while nxt < len(lines) and not lines[nxt].strip():
                        nxt += 1
                    if nxt >= len(lines) or not lines[nxt].startswith((" ", "\t")):
                        break
                end += 1
            lines[idx:end] = [formatted]
            return nl.join(lines)
        idx += 1

    lines.append(formatted)
    return nl.join(lines)


def _set_frontmatter_lint_accept(
    raw: str,
    updates: dict[str, str] | None = None,
    *,
    prune_invalid: bool = False,
    fill_blank: str | None = None,
    nl: str = "\n",
) -> str:
    """Update, prune, or insert entries inside the ``lint-accept:`` frontmatter mapping."""
    lines = raw.splitlines()
    block_re = re.compile(r"^lint-accept\s*:(.*)$")
    start = next((i for i, ln in enumerate(lines) if block_re.match(ln)), None)

    entries: list[tuple[str, str]] = []
    if start is not None:
        end = start + 1
        while end < len(lines):
            ln = lines[end]
            if ln.strip() and not ln.startswith((" ", "\t")):
                break
            m = re.match(r"^[ \t]+([A-Za-z0-9_-]+)\s*:\s*(.*)$", ln)
            if m:
                k, v = m.group(1), m.group(2).strip()
                if len(v) >= 2 and v[0] == v[-1] and v[0] in "'\"":
                    v = v[1:-1]
                entries.append((k, v))
            end += 1
    else:
        end = len(lines)

    ordered: dict[str, str] = {}
    for k, v in entries:
        if prune_invalid:
            if k not in LINT_RULE_IDS:
                continue
            if not v.strip():
                if fill_blank is not None:
                    ordered[k] = fill_blank
                continue
        elif fill_blank is not None and k in LINT_RULE_IDS and not v.strip():
            v = fill_blank
        ordered[k] = v

    for k, v in (updates or {}).items():
        ordered[k] = v

    if ordered:
        new_block = ["lint-accept:"] + [
            f"  {k}: {_yaml_quote_scalar(v)}" for k, v in ordered.items()
        ]
    else:
        new_block = []

    if start is not None:
        lines[start:end] = new_block
    elif new_block:
        lines.extend(new_block)
    return nl.join(lines)


def _write_frontmatter_update(
    skill_md: Path,
    transform: Any,
    *,
    dry_run: bool,
) -> bool:
    """Apply ``transform(raw, nl) -> new_raw`` to ``skill_md``'s frontmatter."""
    text = skill_md.read_text(encoding="utf-8", errors="replace")
    parts = _split_frontmatter(text)
    if parts is None:
        return False
    bom, nl, raw, rest = parts
    new_raw = transform(raw, nl)
    if new_raw == raw:
        return False
    if not dry_run:
        rebuilt = f"{bom}---{nl}{new_raw}{nl}---{nl}{rest}"
        skill_md.write_text(rebuilt, encoding="utf-8")
    return True


# ---------------------------------------------------------------------------
# Helpers for synthesizing / normalizing metadata values
# ---------------------------------------------------------------------------


def _slugify_name(raw: str) -> str:
    slug = re.sub(r"[^a-z0-9-]+", "-", raw.strip().lower()).strip("-")
    slug = re.sub(r"-{2,}", "-", slug)
    return slug or "skill"


def _extract_body_description(skill_md: Path, fallback_name: str, limit: int) -> str:
    """Extract a clean single-line summary from the Markdown body of SKILL.md."""
    try:
        text = skill_md.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return f"Skill instructions for {fallback_name}."
    parts = _split_frontmatter(text)
    body = parts[3] if parts else text
    paragraph: list[str] = []
    heading = ""
    in_code = False
    for line in body.splitlines():
        stripped = line.strip()
        if stripped.startswith("```"):
            in_code = not in_code
            continue
        if in_code:
            continue
        if not stripped:
            if paragraph:
                break
            continue
        if stripped.startswith("#"):
            if not heading:
                heading = stripped.lstrip("#").strip()
            if paragraph:
                break
            continue
        if stripped.startswith(("-", "*", ">", "|")) and not paragraph:
            continue
        paragraph.append(stripped)
    candidate = " ".join(paragraph).strip()
    if not candidate:
        candidate = f"{heading}." if heading else f"Skill instructions for {fallback_name}."
    candidate = re.sub(r"\s+", " ", candidate)
    return _truncate_word_boundary(candidate, min(limit, 240))


def _truncate_word_boundary(text: str, limit: int) -> str:
    clean = " ".join(text.split())
    if len(clean) <= limit:
        return clean
    if limit <= 3:
        return clean[:limit]
    cut = clean[: limit - 3]
    if " " in cut:
        head = cut.rsplit(" ", 1)[0].rstrip(" ,;:-")
        if len(head) >= limit // 2:
            return head + "..."
    return cut.rstrip() + "..."


def _bump_semver(version: str, level: str) -> str | None:
    """Bump a semver string (X.Y.Z[...]) by patch, minor, or major."""
    m = re.match(r"^(\d+)\.(\d+)\.(\d+)", version.strip())
    if not m:
        return None
    major, minor, patch = int(m.group(1)), int(m.group(2)), int(m.group(3))
    lvl = level.strip().lower()
    if lvl == "major":
        return f"{major + 1}.0.0"
    if lvl == "minor":
        return f"{major}.{minor + 1}.0"
    return f"{major}.{minor}.{patch + 1}"


def _coerce_semver(raw: str) -> tuple[str | None, bool]:
    """Coerce common non-semver forms into X.Y.Z. Returns (coerced, is_lossless_safe)."""
    cleaned = raw.strip().lstrip("vV")
    if SEMVER_RE.fullmatch(cleaned):
        return cleaned, True
    m2 = re.fullmatch(r"(\d+)\.(\d+)", cleaned)
    if m2:
        return f"{int(m2.group(1))}.{int(m2.group(2))}.0", True
    m1 = re.fullmatch(r"(\d+)", cleaned)
    if m1:
        return f"{int(m1.group(1))}.0.0", True
    m4 = re.fullmatch(r"(\d+)\.(\d+)\.(\d+)\.\d+", cleaned)
    if m4:
        return f"{int(m4.group(1))}.{int(m4.group(2))}.{int(m4.group(3))}", False
    return None, False


def _infer_argument_hint(skill_md: Path, skill_name: str) -> str:
    """Infer a concise argument-hint from self-slash usage or mode headings."""
    try:
        text = skill_md.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return "<command> [args]"
    parts = _split_frontmatter(text)
    body = parts[3] if parts else text
    slash_re = re.compile(rf"/{re.escape(skill_name)}\s+([<\[][^\n`]+|[a-z0-9_-]+(?:\s+[^\n`]+)?)")
    hits = [m.group(1).strip().rstrip("`.,;") for m in slash_re.finditer(body)]
    if hits:
        # If there are distinct subcommands, show up to 3 pipe-separated
        subcmds: list[str] = []
        for h in hits:
            first = h.split()[0]
            if first not in subcmds:
                subcmds.append(first)
        if len(subcmds) == 1:
            return hits[0][:48]
        return "|".join(subcmds[:4])
    if re.search(r"\bmodes?\b", body, re.I):
        return "<mode> [args]"
    return "<command> [args]"


def _rebaseline_version_entry(registry: Path, skill_name: str, skill_dir: Path, version: str) -> None:
    """Update one skill's baseline snapshot in the SQLite versions store."""
    if not is_under(skill_dir, registry):
        return
    state = load_versions(registry)
    snap = skill_snapshot(skill_dir)
    rel = skill_dir.relative_to(registry).as_posix()
    state.setdefault("skills", {})[skill_name] = {
        "version": version,
        "name": skill_name,
        "path": rel,
        "commit": git_head(registry),
        "fingerprint": snap["fingerprint"],
        "file_count": snap["file_count"],
        "files": snap["files"],
    }
    save_versions(registry, state)


def _agent_for_path(target: Path) -> str | None:
    """Return the registered agent name owning ``target``, if any."""
    for agent in agent_names():
        if is_under(target, agent_skill_dir(agent)):
            return agent
        if any(same_path(target, md) for md in agent_md_targets(agent)):
            return agent
    return None


# ---------------------------------------------------------------------------
# Individual fix executors
# ---------------------------------------------------------------------------


def _apply_metadata_fix(
    finding: LintFinding,
    style: str,
    *,
    unsafe: bool,
    dry_run: bool,
    limit: int,
) -> FixOutcome:
    rule = finding.rule
    skill_dir = finding.path
    skill_md = skill_dir / "SKILL.md"
    spec = FIX_CATALOG[rule]
    style_info = spec.styles[style]
    safety = style_info.safety

    if style == "ignore":
        return FixOutcome(rule, finding.target_name, "safe", style, "ignored", "skipped by style", str(skill_md))

    # Special case: specialized auto is safe for alias/case/missing/rejected, unsafe for dropping multi-tech
    data, _err = read_frontmatter(skill_md) if skill_md.is_file() else (None, "missing")
    if rule == "specialized" and style == "auto" and isinstance(data, dict):
        raw_val = data.get("specialized")
        if isinstance(raw_val, str) and "," in raw_val:
            safety = "unsafe"
    if rule == "specialized" and style == "set-none" and isinstance(data, dict):
        raw_val = data.get("specialized")
        if raw_val is None or (isinstance(raw_val, str) and raw_val.strip().lower() in SPECIALIZED_REJECTED):
            safety = "safe"

    if safety == "unsafe" and not unsafe:
        return FixOutcome(
            rule, finding.target_name, "unsafe", style, "unsafe-skipped",
            f"requires --unsafe ({style_info.summary})", str(skill_md),
        )

    if not skill_md.is_file():
        return FixOutcome(rule, finding.target_name, safety, style, "failed", "SKILL.md not found", str(skill_md))

    # Shared `accept` style for any rule in LINT_RULE_IDS
    if style == "accept":
        accept_rule = "version" if rule.startswith("version-") else rule
        reason = f"accepted via manager lint --fix ({finding.detail[:80]})"
        changed = _write_frontmatter_update(
            skill_md,
            lambda raw, nl: _set_frontmatter_lint_accept(raw, {accept_rule: reason}, nl=nl),
            dry_run=dry_run,
        )
        status = ("would fix" if dry_run else "fixed") if changed else "skipped"
        return FixOutcome(rule, finding.target_name, safety, style, status, f"added lint-accept.{accept_rule}", str(skill_md))

    if rule == "frontmatter" and style == "stub":
        text = skill_md.read_text(encoding="utf-8", errors="replace")
        if _split_frontmatter(text) is not None:
            return FixOutcome(
                rule, finding.target_name, safety, style, "skipped",
                "frontmatter delimiters exist but YAML is invalid; fix syntax manually", str(skill_md),
            )
        nl = "\r\n" if "\r\n" in text else "\n"
        bom = "\ufeff" if text.startswith("\ufeff") else ""
        body = text[len(bom):]
        slug = _slugify_name(skill_dir.name)
        desc = _extract_body_description(skill_md, slug, limit)
        header = (
            f"{bom}---{nl}"
            f"name: {_yaml_quote_scalar(slug)}{nl}"
            f"version: {INITIAL_VERSION}{nl}"
            f"specialized: {SPECIALIZED_GENERAL}{nl}"
            f"description: {_yaml_quote_scalar(desc)}{nl}"
            f"---{nl}{nl}"
        )
        if not dry_run:
            skill_md.write_text(header + body, encoding="utf-8")
        return FixOutcome(
            rule, finding.target_name, safety, style,
            "would fix" if dry_run else "fixed",
            f"prepended frontmatter (name={slug}, version={INITIAL_VERSION})", str(skill_md),
        )

    if rule == "name" and style == "match-folder":
        slug = _slugify_name(skill_dir.name)
        changed = _write_frontmatter_update(
            skill_md, lambda raw, nl: _set_frontmatter_scalar(raw, "name", slug, nl), dry_run=dry_run
        )
        return FixOutcome(
            rule, finding.target_name, safety, style,
            ("would fix" if dry_run else "fixed") if changed else "skipped",
            f"set name: {slug}", str(skill_md),
        )

    if rule == "name-mismatch":
        if style == "match-folder":
            slug = _slugify_name(skill_dir.name)
            changed = _write_frontmatter_update(
                skill_md, lambda raw, nl: _set_frontmatter_scalar(raw, "name", slug, nl), dry_run=dry_run
            )
            return FixOutcome(
                rule, finding.target_name, safety, style,
                ("would fix" if dry_run else "fixed") if changed else "skipped",
                f"updated frontmatter name -> {slug}", str(skill_md),
            )
        if style == "rename-folder":
            desired = str((data or {}).get("name") or "").strip()
            if not desired or not re.fullmatch(r"[a-z0-9-]+", desired):
                return FixOutcome(rule, finding.target_name, safety, style, "failed", "frontmatter name is not a valid folder slug", str(skill_dir))
            new_dir = skill_dir.with_name(desired)
            if new_dir.exists():
                return FixOutcome(rule, finding.target_name, safety, style, "failed", f"target folder already exists: {new_dir}", str(skill_dir))
            if not dry_run:
                skill_dir.rename(new_dir)
            return FixOutcome(
                rule, finding.target_name, safety, style,
                "would fix" if dry_run else "fixed",
                f"renamed {skill_dir.name} -> {desired}", str(new_dir),
            )

    if rule == "duplicate-name" and style == "disambiguate":
        parent_slug = _slugify_name(skill_dir.parent.name)
        cur_name = _slugify_name(str((data or {}).get("name") or skill_dir.name))
        new_name = f"{parent_slug}-{cur_name}"
        changed = _write_frontmatter_update(
            skill_md, lambda raw, nl: _set_frontmatter_scalar(raw, "name", new_name, nl), dry_run=dry_run
        )
        return FixOutcome(
            rule, finding.target_name, safety, style,
            ("would fix" if dry_run else "fixed") if changed else "skipped",
            f"set name -> {new_name}", str(skill_md),
        )

    if rule == "description":
        new_desc = (
            _extract_body_description(skill_md, skill_dir.name, limit)
            if style == "from-body"
            else f"TODO: describe what the {skill_dir.name} skill does and when to use it."
        )
        changed = _write_frontmatter_update(
            skill_md, lambda raw, nl: _set_frontmatter_scalar(raw, "description", new_desc, nl), dry_run=dry_run
        )
        return FixOutcome(
            rule, finding.target_name, safety, style,
            ("would fix" if dry_run else "fixed") if changed else "skipped",
            f"set description ({len(new_desc)} chars)", str(skill_md),
        )

    if rule == "description-multiline" and style == "collapse":
        raw_desc = str((data or {}).get("description") or "")
        collapsed = " ".join(raw_desc.split())
        changed = _write_frontmatter_update(
            skill_md, lambda raw, nl: _set_frontmatter_scalar(raw, "description", collapsed, nl), dry_run=dry_run
        )
        return FixOutcome(
            rule, finding.target_name, safety, style,
            ("would fix" if dry_run else "fixed") if changed else "skipped",
            f"collapsed to single line ({len(collapsed)} chars)", str(skill_md),
        )

    if rule == "description-length" and style == "truncate":
        raw_desc = str((data or {}).get("description") or "")
        trimmed = _truncate_word_boundary(raw_desc, limit)
        changed = _write_frontmatter_update(
            skill_md, lambda raw, nl: _set_frontmatter_scalar(raw, "description", trimmed, nl), dry_run=dry_run
        )
        return FixOutcome(
            rule, finding.target_name, safety, style,
            ("would fix" if dry_run else "fixed") if changed else "skipped",
            f"trimmed {len(raw_desc)} -> {len(trimmed)} chars", str(skill_md),
        )

    if rule == "specialized":
        raw_val = (data or {}).get("specialized")
        target_val = SPECIALIZED_GENERAL
        if style == "set-none":
            target_val = SPECIALIZED_GENERAL
        else:
            if isinstance(raw_val, str) and raw_val.strip():
                items = [p.strip().lower() for p in raw_val.split(",") if p.strip()]
                cleaned: list[str] = []
                for item in items:
                    item = SPECIALIZED_ALIASES.get(item, item)
                    if item in SPECIALIZED_REJECTED or item == SPECIALIZED_GENERAL:
                        continue
                    if SPECIALIZED_RE.fullmatch(item):
                        cleaned.append(item)
                target_val = cleaned[0] if cleaned else SPECIALIZED_GENERAL
            else:
                target_val = SPECIALIZED_GENERAL
        changed = _write_frontmatter_update(
            skill_md, lambda raw, nl: _set_frontmatter_scalar(raw, "specialized", target_val, nl), dry_run=dry_run
        )
        return FixOutcome(
            rule, finding.target_name, safety, style,
            ("would fix" if dry_run else "fixed") if changed else "skipped",
            f"specialized: {raw_val!r} -> {target_val!r}", str(skill_md),
        )

    if rule == "argument-hint" and style == "infer":
        hint = _infer_argument_hint(skill_md, str((data or {}).get("name") or skill_dir.name))
        changed = _write_frontmatter_update(
            skill_md, lambda raw, nl: _set_frontmatter_scalar(raw, "argument-hint", hint, nl), dry_run=dry_run
        )
        return FixOutcome(
            rule, finding.target_name, safety, style,
            ("would fix" if dry_run else "fixed") if changed else "skipped",
            f"set argument-hint: {hint}", str(skill_md),
        )

    if rule == "lint-accept":
        fill = "reviewed and accepted" if style == "fill-reason" else None
        changed = _write_frontmatter_update(
            skill_md,
            lambda raw, nl: _set_frontmatter_lint_accept(raw, prune_invalid=True, fill_blank=fill, nl=nl),
            dry_run=dry_run,
        )
        return FixOutcome(
            rule, finding.target_name, safety, style,
            ("would fix" if dry_run else "fixed") if changed else "skipped",
            "cleaned lint-accept mapping", str(skill_md),
        )

    return FixOutcome(rule, finding.target_name, safety, style, "skipped", "no automatic action for style", str(skill_md))


def _apply_version_fix(
    finding: LintFinding,
    style: str,
    *,
    registry: Path,
    unsafe: bool,
    dry_run: bool,
) -> FixOutcome:
    rule = finding.rule
    skill_dir = finding.path
    skill_md = skill_dir / "SKILL.md"
    spec = FIX_CATALOG[rule]
    style_info = spec.styles[style]
    safety = style_info.safety

    if style == "ignore":
        return FixOutcome(rule, finding.target_name, "safe", style, "ignored", "skipped by style", str(skill_md))

    current_ver = str(finding.extra.get("version") or "").strip()
    suggested = str(finding.extra.get("suggested") or "patch").strip()

    # Check if normalize needs unsafe fallback
    coerced_ver: str | None = None
    if rule == "version-invalid" and style == "normalize":
        coerced_ver, lossless = _coerce_semver(current_ver)
        if coerced_ver is None or not lossless:
            safety = "unsafe"

    if safety == "unsafe" and not unsafe:
        return FixOutcome(
            rule, finding.target_name, "unsafe", style, "unsafe-skipped",
            f"requires --unsafe ({style_info.summary})", str(skill_md),
        )

    if style == "accept":
        reason = f"accepted via manager lint --fix ({finding.detail[:80]})"
        changed = _write_frontmatter_update(
            skill_md,
            lambda raw, nl: _set_frontmatter_lint_accept(raw, {"version": reason}, nl=nl),
            dry_run=dry_run,
        )
        return FixOutcome(
            rule, finding.target_name, safety, style,
            ("would fix" if dry_run else "fixed") if changed else "skipped",
            "added lint-accept.version", str(skill_md),
        )

    if rule == "version-missing" and style == "set-initial":
        changed = _write_frontmatter_update(
            skill_md, lambda raw, nl: _set_frontmatter_scalar(raw, "version", INITIAL_VERSION, nl), dry_run=dry_run
        )
        if changed and not dry_run:
            _rebaseline_version_entry(registry, finding.target_name, skill_dir, INITIAL_VERSION)
        return FixOutcome(
            rule, finding.target_name, safety, style,
            ("would fix" if dry_run else "fixed") if changed else "skipped",
            f"set version: {INITIAL_VERSION}", str(skill_md),
        )

    if rule == "version-invalid":
        new_ver = INITIAL_VERSION if style == "set-initial" else (coerced_ver or INITIAL_VERSION)
        changed = _write_frontmatter_update(
            skill_md, lambda raw, nl: _set_frontmatter_scalar(raw, "version", new_ver, nl), dry_run=dry_run
        )
        if changed and not dry_run:
            _rebaseline_version_entry(registry, finding.target_name, skill_dir, new_ver)
        return FixOutcome(
            rule, finding.target_name, safety, style,
            ("would fix" if dry_run else "fixed") if changed else "skipped",
            f"version {current_ver!r} -> {new_ver}", str(skill_md),
        )

    if rule == "version-unbumped":
        if style == "rebaseline":
            ver_to_keep = current_ver if SEMVER_RE.fullmatch(current_ver) else INITIAL_VERSION
            if not dry_run:
                _rebaseline_version_entry(registry, finding.target_name, skill_dir, ver_to_keep)
            return FixOutcome(
                rule, finding.target_name, safety, style,
                "would fix" if dry_run else "fixed",
                f"rebaselined at {ver_to_keep} without version bump", str(skill_md),
            )
        bump_level = (
            "patch" if style == "bump-patch"
            else "minor" if style == "bump-minor"
            else suggested if suggested in {"patch", "minor", "major"}
            else "patch"
        )
        base_ver = current_ver if SEMVER_RE.fullmatch(current_ver) else INITIAL_VERSION
        bumped = _bump_semver(base_ver, bump_level) or INITIAL_VERSION
        changed = _write_frontmatter_update(
            skill_md, lambda raw, nl: _set_frontmatter_scalar(raw, "version", bumped, nl), dry_run=dry_run
        )
        if changed and not dry_run:
            _rebaseline_version_entry(registry, finding.target_name, skill_dir, bumped)
        return FixOutcome(
            rule, finding.target_name, safety, style,
            ("would fix" if dry_run else "fixed") if changed else "skipped",
            f"bumped {base_ver} -> {bumped} ({bump_level})", str(skill_md),
        )

    return FixOutcome(rule, finding.target_name, safety, style, "skipped", "unsupported version fix", str(skill_md))


def _apply_sync_fix(
    finding: LintFinding,
    style: str,
    *,
    registry: Path,
    known: dict[str, Path],
    nested: dict[str, Path],
    remote_index: dict[str, Path],
    unsafe: bool,
    dry_run: bool,
    no_backup: bool,
) -> FixOutcome:
    issue: SyncIssue = finding.extra["issue"]
    rule = finding.rule
    target = Path(issue.target)
    spec = FIX_CATALOG[rule]
    style_info = spec.styles[style]
    safety = style_info.safety
    agent = _agent_for_path(target)

    if style == "ignore":
        return FixOutcome(rule, issue.skill, "safe", style, "ignored", "skipped by style", str(target))

    # Resolve canonical source for link/agent-md repairs
    expected_source: Path | None = None
    if issue.kind == "agent-md":
        cand = registry / AGENT_SOURCE
        expected_source = cand if cand.is_file() else None
    else:
        expected_source = known.get(issue.skill) or nested.get(issue.skill) or remote_index.get(issue.skill)

    # Dynamic safety refinement
    if rule == "broken-link" and style == "restore" and expected_source is None:
        safety = "unsafe"
    if rule == "missing-skill" and style == "relink" and (not is_link_like(target) and target.is_dir()):
        safety = "unsafe"

    if safety == "unsafe" and not unsafe:
        return FixOutcome(
            rule, issue.skill, "unsafe", style, "unsafe-skipped",
            f"requires --unsafe ({style_info.summary})", str(target),
        )

    # --- missing-locked ---
    if rule == "missing-locked":
        if style == "restore":
            if expected_source is None:
                return FixOutcome(rule, issue.skill, safety, style, "failed", "skill not found in registry", str(target))
            if not dry_run:
                make_link(expected_source, target)
            return FixOutcome(
                rule, issue.skill, safety, style,
                "would fix" if dry_run else "fixed",
                f"restored link -> {expected_source}", str(target),
            )
        if style == "unlock":
            if not dry_run:
                remove_lock_entry(registry, issue.skill, agent)
            return FixOutcome(
                rule, issue.skill, safety, style,
                "would fix" if dry_run else "fixed",
                f"removed lock record for {agent or 'agent'}", str(target),
            )

    # --- broken-link / wrong-target ---
    if rule in {"broken-link", "wrong-target"}:
        if style in {"restore", "relink"}:
            if expected_source is None:
                # Orphan broken link under --unsafe -> remove dangling link
                if not dry_run and (target.exists() or is_link_like(target)):
                    remove_entry(target)
                    drop_install(registry, target)
                    remove_lock_entry(registry, issue.skill, agent)
                return FixOutcome(
                    rule, issue.skill, safety, style,
                    "would fix" if dry_run else "fixed",
                    "no registry/remote source; removed orphan broken link", str(target),
                )
            if not dry_run:
                if target.exists() or is_link_like(target):
                    remove_entry(target)
                if issue.kind == "agent-md":
                    deploy_agent_file(
                        expected_source, target, hard=False, force=True,
                        registry=registry, dry_run=False,
                    )
                else:
                    make_link(expected_source, target)
            return FixOutcome(
                rule, issue.skill, safety, style,
                "would fix" if dry_run else "fixed",
                f"relinked -> {expected_source}", str(target),
            )
        if style == "remove":
            if not dry_run and (target.exists() or is_link_like(target)):
                remove_entry(target)
                drop_install(registry, target)
                remove_lock_entry(registry, issue.skill, agent)
            return FixOutcome(
                rule, issue.skill, safety, style,
                "would fix" if dry_run else "fixed",
                "removed link", str(target),
            )

    # --- missing-skill ---
    if rule == "missing-skill":
        if style == "relink":
            if expected_source is None:
                return FixOutcome(
                    rule, issue.skill, safety, style, "skipped",
                    "no matching skill in registry; use --fix-style missing-skill=remove --unsafe", str(target),
                )
            note = f"relinked -> {expected_source}"
            if not dry_run:
                if not is_link_like(target) and target.is_dir() and not no_backup:
                    arc = backup_dirs([target], "lint-fix-backup")
                    if arc:
                        note += f" (backup {arc.name})"
                if target.exists() or is_link_like(target):
                    if not is_link_like(target) and target.is_dir():
                        remove_tree_local(target)
                    else:
                        remove_entry(target)
                make_link(expected_source, target)
            return FixOutcome(rule, issue.skill, safety, style, "would fix" if dry_run else "fixed", note, str(target))
        if style == "remove":
            note = "removed entry without SKILL.md"
            if not dry_run and (target.exists() or is_link_like(target)):
                if not is_link_like(target) and target.is_dir() and not no_backup:
                    arc = backup_dirs([target], "lint-fix-backup")
                    if arc:
                        note += f" (backup {arc.name})"
                if not is_link_like(target) and target.is_dir():
                    remove_tree_local(target)
                else:
                    remove_entry(target)
                drop_record(registry, target)
                drop_install(registry, target)
                remove_lock_entry(registry, issue.skill, agent)
            return FixOutcome(rule, issue.skill, safety, style, "would fix" if dry_run else "fixed", note, str(target))

    # --- hard-copy sync states ---
    rec = get_record(registry, target)
    if rule == "source-changed":
        if rec is None:
            return FixOutcome(rule, issue.skill, safety, style, "skipped", "copy record no longer present", str(target))
        if style == "update":
            st, det = sync_copy(rec, registry, force=False, dry_run=dry_run)
            return FixOutcome(
                rule, issue.skill, safety, style,
                "failed" if st == "failed" else ("would fix" if dry_run else "fixed"),
                det, str(target),
            )
        if style == "relink":
            src_path = Path(rec.source)
            if not src_path.exists():
                return FixOutcome(rule, issue.skill, safety, style, "failed", "source missing", str(target))
            note = f"converted copy -> link ({src_path})"
            if not dry_run:
                if target.is_dir() and not is_link_like(target) and not no_backup:
                    arc = backup_dirs([target], "lint-fix-backup")
                    if arc:
                        note += f" (backup {arc.name})"
                if target.exists() or is_link_like(target):
                    remove_tree_local(target) if (target.is_dir() and not is_link_like(target)) else remove_entry(target)
                make_link(src_path, target)
                drop_record(registry, target)
            return FixOutcome(rule, issue.skill, safety, style, "would fix" if dry_run else "fixed", note, str(target))

    if rule == "missing-target":
        if rec is None:
            return FixOutcome(rule, issue.skill, safety, style, "skipped", "copy record absent", str(target))
        if style == "restore":
            st, det = sync_copy(rec, registry, force=True, dry_run=dry_run)
            return FixOutcome(
                rule, issue.skill, safety, style,
                "failed" if st == "failed" else ("would fix" if dry_run else "fixed"),
                det, str(target),
            )
        if style == "forget":
            if not dry_run:
                drop_record(registry, target)
                drop_install(registry, target)
            return FixOutcome(rule, issue.skill, safety, style, "would fix" if dry_run else "fixed", "dropped missing copy record", str(target))

    if rule == "missing-source":
        if style == "forget":
            if not dry_run:
                drop_record(registry, target)
            return FixOutcome(rule, issue.skill, safety, style, "would fix" if dry_run else "fixed", "dropped orphaned copy record", str(target))
        if style == "remove":
            note = "removed orphaned copy + record"
            if not dry_run:
                if target.is_dir() and not is_link_like(target) and not no_backup:
                    arc = backup_dirs([target], "lint-fix-backup")
                    if arc:
                        note += f" (backup {arc.name})"
                if target.exists() or is_link_like(target):
                    remove_tree_local(target) if (target.is_dir() and not is_link_like(target)) else remove_entry(target)
                drop_record(registry, target)
                drop_install(registry, target)
            return FixOutcome(rule, issue.skill, safety, style, "would fix" if dry_run else "fixed", note, str(target))

    if rule in {"target-modified", "both-changed"}:
        if rec is None:
            return FixOutcome(rule, issue.skill, safety, style, "skipped", "copy record absent", str(target))
        if style == "overwrite":
            note = "overwrote local copy from source"
            if not dry_run:
                if target.is_dir() and not is_link_like(target) and not no_backup:
                    arc = backup_dirs([target], "lint-fix-backup")
                    if arc:
                        note += f" (backup {arc.name})"
                st, det = sync_copy(rec, registry, force=True, dry_run=False)
                if st == "failed":
                    return FixOutcome(rule, issue.skill, safety, style, "failed", det, str(target))
            return FixOutcome(rule, issue.skill, safety, style, "would fix" if dry_run else "fixed", note, str(target))
        if style == "accept-local":
            if not dry_run:
                remember_copy(registry, rec.skill, Path(rec.source), target)
            return FixOutcome(rule, issue.skill, safety, style, "would fix" if dry_run else "fixed", "updated stored fingerprints to current state", str(target))
        if style == "forget":
            if not dry_run:
                drop_record(registry, target)
            return FixOutcome(rule, issue.skill, safety, style, "would fix" if dry_run else "fixed", "untracked copy from database", str(target))

    if rule == "target-replaced":
        if style == "forget":
            if not dry_run:
                drop_record(registry, target)
            return FixOutcome(rule, issue.skill, safety, style, "would fix" if dry_run else "fixed", "dropped stale hard-copy record", str(target))
        if style == "restore" and rec is not None:
            st, det = sync_copy(rec, registry, force=True, dry_run=dry_run)
            return FixOutcome(
                rule, issue.skill, safety, style,
                "failed" if st == "failed" else ("would fix" if dry_run else "fixed"),
                det, str(target),
            )

    if rule == "stale-copy":
        if expected_source is None:
            return FixOutcome(rule, issue.skill, safety, style, "failed", f"missing {AGENT_SOURCE.as_posix()}", str(target))
        hard = style == "update"
        st, det = deploy_agent_file(
            expected_source, target, hard=hard, force=False,
            registry=registry, dry_run=dry_run,
        )
        return FixOutcome(
            rule, issue.skill, safety, style,
            "failed" if st == "failed" else ("would fix" if dry_run else "fixed"),
            det, str(target),
        )

    return FixOutcome(rule, issue.skill, safety, style, "skipped", "no automatic action", str(target))


def _apply_readme_fix(
    finding: LintFinding,
    style: str,
    *,
    registry: Path,
    unsafe: bool,
    dry_run: bool,
) -> FixOutcome:
    readme = registry / README_NAME
    if style == "ignore":
        return FixOutcome(finding.rule, "-", "safe", style, "ignored", "skipped by style", str(readme))
    if not readme.is_file():
        return FixOutcome(finding.rule, "-", "safe", style, "failed", f"{README_NAME} not found", str(readme))

    from .analysis import expected_catalog

    catalog = expected_catalog(registry)
    archive_root = next(
        (registry / n for n in ("_Archive", "Archive") if (registry / n).is_dir()),
        registry / "Archive",
    )
    archived_n = len(walk_skills(archive_root, prune=False)) if archive_root.is_dir() else 0
    standalone_n = sum(1 for info in catalog.values() if info["category"] == STANDALONE_CATEGORY)
    groups_n = len({info["category"] for info in catalog.values()} - {STANDALONE_CATEGORY})
    total_n = len(catalog)

    text = readme.read_text(encoding="utf-8", errors="replace")
    updated = text
    replacements = [
        (r"(Total active skills:\s*\*\*)(\d+)(\*\*)", rf"\g<1>{total_n}\g<3>"),
        (r"\b(\d+)(\s+standalone)\b", rf"{standalone_n}\g<2>"),
        (r"\b(\d+)(\s+topic groups)\b", rf"{groups_n}\g<2>"),
        (r"\b(\d+)(\s+archived)\b", rf"{archived_n}\g<2>"),
    ]
    for pattern, repl in replacements:
        updated = re.sub(pattern, repl, updated, count=1)

    if updated == text:
        return FixOutcome(finding.rule, "-", "safe", style, "skipped", "README header counts already match or pattern absent", str(readme))
    if not dry_run:
        readme.write_text(updated, encoding="utf-8")
    return FixOutcome(
        finding.rule, "-", "safe", style,
        "would fix" if dry_run else "fixed",
        f"updated header counts ({total_n} active, {standalone_n} standalone, {groups_n} groups, {archived_n} archived)",
        str(readme),
    )


# ---------------------------------------------------------------------------
# Main fix orchestration entry point
# ---------------------------------------------------------------------------


def apply_lint_fixes(
    findings: Sequence[LintFinding],
    *,
    registry: Path,
    unsafe: bool = False,
    dry_run: bool = False,
    no_backup: bool = False,
    style_overrides: dict[str, str] | None = None,
    only_rules: set[str] | None = None,
    skip_rules: set[str] | None = None,
    description_limit: int = DEFAULT_DESCRIPTION_LIMIT,
) -> list[FixOutcome]:
    """Execute fixes for all collected ``findings`` according to safety & styles.

    Returns a list of ``FixOutcome`` rows and renders a structured fix report.
    """
    overrides = style_overrides or {}
    only = only_rules or set()
    skip = skip_rules or set()

    known = registry_skills(registry)
    nested = nested_skill_index(registry)
    remote_index = remote_skill_index()

    outcomes: list[FixOutcome] = []
    seen_readme_counts = False

    for finding in findings:
        rule = finding.rule
        if rule not in FIX_CATALOG:
            continue
        if only and rule not in only:
            continue
        if rule in skip:
            outcomes.append(FixOutcome(rule, finding.target_name, "safe", "skip", "ignored", "excluded by --skip-fix", str(finding.path)))
            continue
        if rule == "readme-counts":
            if seen_readme_counts:
                continue
            seen_readme_counts = True

        spec = FIX_CATALOG[rule]
        if rule in overrides:
            style = overrides[rule]
        elif "all" in overrides and overrides["all"] in spec.styles:
            style = overrides["all"]
        else:
            style = spec.default_style

        try:
            if spec.category == "metadata":
                outcome = _apply_metadata_fix(
                    finding, style, unsafe=unsafe, dry_run=dry_run, limit=description_limit
                )
            elif spec.category == "version":
                outcome = _apply_version_fix(
                    finding, style, registry=registry, unsafe=unsafe, dry_run=dry_run
                )
            elif spec.category == "sync":
                outcome = _apply_sync_fix(
                    finding, style, registry=registry, known=known, nested=nested,
                    remote_index=remote_index, unsafe=unsafe, dry_run=dry_run, no_backup=no_backup,
                )
            elif spec.category == "readme":
                outcome = _apply_readme_fix(
                    finding, style, registry=registry, unsafe=unsafe, dry_run=dry_run
                )
            else:
                outcome = FixOutcome(rule, finding.target_name, "safe", style, "skipped", "unknown category", str(finding.path))
        except OSError as exc:
            outcome = FixOutcome(rule, finding.target_name, "safe", style, "failed", str(exc), str(finding.path))

        outcomes.append(outcome)

    if outcomes:
        mode_tag = "safe + unsafe" if unsafe else "safe only"
        if dry_run:
            mode_tag += ", dry-run"
        rows = [
            [o.rule, o.target_name, o.safety, o.style, o.status, o.detail, o.path]
            for o in outcomes
        ]
        display_table(
            ["Rule", "Target", "Safety", "Style", "Status", "Detail", "Path"],
            rows,
            title=f"lint fix report ({len(outcomes)} items; {mode_tag})",
            always=True,
        )
        counts = Counter(o.status for o in outcomes)
        display_counts(counts, title="fix summary")
        unsafe_n = counts.get("unsafe-skipped", 0)
        if unsafe_n and not unsafe:
            display_info(
                f"{unsafe_n} unsafe fix(es) were skipped by default; "
                "re-run with `lint --fix --unsafe` (or `--dry-run`) to apply them"
            )
    else:
        display_info("no fixable lint findings matched the active filters")

    return outcomes
