"""Filesystem primitives, SQLite state store, copy manifests, locks, and backups."""

from __future__ import annotations

import json
import os
import shutil
import sqlite3
import stat
import subprocess
import sys
import zipfile
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any, Iterable, Sequence

from .config import (
    AGENT_MD_SUBDIRS,
    AGENT_SKILL_SUBDIRS,
    DB_APP_DIR,
    DB_FILE_NAME,
    LEGACY_STORE_FILES,
)


def home_dir() -> Path:
    override = os.environ.get("MANAGER_HOME")
    return Path(override).expanduser() if override else Path.home()


def is_reparse(path: Path) -> bool:
    """True for symlinks and junctions on Windows (and symlinks elsewhere)."""
    try:
        st = os.lstat(path)
    except OSError:
        return False
    attrs = getattr(st, "st_file_attributes", 0)
    return bool(attrs & getattr(stat, "FILE_ATTRIBUTE_REPARSE_POINT", 0)) or stat.S_ISLNK(st.st_mode)


def is_link_like(path: Path) -> bool:
    return path.is_symlink() or is_reparse(path)


def same_path(a: Path, b: Path) -> bool:
    try:
        return os.path.normcase(os.path.realpath(a)) == os.path.normcase(os.path.realpath(b))
    except OSError:
        return False


def has_skill(path: Path) -> bool:
    try:
        return (path / "SKILL.md").is_file()
    except OSError:
        return False


def is_under(child: Path, parent: Path) -> bool:
    try:
        child_s = os.path.normcase(os.path.abspath(child))
        parent_s = os.path.normcase(os.path.abspath(parent))
        return os.path.commonpath([child_s, parent_s]) == parent_s
    except ValueError:
        return False


def remove_entry(path: Path) -> str:
    """Remove a link, junction or real entry. Returns the kind removed."""
    if path.is_symlink():
        path.unlink()
        return "symlink"
    if is_reparse(path):
        os.rmdir(path)
        return "junction"
    if path.is_dir():
        shutil.rmtree(path)
        return "directory"
    path.unlink()
    return "file"


def clear_entries(entries: Iterable[Path]) -> None:
    for entry in entries:
        if entry.exists() or is_link_like(entry):
            remove_entry(entry)


def remove_tree_local(path: Path) -> None:
    """Delete a real directory tree WITHOUT following links or junctions:
    nested reparse points are removed as entries, never descended."""
    for entry in os.scandir(path):
        child = Path(entry.path)
        if is_link_like(child):
            remove_entry(child)
        elif entry.is_dir(follow_symlinks=False):
            remove_tree_local(child)
        else:
            child.unlink()
    path.rmdir()


def make_link(source: Path, dest: Path) -> str:
    """Create a directory symlink, falling back to a junction if needed."""
    dest.parent.mkdir(parents=True, exist_ok=True)
    try:
        os.symlink(source, dest, target_is_directory=True)
        return "symlink"
    except OSError as exc:
        if _make_junction(source, dest):
            return "junction"
        raise exc


def _make_junction(source: Path, dest: Path) -> bool:
    if os.name != "nt":
        return False
    try:
        result = subprocess.run(
            ["cmd", "/c", "mklink", "/J", str(dest), str(source)],
            capture_output=True,
            text=True,
        )
    except OSError:
        return False
    return result.returncode == 0 and dest.exists()


def platform_data_dir() -> Path:
    if sys.platform.startswith("win"):
        base = os.environ.get("LOCALAPPDATA") or str(Path.home() / "AppData" / "Local")
    elif sys.platform == "darwin":
        base = str(Path.home() / "Library" / "Application Support")
    else:
        base = os.environ.get("XDG_DATA_HOME") or str(Path.home() / ".local" / "share")
    return Path(base) / DB_APP_DIR


def db_path() -> Path:
    override = os.environ.get("MANAGER_DB")
    if override:
        return Path(override).expanduser()
    return platform_data_dir() / DB_FILE_NAME


def db_connect() -> sqlite3.Connection:
    path = db_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(path))
    try:
        conn.execute(
            "CREATE TABLE IF NOT EXISTS kv ("
            "registry TEXT NOT NULL, store TEXT NOT NULL, data TEXT NOT NULL, "
            "updated_at TEXT NOT NULL, PRIMARY KEY (registry, store))"
        )
        _ensure_agents_table(conn)
        _ensure_remotes_table(conn)
    except sqlite3.Error:
        conn.close()
        raise
    return conn


def _ensure_agents_table(conn: sqlite3.Connection) -> None:
    """Create the agents table and seed the built-in defaults once per name.
    Rows (including removal tombstones) survive later calls, so a removed
    default is never resurrected behind the user's back."""
    conn.execute(
        "CREATE TABLE IF NOT EXISTS agents ("
        "name TEXT PRIMARY KEY, skill_dir TEXT NOT NULL, "
        "md_paths TEXT NOT NULL DEFAULT '[]', "
        "origin TEXT NOT NULL DEFAULT 'seed', updated_at TEXT NOT NULL)"
    )
    now = datetime.now().isoformat(timespec="seconds")
    for name, subdir in AGENT_SKILL_SUBDIRS.items():
        mds = json.dumps([p.as_posix() for p in AGENT_MD_SUBDIRS.get(name, [])])
        conn.execute(
            "INSERT OR IGNORE INTO agents (name, skill_dir, md_paths, origin, updated_at) "
            "VALUES (?, ?, ?, 'seed', ?)",
            (name, subdir.as_posix(), mds, now),
        )
    conn.commit()


def _ensure_remotes_table(conn: sqlite3.Connection) -> None:
    conn.execute(
        "CREATE TABLE IF NOT EXISTS remotes ("
        "name TEXT PRIMARY KEY, url TEXT NOT NULL, subpath TEXT NOT NULL DEFAULT '', "
        "ref TEXT NOT NULL DEFAULT '', head TEXT NOT NULL DEFAULT '', "
        "added_at TEXT NOT NULL, updated_at TEXT NOT NULL)"
    )
    conn.commit()


def _registry_key(registry: Path) -> str:
    return os.path.normcase(os.path.abspath(str(registry)))


def kv_get(registry: Path, store: str) -> Any | None:
    """Read one store blob; a legacy JSON file is imported (and then removed)."""
    conn = db_connect()
    try:
        row = conn.execute(
            "SELECT data FROM kv WHERE registry = ? AND store = ?",
            (_registry_key(registry), store),
        ).fetchone()
        if row is not None:
            try:
                return json.loads(row[0])
            except json.JSONDecodeError:
                return None
    finally:
        conn.close()
    legacy = registry / LEGACY_STORE_FILES.get(store, "")
    if not LEGACY_STORE_FILES.get(store) or not legacy.is_file():
        return None
    try:
        data = json.loads(legacy.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None
    if isinstance(data, dict):
        kv_set(registry, store, data)
        try:
            legacy.unlink()
        except OSError:
            pass
        return data
    return None


def kv_set(registry: Path, store: str, data: Any) -> None:
    conn = db_connect()
    try:
        conn.execute(
            "INSERT INTO kv (registry, store, data, updated_at) VALUES (?, ?, ?, ?) "
            "ON CONFLICT(registry, store) DO UPDATE SET data = excluded.data, "
            "updated_at = excluded.updated_at",
            (_registry_key(registry), store, json.dumps(data, indent=2, sort_keys=True),
             datetime.now().isoformat(timespec="seconds")),
        )
        conn.commit()
    finally:
        conn.close()


def _key(path: Path | str) -> str:
    return os.path.normcase(os.path.abspath(str(path)))


def load_installs(registry: Path) -> dict[str, Any]:
    data = kv_get(registry, "installs")
    if not isinstance(data, dict):
        return {"version": 1, "into": {}}
    if not isinstance(data.get("into"), dict):
        data["into"] = {}
    return data


def record_install(registry: Path, target: Path, source: Path, mode: str, project: Path) -> None:
    data = load_installs(registry)
    data.setdefault("into", {})[_key(target)] = {
        "skill": target.name,
        "target": str(target),
        "source": str(source),
        "mode": mode,
        "project": str(project),
        "installed_at": datetime.now().isoformat(timespec="seconds"),
    }
    kv_set(registry, "installs", data)


def prune_installs(registry: Path) -> list[str]:
    """Drop index rows whose target path no longer exists. Returns removed keys."""
    data = load_installs(registry)
    into = data.setdefault("into", {})
    removed = [key for key, entry in into.items()
               if not Path(entry.get("target", "")).exists()
               and not is_link_like(Path(entry.get("target", "")))]
    for key in removed:
        del into[key]
    if removed:
        kv_set(registry, "installs", data)
    return removed


def drop_install(registry: Path, target: Path) -> bool:
    """Remove the --into install index row for a target, if present."""
    data = load_installs(registry)
    into = data.setdefault("into", {})
    if _key(target) in into:
        del into[_key(target)]
        kv_set(registry, "installs", data)
        return True
    return False


@dataclass
class CopyRecord:
    skill: str
    source: str
    target: str
    kind: str  # "dir" or "file"
    fingerprint: str
    target_fingerprint: str
    files: int
    copied_at: str

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "CopyRecord":
        return cls(
            skill=str(data.get("skill", "")),
            source=str(data.get("source", "")),
            target=str(data.get("target", "")),
            kind=str(data.get("kind", "dir")),
            fingerprint=str(data.get("fingerprint", "")),
            target_fingerprint=str(data.get("target_fingerprint", "")),
            files=int(data.get("files", 0) or 0),
            copied_at=str(data.get("copied_at", "")),
        )

    def to_dict(self) -> dict[str, Any]:
        return {
            "skill": self.skill,
            "source": self.source,
            "target": self.target,
            "kind": self.kind,
            "fingerprint": self.fingerprint,
            "target_fingerprint": self.target_fingerprint,
            "files": self.files,
            "copied_at": self.copied_at,
        }


def load_manifest(registry: Path) -> dict[str, Any]:
    data = kv_get(registry, "copies")
    if not isinstance(data, dict):
        return {"version": 1, "copies": {}}
    data.setdefault("version", 1)
    copies = data.setdefault("copies", {})
    if not isinstance(copies, dict):
        data["copies"] = {}
    return data


def save_manifest(registry: Path, data: dict[str, Any]) -> None:
    kv_set(registry, "copies", data)


def load_records(registry: Path) -> dict[str, CopyRecord]:
    data = load_manifest(registry)
    records: dict[str, CopyRecord] = {}
    for key, value in data.get("copies", {}).items():
        if isinstance(value, dict):
            records[str(key)] = CopyRecord.from_dict(value)
    return records


def get_record(registry: Path, target: Path) -> CopyRecord | None:
    return load_records(registry).get(_key(target))


def record_copy(registry: Path, record: CopyRecord) -> None:
    data = load_manifest(registry)
    data.setdefault("copies", {})[_key(record.target)] = record.to_dict()
    save_manifest(registry, data)


def drop_record(registry: Path, target: Path) -> None:
    data = load_manifest(registry)
    copies = data.setdefault("copies", {})
    if _key(target) in copies:
        del copies[_key(target)]
        save_manifest(registry, data)


def load_lockfile(registry_root: Path) -> dict[str, Any]:
    data = kv_get(registry_root, "lock")
    if not isinstance(data, dict):
        return {"version": 1, "locked": {}}
    data.setdefault("version", 1)
    data.setdefault("locked", {})
    return data


def save_lockfile(registry_root: Path, data: dict[str, Any]) -> None:
    kv_set(registry_root, "lock", data)


def record_locks(registry_root: Path, names: Iterable[str], agents: Iterable[str]) -> None:
    data = load_lockfile(registry_root)
    locked = data.setdefault("locked", {})
    now = datetime.now().isoformat(timespec="seconds")
    for name in names:
        entry = locked.setdefault(name, {})
        for agent in agents:
            entry[agent] = now
    save_lockfile(registry_root, data)


def remove_lock_entry(registry: Path, name: str, agent: str | None) -> None:
    """Drop the --lock row for (skill, agent); prune the skill when empty."""
    if agent is None:
        return
    data = load_lockfile(registry)
    entry = data.get("locked", {}).get(name)
    if isinstance(entry, dict) and agent in entry:
        del entry[agent]
        if not entry:
            del data["locked"][name]
        save_lockfile(registry, data)


def backup_dirs(dirs: Sequence[Path], label: str = "skill-sync-backup") -> Path | None:
    existing = [directory for directory in dirs if directory.exists()]
    if not existing:
        return None
    stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    archive = home_dir() / f"{label}-{stamp}.zip"
    archive.parent.mkdir(parents=True, exist_ok=True)
    seen: set[str] = set()
    with zipfile.ZipFile(archive, "w", zipfile.ZIP_DEFLATED) as bundle:
        for base in existing:
            for dirpath, dirnames, filenames in os.walk(base, followlinks=True):
                root = Path(dirpath)
                real = os.path.normcase(os.path.realpath(root))
                if real in seen:
                    dirnames[:] = []
                    continue
                seen.add(real)
                for filename in filenames:
                    source = root / filename
                    try:
                        arcname = base.name / source.relative_to(base)
                        bundle.write(source, arcname=str(arcname))
                    except (OSError, ValueError):
                        continue
    return archive
