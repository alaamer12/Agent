"""Interactive multi-select checklist TUI for reconciling installed skills."""

from __future__ import annotations

import argparse
import os
import shutil
import sys
from pathlib import Path
from typing import Any, Sequence

from .agents import agent_skill_dir, agent_skill_inventory, parse_agents
from .config import Live, ManagerError
from .deploy import cmd_skill, cmd_skill_remove, resolve_into
from .registry import registry_skills
from .reporting import _DISPLAY, _console, display_info, display_table

_QUESTIONARY: Any = None
_QUESTIONARY_TRIED = False


def checklist_step(visible: Sequence[str], selected: set[str], cursor: int,
                   key: str) -> tuple[int, set[str], str]:
    """Pure checklist transitions, shared by the TUI, its tests and prompts.
    Returns (cursor, selected copy, action) with action in move/toggle/all/
    done/quit/none."""
    out = set(selected)
    if key == "up":
        return max(0, cursor - 1), out, "move"
    if key == "down":
        return min(max(0, len(visible) - 1), cursor + 1), out, "move"
    if key == "home":
        return 0, out, "move"
    if key == "end":
        return max(0, len(visible) - 1), out, "move"
    if key == "pgup":
        return max(0, cursor - 10), out, "move"
    if key == "pgdn":
        return min(max(0, len(visible) - 1), cursor + 10), out, "move"
    if key == "space" and visible:
        name = visible[min(cursor, len(visible) - 1)]
        if name in out:
            out.discard(name)
        else:
            out.add(name)
        return cursor, out, "toggle"
    if key == "a" and visible:
        if any(name not in out for name in visible):
            out.update(visible)
        else:
            out.difference_update(visible)
        return cursor, out, "all"
    if key == "enter":
        return cursor, out, "done"
    if key in ("q", "esc", "ctrl-c"):
        return cursor, out, "quit"
    return cursor, out, "none"


def _read_key() -> str:
    """One keypress as a logical name (up/down/space/enter/esc/...); single
    printable characters come back lowercased."""
    if os.name == "nt":
        import msvcrt

        ch = msvcrt.getwch()
        if ch == "\x03":
            return "ctrl-c"
        if ch in ("\x00", "\xe0"):
            extended = msvcrt.getwch()
            return {"H": "up", "P": "down", "K": "left", "M": "right",
                    "G": "home", "O": "end", "I": "pgup", "Q": "pgdn",
                    "S": "delete"}.get(extended, "")
        if ch == "\x1b":
            return "esc"
        if ch in ("\r", "\n"):
            return "enter"
        if ch == "\x08":
            return "backspace"
        if ch == " ":
            return "space"
        return ch.lower()
    import select
    import termios
    import tty

    fd = sys.stdin.fileno()
    old = termios.tcgetattr(fd)
    try:
        tty.setcbreak(fd)
        ch = sys.stdin.read(1)
        if ch == "\x03":
            return "ctrl-c"
        if ch == "\x1b":
            if not select.select([sys.stdin], [], [], 0)[0]:
                return "esc"
            seq = sys.stdin.read(1)
            if seq == "[":
                code = sys.stdin.read(1)
                return {"A": "up", "B": "down", "C": "right", "D": "left",
                        "H": "home", "F": "end", "5": "pgup", "6": "pgdn"}.get(code, "")
            return "esc"
        if ch in ("\r", "\n"):
            return "enter"
        if ch in ("\x7f", "\x08"):
            return "backspace"
        if ch == " ":
            return "space"
        return ch.lower()
    finally:
        termios.tcsetattr(fd, termios.TCSADRAIN, old)


def _checklist_lines(visible: Sequence[str], selected: set[str], cursor: int,
                     installed: set[str], height: int) -> tuple[list[str], int]:
    """Plain-text checklist window; returns (lines, top index kept on screen)."""
    top = min(max(0, cursor), max(0, len(visible) - 1))
    if cursor >= top + height:
        top = cursor - height + 1
    elif cursor < top:
        top = cursor
    top = max(0, min(top, len(visible) - height))
    lines = []
    for index in range(top, min(top + height, len(visible))):
        name = visible[index]
        box = "x" if name in selected else " "
        mark = ">" if index == cursor else " "
        tag = "installed" if name in installed else "-"
        lines.append(f"{mark} [{box}] {name:<30} {tag}")
    if not lines:
        lines.append("  (no skills match the filter)")
    return lines, top


def _questionary() -> Any:
    """Return the questionary module, or None when it is not installed.

    Imported on demand: only the interactive picker needs it, and prompt_toolkit
    is heavy enough to be noticed by --help and --json runs."""
    global _QUESTIONARY, _QUESTIONARY_TRIED
    if not _QUESTIONARY_TRIED:
        _QUESTIONARY_TRIED = True
        try:
            import questionary as module
        except Exception:  # pragma: no cover - exercised only without questionary
            module = None
        _QUESTIONARY = module
    return _QUESTIONARY


def _questionary_style(q: Any) -> Any:
    """One palette shared by the picker and the apply confirmation."""
    return q.Style([
        ("qmark", "fg:ansicyan bold"),
        ("question", "bold"),
        ("pointer", "fg:ansicyan bold"),
        ("highlighted", "fg:ansicyan bold"),
        ("selected", "fg:ansigreen"),
        ("answer", "fg:ansigreen bold"),
        ("instruction", "fg:ansibrightblack"),
        ("text", ""),
    ])


def _pick_checkbox(q: Any, names: Sequence[str], selected: set[str],
                   installed: set[str]) -> set[str] | None:
    """Multi-select through questionary: coloured rows, a real cursor row and
    type-to-filter search. None means the user cancelled."""
    width = min(36, max([len(name) for name in names] + [12]))
    choices = [
        q.Choice(
            title=(f"{name}{' ' * max(2, width - len(name))}installed"
                   if name in installed else name),
            value=name,
            checked=name in selected,
        )
        for name in names
    ]
    try:
        answer = q.checkbox(
            f"skills: {len(set(names) & selected)} of {len(names)} installed"
            " - keep the ones you want",
            choices=choices,
            style=_questionary_style(q),
            use_search_filter=True,
            use_jk_keys=False,
        ).ask(kbi_msg="")
    except (KeyboardInterrupt, EOFError):
        return None
    return None if answer is None else set(answer)


def _pick_tui(names: Sequence[str], selected: set[str], installed: set[str]) -> set[str] | None:
    """Interactive multi-select: questionary when it is installed and colour is
    on, otherwise the built-in key loop. None means the user cancelled."""
    q = _questionary()
    if q is not None and _DISPLAY.color:
        return _pick_checkbox(q, names, selected, installed)
    return _pick_keys(names, selected, installed)


def _pick_keys(names: Sequence[str], selected: set[str], installed: set[str]) -> set[str] | None:
    """Arrow-key multi-select rendered with rich Live (or ANSI redraw). None
    means the user cancelled."""
    state_selected = set(selected)
    cursor = 0
    pending_filter = ""
    committed_filter = ""
    mode = "nav"
    height = max(5, shutil.get_terminal_size((100, 30)).lines - 8)
    sys.stdout.write("\x1b[?25l")

    def visible_now() -> list[str]:
        needle = committed_filter.lower()
        return [n for n in names if not needle or needle in n.lower()]

    def frame() -> str:
        visible = visible_now()
        lines, _top = _checklist_lines(visible, state_selected, cursor, installed, height)
        done = sum(1 for n in visible if n in state_selected)
        header = (f"skills: {len(state_selected & set(names))}/{len(names)} selected"
                  f" ({done}/{len(visible)} shown)"
                  + (f"   filter: {committed_filter}" if committed_filter else ""))
        hint = ("up/down move - space toggle - a all/none - / filter - enter plan - q quit"
                + ("   [typing filter: enter applies, esc cancels]" if mode == "filter" else ""))
        return "\n".join([header, *lines, hint])

    console = _console()
    use_live = console is not None and Live is not None
    if use_live:
        from rich.text import Text

    live: Any = None
    try:
        if use_live:
            live = Live(Text(frame()), console=console, transient=True,
                        refresh_per_second=12)
            live.__enter__()
        else:
            sys.stdout.write("\x1b[2J\x1b[H" + frame() + "\n")
            sys.stdout.flush()
        while True:
            key = _read_key()
            if key == "":
                continue
            redraw = True
            if mode == "filter":
                if key == "enter":
                    committed_filter = pending_filter
                    mode = "nav"
                elif key in ("esc", "ctrl-c"):
                    pending_filter = committed_filter
                    mode = "nav"
                elif key == "backspace":
                    pending_filter = pending_filter[:-1]
                elif len(key) == 1 and key.isprintable():
                    pending_filter += key
                else:
                    redraw = False
            elif key == "/":
                pending_filter = committed_filter
                mode = "filter"
            else:
                visible = visible_now()
                cursor, state_selected, action = checklist_step(visible, state_selected, cursor, key)
                cursor = min(cursor, max(0, len(visible) - 1))
                if action == "done":
                    return state_selected
                if action == "quit":
                    return None
                if action == "none":
                    redraw = False
            if not redraw:
                continue
            if live is not None:
                live.update(Text(frame()))
            else:
                sys.stdout.write("\x1b[2J\x1b[H" + frame() + "\n")
                sys.stdout.flush()
    finally:
        if live is not None:
            live.__exit__(None, None, None)
        sys.stdout.write("\x1b[0m\x1b[?25h")
        sys.stdout.flush()


def _pick_fallback(names: Sequence[str], selected: set[str], installed: set[str]) -> set[str] | None:
    """Numbered-prompt multi-select for pipes, dumb terminals and --no-tui."""
    shown = set(selected)
    display_info("[interactive] numbered picker (type skill numbers to toggle them)")
    for index, name in enumerate(names, start=1):
        box = "x" if name in shown else " "
        tag = " installed" if name in installed else ""
        print(f"  {index:>3}. [{box}] {name}{tag}")
    while True:
        try:
            raw = input("choose> ").strip().lower()
        except EOFError:
            return None
        if not raw:
            continue
        if raw in ("done", "d"):
            return shown
        if raw == "quit":
            return None
        if raw == "all":
            shown = set(names)
            continue
        if raw == "none":
            shown = set()
            continue
        for token in raw.replace(",", " ").split():
            if not token.isdigit():
                print(f"  ? '{token}' is not a number, 'all', 'none', 'done' or 'quit'")
                continue
            index = int(token)
            if not 1 <= index <= len(names):
                print(f"  ? no skill number {index} (1..{len(names)})")
                continue
            name = names[index - 1]
            if name in shown:
                shown.discard(name)
            else:
                shown.add(name)


def _confirm_apply(use_tui: bool) -> bool:
    """Ask before touching anything; a TUI answer gets a TUI question."""
    q = _questionary() if use_tui and _DISPLAY.color else None
    if q is not None:
        try:
            return bool(q.confirm("Apply changes?", default=False,
                                  style=_questionary_style(q)).ask(kbi_msg=""))
        except (KeyboardInterrupt, EOFError):
            return False
    try:
        answer = input("Apply changes? [y/N] ").strip().lower()
    except EOFError:
        answer = ""
    return answer in ("y", "yes")


def cmd_interactive(args: argparse.Namespace, registry: Path, jobs: int, invoked: set[str]) -> int:
    """Reconcile what stays installed: multi-select the skills to keep, then
    apply installs/uninstalls behind one [y/N] confirmation."""
    into = resolve_into(args.into) if args.into else None
    if into is not None and ({"-A", "--agents"} & invoked):
        raise ManagerError("--into targets one folder; drop --agents")
    skills = registry_skills(registry)
    if not skills:
        raise ManagerError("the registry holds no skills to pick from")
    if into is not None:
        roots: list[tuple[str, Path, str | None]] = [(f"into {into}", into, None)]
    else:
        roots = [(agent, agent_skill_dir(agent), agent) for agent in parse_agents(args.agents)]
    installed: set[str] = set()
    for _label, root, _agent in roots:
        installed.update(item["name"] for item in agent_skill_inventory(root, registry))

    names = sorted(skills, key=str.lower)
    selected = {name for name in names if name in installed}
    tui = not args.no_tui and sys.stdin.isatty() and sys.stdout.isatty()
    if tui:
        chosen = _pick_tui(names, selected, installed)
    else:
        chosen = _pick_fallback(names, selected, installed)
    if chosen is None:
        display_info("[interactive] cancelled; nothing changed")
        return 0

    to_install = sorted(chosen - installed, key=str.lower)
    to_remove = sorted(installed & (set(names) - chosen), key=str.lower)
    foreign = sorted(installed - set(names))
    rows = [[name, "install"] for name in to_install] + [[name, "uninstall"] for name in to_remove]
    title = (f"interactive plan: {len(to_install)} install, {len(to_remove)} uninstall, "
              f"{len(chosen & installed)} keep, {len(names) - len(chosen) - len(to_remove)} absent")
    if rows:
        display_table(["Skill", "Action"], rows, title=title, always=True)
    else:
        display_info(f"{title}; nothing to change")
        return 0
    if foreign:
        display_info(f"left untouched (installed but not registry skills): {', '.join(foreign)}")
    if args.dry_run:
        display_info("[interactive] dry-run: plan shown, nothing applied")
        return 0
    if not _confirm_apply(tui):
        display_info("[interactive] declined; nothing changed")
        return 0

    rc = 0
    if to_install:
        deploy_args = argparse.Namespace(
            skills=to_install, all=False, agents=args.agents, lock=args.lock,
            refresh=False, remove=False, list=False, remote=None, into=args.into,
            hard_copy=args.hard_copy, mode=args.mode, force=args.force,
            dry_run=False)
        rc |= cmd_skill(deploy_args, registry, jobs, set())
    if to_remove:
        remove_args = argparse.Namespace(
            skills=to_remove, all=False, agents=args.agents, dry_run=False,
            force=args.force, no_backup=args.no_backup)
        rc |= cmd_skill_remove(remove_args, registry, into)
    return rc
