"""Unified Rich + ANSI + Plain reporting engine for manager.py.

Design goals
------------
1. **Guaranteed styled output**: When ``rich`` is installed and color is not
   explicitly disabled (``--no-color`` or ``NO_COLOR``), Rich consoles are
   initialized with ``force_terminal=True`` and Windows Virtual Terminal
   processing is enabled via ``ctypes`` so colors render even inside IDE
   consoles, Git Bash/mintty, and subprocess wrappers where ``isatty()`` is
   False. When ``rich`` is not installed, every table, panel, banner, rule,
   count strip, and status message renders with ANSI SGR styling.
2. **Readable long names and paths**: Paths are compacted with ``~`` for the
   home directory and truncated in the middle with ``...`` while keeping root
   and leaf segments intact (e.g. ``Groups/.../scss-modules/SKILL.md``). Long
   identifiers are middle-truncated with ``...`` so both prefix and suffix stay
   visible.
3. **Organized long lists**: Tables dynamically allocate column widths to fit
   the current terminal, color-code semantic statuses, right-align numbers, and
   cap long tables (default 40 rows; ``--full`` or ``--limit 0`` shows all)
   while prioritizing errors, warnings, and active changes ahead of routine
   ``unchanged``/``absent`` rows.
"""

from __future__ import annotations

import os
import re
import shutil
import sys
from collections import Counter
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable, Literal, Sequence

from .config import (
    Console,
    DEFAULT_TABLE_ROW_LIMIT,
    Panel,
    RICH_AVAILABLE,
    Rule,
    Table,
    Text,
    rich_box,
)

ColumnKind = Literal["text", "name", "path", "status", "number", "detail", "type"]

ANSI_RE = re.compile(r"\x1b\[[0-9;]*[A-Za-z]")
URL_SCHEME_RE = re.compile(r"^([a-z][a-z0-9+.-]*://[^/]+)(/.*)?$", re.I)
ANSI_RESET = "\x1b[0m"

# Semantic style token -> (rich style, ANSI SGR code)
THEME: dict[str, tuple[str, str]] = {
    "title": ("bold bright_cyan", "\x1b[1;96m"),
    "subtitle": ("dim", "\x1b[2m"),
    "header": ("bold cyan", "\x1b[1;36m"),
    "border": ("dim cyan", "\x1b[2;36m"),
    "key": ("bold white", "\x1b[1;37m"),
    "name": ("bold white", "\x1b[1;37m"),
    "path": ("bright_blue", "\x1b[94m"),
    "type": ("magenta", "\x1b[35m"),
    "number": ("cyan", "\x1b[36m"),
    "muted": ("bright_black", "\x1b[90m"),
    "ok": ("bold green", "\x1b[1;32m"),
    "warn": ("bold yellow", "\x1b[1;33m"),
    "error": ("bold red", "\x1b[1;31m"),
    "info": ("bold cyan", "\x1b[1;36m"),
    "accent": ("bold magenta", "\x1b[1;35m"),
}

_STATUS_OK = {
    "linked", "copied", "updated", "restored", "repaired", "created", "added",
    "cloned", "re-registered", "clean", "ok", "yes", "install", "installed",
    "managed-copy", "symlink", "junction", "command", "fixed", "safe",
}
_STATUS_WARN = {
    "relinked", "replaced", "skipped", "protected", "modified", "untracked",
    "mixed", "stale-copy", "source-changed", "target-modified", "target-replaced",
    "unmanaged-dir", "uninstall", "unlinked", "removed", "removed copy", "unsafe", "unsafe-skipped",
    "removed tree", "removed file", "mandatory", "not fetched",
}
_STATUS_ERROR = {
    "failed", "broken-link", "missing-source", "missing-target", "missing-skill",
    "missing-locked", "source-unreadable", "target-unreadable", "both-changed",
    "over", "missing", "tombstoned", "deleted", "dir absent",
}
_STATUS_MUTED = {"unchanged", "kept", "absent", "ignored", "no", "-", "seed", "none", "no skills installed"}
_ROUTINE_STATUSES = {"unchanged", "kept", "absent", "ignored", "ok", "clean", "-"}


@dataclass
class DisplayConfig:
    """Global runtime display state shared across commands."""

    quiet: bool = False
    color: bool = True
    verbose: bool = False
    full: bool = False
    max_rows: int = DEFAULT_TABLE_ROW_LIMIT


_DISPLAY = DisplayConfig()
_CONSOLE_OUT: Any = None
_CONSOLE_ERR: Any = None
_VT_ENABLED = False


def _enable_windows_ansi() -> None:
    """Enable ENABLE_VIRTUAL_TERMINAL_PROCESSING on Windows stdout/stderr."""
    global _VT_ENABLED
    if _VT_ENABLED or os.name != "nt":
        return
    _VT_ENABLED = True
    try:
        import ctypes

        kernel32 = ctypes.windll.kernel32  # type: ignore[attr-defined]
        for handle_id in (-11, -12):  # STD_OUTPUT_HANDLE, STD_ERROR_HANDLE
            handle = kernel32.GetStdHandle(handle_id)
            mode = ctypes.c_uint32()
            if kernel32.GetConsoleMode(handle, ctypes.byref(mode)):
                kernel32.SetConsoleMode(handle, mode.value | 0x0004)
    except Exception:
        pass


def configure_display(
    *,
    quiet: bool,
    color: bool,
    verbose: bool,
    full: bool = False,
    max_rows: int = DEFAULT_TABLE_ROW_LIMIT,
) -> None:
    """Configure display flags and reset cached Rich Console instances."""
    global _CONSOLE_OUT, _CONSOLE_ERR
    _DISPLAY.quiet = quiet
    _DISPLAY.color = color
    _DISPLAY.verbose = verbose
    _DISPLAY.full = full
    _DISPLAY.max_rows = max(0, max_rows)
    _CONSOLE_OUT = None
    _CONSOLE_ERR = None
    if color:
        _enable_windows_ansi()


def _rich_on() -> bool:
    """Return True when Rich rendering is available and color is enabled."""
    return RICH_AVAILABLE and _DISPLAY.color


def _term_width() -> int:
    """Return the exact column width used by the active renderer (Rich or TTY)."""
    if _rich_on():
        con = _console()
        if con is not None and getattr(con, "width", 0):
            return max(60, int(con.width))
    try:
        cols = shutil.get_terminal_size((100, 30)).columns
    except OSError:
        cols = 100
    return max(60, cols)


def _console(*, stderr: bool = False) -> Any:
    """Return a cached Rich Console configured to always emit styled output.

    Passing ``force_terminal=True`` fixes the common issue where IDE runners,
    Git Bash/mintty, or subprocess wrappers report ``isatty() == False`` and
    cause Rich to strip all colors silently.
    """
    global _CONSOLE_OUT, _CONSOLE_ERR
    if not _rich_on():
        return None
    if stderr:
        if _CONSOLE_ERR is None:
            _CONSOLE_ERR = Console(
                stderr=True,
                force_terminal=True,
                color_system="auto",
                no_color=False,
                highlight=False,
                soft_wrap=False,
            )
        return _CONSOLE_ERR
    if _CONSOLE_OUT is None:
        _CONSOLE_OUT = Console(
            force_terminal=True,
            color_system="auto",
            no_color=False,
            highlight=False,
            soft_wrap=False,
        )
    return _CONSOLE_OUT


def _ansi(text: str, token: str | None) -> str:
    """Wrap ``text`` in ANSI SGR color sequences when color is enabled."""
    if not _DISPLAY.color or not token or token not in THEME:
        return text
    return f"{THEME[token][1]}{text}{ANSI_RESET}"


def _rich_text(text: str, token: str | None = None) -> Any:
    """Build a markup-safe Rich Text object so ``[...]`` in strings never breaks."""
    style = THEME[token][0] if (token and token in THEME) else ""
    return Text(text, style=style)


# ---------------------------------------------------------------------------
# String, Path & List Compaction Utilities
# ---------------------------------------------------------------------------


def strip_ansi(text: str) -> str:
    """Strip ANSI SGR escape sequences from ``text``."""
    return ANSI_RE.sub("", text)


def visible_len(text: str) -> int:
    """Return visible printable width of ``text`` ignoring ANSI escapes."""
    return len(strip_ansi(text))


def _cell(value: Any) -> str:
    """Normalize any value into a clean single-line cell string."""
    text = "" if value is None else str(value)
    return text.replace("\r", " ").replace("\n", " ").strip()


def _home_str() -> str:
    override = os.environ.get("MANAGER_HOME")
    base = Path(override).expanduser() if override else Path.home()
    try:
        return str(base.resolve())
    except OSError:
        return str(base)


def shorten_home(raw: str) -> str:
    """Replace the user home directory prefix with ``~``."""
    if not raw or raw.startswith("~"):
        return raw
    home = _home_str().rstrip("\\/")
    if not home:
        return raw
    norm_raw = os.path.normcase(raw)
    norm_home = os.path.normcase(home)
    if norm_raw == norm_home:
        return "~"
    sep = "\\" if ("\\" in raw and "/" not in raw) else "/"
    for candidate in ("\\", "/"):
        if norm_raw.startswith(norm_home + candidate):
            return f"~{sep}{raw[len(home) + 1:]}"
    return raw


def truncate_middle(text: str, max_width: int, ellipsis: str = "...") -> str:
    """Truncate ``text`` in the middle with ``ellipsis``, preserving head and tail.

    Example::
        truncate_middle("very-long-skill-identifier-v2", 18) -> "very-long...ier-v2"
    """
    if max_width <= 0 or len(text) <= max_width:
        return text
    if max_width <= len(ellipsis):
        return text[:max_width]
    keep = max_width - len(ellipsis)
    head = (keep + 1) // 2
    tail = keep - head
    return f"{text[:head]}{ellipsis}{text[-tail:]}" if tail > 0 else text[:head] + ellipsis


def truncate_end(text: str, max_width: int, ellipsis: str = "...") -> str:
    """Truncate ``text`` at the right edge with ``ellipsis``."""
    if max_width <= 0 or len(text) <= max_width:
        return text
    if max_width <= len(ellipsis):
        return text[:max_width]
    return text[: max_width - len(ellipsis)].rstrip() + ellipsis


def truncate_path(raw: str, max_width: int, ellipsis: str = "...") -> str:
    """Path- and URL-aware middle truncation that preserves root and leaf segments.

    Examples::
        truncate_path("Groups/Frontend/Styling/scss-modules/SKILL.md", 36)
        -> "Groups/.../scss-modules/SKILL.md"
        truncate_path("-> C:\\Users\\dev\\.claude\\skills\\avatar", 30)
        -> "-> ~\\...\\skills\\avatar"
    """
    if not raw:
        return raw
    if raw.startswith("-> "):
        inner_w = max(0, max_width - 3) if max_width > 0 else 0
        return f"-> {truncate_path(raw[3:], inner_w, ellipsis)}"
    if " -> " in raw:
        left, right = raw.split(" -> ", 1)
        combined = f"{shorten_home(left)} -> {shorten_home(right)}"
        if max_width <= 0 or len(combined) <= max_width:
            return combined
        budget = max(12, max_width - 4)
        right_w = max(8, int(budget * 0.58))
        left_w = max(6, budget - right_w)
        return f"{truncate_path(left, left_w, ellipsis)} -> {truncate_path(right, right_w, ellipsis)}"

    compact = shorten_home(raw)
    if max_width <= 0 or len(compact) <= max_width:
        return compact

    url_match = URL_SCHEME_RE.match(compact)
    if url_match:
        origin, rest = url_match.group(1), url_match.group(2) or ""
        parts = [p for p in rest.split("/") if p]
        if len(parts) >= 2:
            best = f"{origin}/{ellipsis}/{parts[-1]}"
            if len(best) <= max_width:
                idx = len(parts) - 2
                while idx >= 1:
                    trial = f"{origin}/{ellipsis}/{'/'.join(parts[idx:])}"
                    if len(trial) <= max_width:
                        best = trial
                        idx -= 1
                    else:
                        break
                return best
        return truncate_middle(compact, max_width, ellipsis)

    sep = "\\" if ("\\" in compact and "/" not in compact) else "/"
    parts = compact.split(sep)
    non_empty = [p for p in parts if p]
    if len(non_empty) >= 3:
        prefix = sep if parts[0] == "" else ""
        head = [non_empty[0]]
        tail = [non_empty[-1]]

        def render(h: list[str], t: list[str]) -> str:
            return prefix + sep.join([*h, ellipsis, *t])

        best = render(head, tail)
        if len(best) <= max_width:
            lo, hi = 1, len(non_empty) - 2
            while lo <= hi:
                trial_tail = [non_empty[hi], *tail]
                cand = render(head, trial_tail)
                if len(cand) <= max_width:
                    tail, best, hi = trial_tail, cand, hi - 1
                    continue
                trial_head = [*head, non_empty[lo]]
                cand = render(trial_head, tail)
                if len(cand) <= max_width:
                    head, best, lo = trial_head, cand, lo + 1
                    continue
                break
            return best

    return truncate_middle(compact, max_width, ellipsis)


def format_list_compact(
    items: Sequence[str],
    *,
    max_items: int = 6,
    max_item_width: int = 28,
    separator: str = ", ",
) -> str:
    """Format a potentially long list of names into a concise inline summary."""
    cleaned = [_cell(item) for item in items if _cell(item)]
    if not cleaned:
        return "none"
    if _DISPLAY.full:
        return separator.join(cleaned)
    shown = [truncate_middle(item, max_item_width) for item in cleaned[:max_items]]
    extra = len(cleaned) - len(shown)
    return separator.join(shown) + (f" (+{extra} more)" if extra > 0 else "")


# ---------------------------------------------------------------------------
# Column Inference, Width Budgeting & Row Prioritization
# ---------------------------------------------------------------------------


def _infer_column_kind(header: str) -> ColumnKind:
    """Infer semantic column type from a header label.

    Exact numeric/status/type matches are checked before substring path matches
    so headers like ``Files`` resolve as ``number`` instead of ``path``.
    """
    low = header.strip().lower()
    if low in {"count", "files", "chars", "desc chars", "mention lines", "skills"}:
        return "number"
    if low in {"status", "state", "action", "fetch", "git", "result", "mutual", "skill.md only", "safety", "default safety"}:
        return "status"
    if low in {"type", "kind", "mode", "origin", "section", "phase", "version", "category", "style", "default style", "default"}:
        return "type"
    if low in {
        "skill", "agent", "remote", "from", "to", "entry", "parent",
        "where", "setting", "ambiguous name", "rule",
    }:
        return "name"
    if any(k in low for k in (
        "path", "target", "source", "dir", "url", "file", "evidence", "instruction",
    )):
        return "path"
    if any(k in low for k in (
        "detail", "issue", "note", "reason", "text", "candidate",
        "error", "accepted", "finding", "suggested", "condition", "styles",
    )):
        return "detail"
    return "text"


def status_token(value: str) -> str:
    """Map a status/state/action cell value to a semantic theme token."""
    low = value.strip().lower()
    if not low or low in _STATUS_MUTED:
        return "muted"
    if low in _STATUS_ERROR or low.startswith(("missing", "broken", "failed")):
        return "error"
    if low in _STATUS_WARN or low.startswith(("would ", "stale", "unmanaged")):
        return "warn"
    if low in _STATUS_OK:
        return "ok"
    return "info"


def _allocate_widths(
    headers: Sequence[str],
    kinds: Sequence[ColumnKind],
    rows: Sequence[Sequence[str]],
) -> list[int]:
    """Compute column widths that fit inside the current terminal width."""
    available = max(40, _term_width() - (len(headers) * 3 + 1))
    natural = [
        max(len(headers[i]), *(len(row[i]) for row in rows))
        for i in range(len(headers))
    ]
    if _DISPLAY.full:
        return natural

    soft_caps: dict[ColumnKind, int] = {
        "path": 48,
        "detail": 46,
        "name": 28,
        "text": 36,
        "type": 18,
        "status": 18,
        "number": 12,
    }
    mins: dict[ColumnKind, int] = {
        "path": 16,
        "detail": 16,
        "name": 10,
        "text": 10,
        "type": 8,
        "status": 8,
        "number": 5,
    }
    widths = [
        min(natural[i], max(len(headers[i]), soft_caps[kinds[i]]))
        for i in range(len(headers))
    ]

    for shrink_group in ({"detail", "path"}, {"text", "name"}, {"type", "status"}):
        while sum(widths) > available:
            candidates = [
                i for i, k in enumerate(kinds)
                if k in shrink_group and widths[i] > mins[k]
            ]
            if not candidates:
                break
            widest = max(candidates, key=lambda i: widths[i])
            widths[widest] -= 1

    # Guarantee total width fits even on narrow 80-col terminals with 8-10 columns
    while sum(widths) > available:
        candidates = [i for i in range(len(widths)) if widths[i] > 4]
        if not candidates:
            break
        widest = max(candidates, key=lambda i: widths[i])
        widths[widest] -= 1

    return widths


def _format_cell(value: str, kind: ColumnKind, width: int) -> str:
    """Apply middle/path truncation to a cell unless ``--full`` is active."""
    if _DISPLAY.full:
        return shorten_home(value) if kind in {"path", "detail"} else value
    if kind == "path":
        return truncate_path(value, width)
    if kind == "detail":
        if " -> " in value or value.startswith("-> "):
            return truncate_path(value, width)
        return truncate_middle(value, width)
    if kind in {"name", "text"}:
        return truncate_middle(value, width)
    return value


def _cell_token(value: str, kind: ColumnKind) -> str | None:
    if value in {"", "-"}:
        return "muted"
    if kind == "status":
        return status_token(value)
    if kind in {"name", "path", "type", "number"}:
        return kind
    return None


def _cap_rows(
    kinds: Sequence[ColumnKind],
    rows: list[list[str]],
    limit: int | None,
) -> tuple[list[list[str]], str | None]:
    """Cap long tables while surfacing errors, warnings, and active changes first."""
    effective = _DISPLAY.max_rows if limit is None else limit
    if _DISPLAY.full or _DISPLAY.verbose or effective <= 0 or len(rows) <= effective:
        return rows, None

    status_col = next((i for i, k in enumerate(kinds) if k == "status"), None)
    if status_col is not None:
        rank = {"error": 0, "warn": 1, "info": 2, "ok": 3, "muted": 4}
        indexed = list(enumerate(rows))
        indexed.sort(
            key=lambda pair: (
                1 if pair[1][status_col].strip().lower() in _ROUTINE_STATUSES else 0,
                rank.get(status_token(pair[1][status_col]), 3),
                pair[0],
            )
        )
        kept = [r for _, r in indexed[:effective]]
        omitted = [r for _, r in indexed[effective:]]
        breakdown = Counter(r[status_col].strip().lower() or "-" for r in omitted)
        summary = ", ".join(f"{cnt} {lbl}" for lbl, cnt in breakdown.most_common(3))
        footer = (
            f"... showing {effective} of {len(rows)} rows "
            f"({len(omitted)} omitted: {summary}); pass --full or --limit 0 to show all"
        )
        return kept, footer

    omitted_count = len(rows) - effective
    footer = (
        f"... showing {effective} of {len(rows)} rows "
        f"({omitted_count} omitted); pass --full or --limit 0 to show all"
    )
    return rows[:effective], footer


# ---------------------------------------------------------------------------
# Public Display API
# ---------------------------------------------------------------------------


def display_rule(title: str = "") -> None:
    """Render a subtle horizontal section divider."""
    if _DISPLAY.quiet:
        return
    if _rich_on():
        _console().print(Rule(title, style=THEME["border"][0], align="left"))
        return
    prefix = f"-- {title} " if title else ""
    line = prefix + "-" * max(4, min(72, _term_width()) - len(prefix))
    print(_ansi(line, "border"))


def display_table(
    headers: Sequence[Any],
    rows: Sequence[Sequence[Any]],
    *,
    title: str | None = None,
    always: bool = False,
    max_rows: int | None = None,
) -> None:
    """Render a width-aware, color-coded table via Rich or ANSI/ASCII fallback."""
    if (_DISPLAY.quiet and not always) or not rows:
        return

    norm_headers = [_cell(h) for h in headers]
    kinds = [_infer_column_kind(h) for h in norm_headers]
    norm_rows = [[_cell(c) for c in row] for row in rows]
    shown_rows, footer = _cap_rows(kinds, norm_rows, max_rows)
    widths = _allocate_widths(norm_headers, kinds, shown_rows)
    formatted = [
        [_format_cell(row[i], kinds[i], widths[i]) for i in range(len(norm_headers))]
        for row in shown_rows
    ]
    shown_headers = [
        header if _DISPLAY.full else truncate_end(header, widths[i], ".")
        for i, header in enumerate(norm_headers)
    ]

    if _rich_on():
        table = Table(
            title=_rich_text(title, "title") if title else None,
            caption=_rich_text(footer, "muted") if footer else None,
            box=rich_box.ROUNDED if rich_box else None,
            border_style=THEME["border"][0],
            header_style=THEME["header"][0],
            title_justify="left",
            caption_justify="left",
            pad_edge=True,
        )
        for header, kind, width in zip(shown_headers, kinds, widths):
            table.add_column(
                header,
                justify="right" if kind == "number" else "left",
                max_width=None if _DISPLAY.full else width,
                no_wrap=not _DISPLAY.full,
                overflow="fold" if _DISPLAY.full else "crop",
            )
        for row in formatted:
            table.add_row(*[
                _rich_text(cell, _cell_token(cell, kind))
                for cell, kind in zip(row, kinds)
            ])
        _console().print(table)
        return

    col_w = [
        max(len(shown_headers[i]), *(len(r[i]) for r in formatted))
        for i in range(len(shown_headers))
    ]
    sep = _ansi("+" + "+".join("-" * (w + 2) for w in col_w) + "+", "border")

    def render_row(cells: Sequence[str], *, is_header: bool = False) -> str:
        rendered: list[str] = []
        for i, cell in enumerate(cells):
            padded = (
                cell.rjust(col_w[i])
                if (not is_header and kinds[i] == "number")
                else cell.ljust(col_w[i])
            )
            token = "header" if is_header else _cell_token(cell, kinds[i])
            rendered.append(_ansi(padded, token))
        pipe = _ansi("|", "border")
        return f"{pipe} " + f" {pipe} ".join(rendered) + f" {pipe}"

    if title:
        print(_ansi(title, "title"))
    print(sep)
    print(render_row(shown_headers, is_header=True))
    print(sep)
    for row in formatted:
        print(render_row(row))
    print(sep)
    if footer:
        print(_ansi(footer, "muted"))


def display_banner(title: str, lines: Iterable[str], *, level: str = "warning") -> None:
    """Render an attention banner (never suppressed by --quiet)."""
    token = {
        "warning": "warn",
        "error": "error",
        "info": "info",
        "success": "ok",
    }.get(level, "warn")
    max_w = max(44, _term_width() - 6)
    cleaned = [
        truncate_path(_cell(line), max_w) if not _DISPLAY.full else _cell(line)
        for line in lines
        if _cell(line)
    ]
    body = "\n".join(cleaned)

    if _rich_on():
        _console().print(
            Panel(
                Text(body),
                title=_rich_text(f" {title} ", token),
                title_align="left",
                border_style=THEME[token][0],
                box=rich_box.ROUNDED if rich_box else None,
            )
        )
        return

    width = max([len(title), *(len(line) for line in cleaned), 20])
    bar = _ansi("+" + "-" * (width + 2) + "+", token)
    pipe = _ansi("|", token)
    print(bar)
    print(f"{pipe} {_ansi(title.ljust(width), token)} {pipe}")
    print(bar)
    for line in cleaned:
        print(f"{pipe} {line.ljust(width)} {pipe}")
    print(bar)


def display_kv(
    pairs: Sequence[tuple[str, Any]],
    *,
    title: str | None = None,
    always: bool = False,
) -> None:
    """Render a compact key/value summary panel."""
    if (_DISPLAY.quiet and not always) or not pairs:
        return
    max_val = max(24, _term_width() - 32)
    formatted_pairs: list[tuple[str, str]] = []
    for key, val in pairs:
        k_str, v_str = _cell(key), _cell(val)
        if not _DISPLAY.full:
            if any(w in k_str.lower() for w in ("registry", "path", "source", "root", "dir", "remote")):
                v_str = truncate_path(v_str, max_val)
            else:
                v_str = truncate_middle(v_str, max_val)
        formatted_pairs.append((k_str, v_str))

    if _rich_on():
        grid = Table.grid(padding=(0, 2))
        grid.add_column(style=THEME["key"][0], no_wrap=True)
        grid.add_column(overflow="fold")
        for k_str, v_str in formatted_pairs:
            k_low = k_str.lower()
            if any(w in k_low for w in ("registry", "path", "source", "remote")):
                tok: str | None = "path"
            elif v_str.isdigit():
                tok = "number"
            elif v_str in {"-", "none", "0"}:
                tok = "muted"
            else:
                tok = None
            grid.add_row(k_str, _rich_text(v_str, tok))
        _console().print(
            Panel(
                grid,
                title=_rich_text(f" {title} ", "title") if title else None,
                title_align="left",
                border_style=THEME["border"][0],
                box=rich_box.ROUNDED if rich_box else None,
                expand=False,
            )
        )
        return

    display_table(["Setting", "Value"], formatted_pairs, title=title, always=always, max_rows=0)


def display_command_report(
    command: str,
    *,
    settings: Sequence[tuple[str, Any]],
    flags: Sequence[str],
    implicit: bool = False,
) -> None:
    """Render the compact command settings header card."""
    if _DISPLAY.quiet:
        return
    pairs = list(settings)
    pairs.append(("Flags", ", ".join(flags) if flags else "none"))
    title = f"manager {command}" + (" (default)" if implicit else "")
    display_kv(pairs, title=title)


def display_counts(counts: Counter[str], *, title: str = "summary") -> None:
    """Render an inline color-coded strip summarizing operation result counts."""
    if _DISPLAY.quiet or not counts:
        return
    order = [
        "fixed", "would fix", "linked", "relinked", "copied", "updated", "restored", "repaired",
        "replaced", "created", "unlinked", "removed", "unchanged", "kept",
        "unsafe-skipped", "ignored", "skipped", "protected", "absent",
        "would link", "would relink", "would copy", "would update",
        "would restore", "would repair", "would replace", "would create",
        "failed",
    ]
    ordered = [(name, counts[name]) for name in order if counts.get(name)]
    ordered.extend((name, cnt) for name, cnt in sorted(counts.items()) if name not in order and cnt)
    if not ordered:
        return

    if _rich_on():
        line = Text()
        line.append(f"{title}: ", style=THEME["title"][0])
        for idx, (label, count) in enumerate(ordered):
            if idx:
                line.append("  |  ", style=THEME["muted"][0])
            tok = status_token(label)
            line.append(f"{label} ", style=THEME[tok][0])
            line.append(str(count), style=THEME["key"][0])
        _console().print(line)
        return

    parts = [
        f"{_ansi(label, status_token(label))} {_ansi(str(count), 'key')}"
        for label, count in ordered
    ]
    print(f"{_ansi(title + ':', 'title')} " + _ansi(" | ", "muted").join(parts))


def display_info(message: str) -> None:
    """Render a styled informational line."""
    if _DISPLAY.quiet:
        return
    raw = _cell(message)
    text = raw if _DISPLAY.full else truncate_path(raw, max(40, _term_width() - 8))
    if _rich_on():
        line = Text()
        line.append("info ", style=THEME["info"][0])
        line.append(text)
        _console().print(line)
        return
    print(f"{_ansi('[info]', 'info')} {text}")


def display_ok(message: str) -> None:
    """Render a styled success line."""
    if _DISPLAY.quiet:
        return
    raw = _cell(message)
    text = raw if _DISPLAY.full else truncate_path(raw, max(40, _term_width() - 8))
    if _rich_on():
        line = Text()
        line.append("ok   ", style=THEME["ok"][0])
        line.append(text)
        _console().print(line)
        return
    print(f"{_ansi('[ok]', 'ok')} {text}")


def display_warn(message: str) -> None:
    """Render a styled warning line to stderr."""
    raw = _cell(message)
    text = raw if _DISPLAY.full else truncate_path(raw, max(40, _term_width() - 8))
    if _rich_on():
        line = Text()
        line.append("warn ", style=THEME["warn"][0])
        line.append(text)
        _console(stderr=True).print(line)
        return
    print(f"{_ansi('[warn]', 'warn')} {text}", file=sys.stderr)


def display_error(message: str) -> None:
    """Render a styled error line to stderr."""
    text = _cell(message)
    if _rich_on():
        line = Text()
        line.append("err  ", style=THEME["error"][0])
        line.append(text)
        _console(stderr=True).print(line)
        return
    print(f"{_ansi('[error]', 'error')} {text}", file=sys.stderr)
