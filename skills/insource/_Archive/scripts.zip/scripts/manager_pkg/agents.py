"""Registered code-agent management, installed-skill inventory, and claim sync."""

from __future__ import annotations

import argparse
import json
import os
from collections import Counter
from datetime import datetime
from pathlib import Path
from typing import Any, Sequence

from .config import (
    AGENT_NAME_RE,
    AGENT_SKILL_SUBDIRS,
    ALIASES,
    ManagerError,
    REGISTRY,
)
from .reporting import display_counts, display_info, display_table
from .storage import (
    backup_dirs,
    db_connect,
    drop_record,
    get_record,
    has_skill,
    home_dir,
    is_link_like,
    is_under,
    remove_entry,
    remove_tree_local,
    same_path,
)

_AGENTS_CACHE: dict[str, dict[str, Any]] | None = None


def _agent_path(raw: str) -> Path:
    """A stored path may be absolute (user-set) or relative to the home
    directory (seeded default)."""
    path = Path(raw).expanduser()
    return path if path.is_absolute() else home_dir() / path


def agents_all(*, include_removed: bool = False) -> dict[str, dict[str, Any]]:
    """The agents table as {name: {skill_dir, md_paths, origin}}; removal
    tombstones are hidden unless asked for."""
    global _AGENTS_CACHE
    if _AGENTS_CACHE is None:
        conn = db_connect()
        try:
            rows = conn.execute(
                "SELECT name, skill_dir, md_paths, origin FROM agents ORDER BY name"
            ).fetchall()
        finally:
            conn.close()
        parsed: dict[str, dict[str, Any]] = {}
        for name, skill_dir, md_raw, origin in rows:
            try:
                mds = json.loads(md_raw)
            except (json.JSONDecodeError, TypeError):
                mds = []
            parsed[name] = {"skill_dir": skill_dir,
                            "md_paths": [str(m) for m in mds if str(m)],
                            "origin": origin}
        _AGENTS_CACHE = parsed
    if include_removed:
        return dict(_AGENTS_CACHE)
    return {n: r for n, r in _AGENTS_CACHE.items() if r["origin"] != "removed"}


def _agents_cache_clear() -> None:
    global _AGENTS_CACHE
    _AGENTS_CACHE = None


def agent_names() -> list[str]:
    return list(agents_all())


def agent_skill_dir(agent: str) -> Path:
    row = agents_all().get(agent)
    if row is None or not row["skill_dir"]:
        raise ManagerError(
            f"agent '{agent}' is not registered in the agents table; add it with "
            f"`manager.py agents --set {agent} --skill-dir PATH`"
        )
    return _agent_path(row["skill_dir"])


def agent_md_targets(agent: str) -> list[Path]:
    row = agents_all().get(agent)
    if row is None:
        raise ManagerError(
            f"agent '{agent}' is not registered in the agents table; add it with "
            f"`manager.py agents --set {agent} --skill-dir PATH`"
        )
    return [_agent_path(rel) for rel in row["md_paths"]]


def parse_agents(raw: str) -> list[str]:
    available = agent_names()
    if not raw:
        return available
    requested = [part.strip().lower() for part in raw.replace(",", " ").split() if part.strip()]
    if not requested or "all" in requested:
        return available
    result: list[str] = []
    unknown: list[str] = []
    for item in requested:
        name = ALIASES.get(item, item)
        if name not in agents_all():
            unknown.append(item)
        elif name not in result:
            result.append(name)
    if unknown:
        raise ManagerError(
            f"unknown agent(s): {', '.join(unknown)}. Registered: {', '.join(available)} - "
            f"add one with `manager.py agents --set NAME --skill-dir PATH`"
        )
    return result


def _store_agent_path(raw: str) -> str:
    """Store a user-supplied path as an absolute posix string."""
    return Path(raw).expanduser().absolute().as_posix()


def agents_set(name: str, *, skill_dir: str | None = None,
               md_paths: Sequence[str] | None = None, override: bool = False) -> tuple[str, str]:
    """Register or update one agents row. Returns (status, detail).
    Conflicts - a differing existing row or another agent owning the same
    skill dir - raise ManagerError unless override is set."""
    name = name.strip().lower()
    if not AGENT_NAME_RE.match(name):
        raise ManagerError(
            f"invalid agent name '{name}': lowercase letters, digits, dot, dash, "
            f"underscore, starting alphanumeric, max 32 characters"
        )
    all_rows = agents_all(include_removed=True)
    visible = agents_all()
    existing = all_rows.get(name)
    tombstoned = existing is not None and existing["origin"] == "removed"
    new_skill = _store_agent_path(skill_dir) if skill_dir else None
    new_mds = [_store_agent_path(p) for p in md_paths] if md_paths else None
    if new_skill is None and new_mds is None:
        raise ManagerError("agents --set needs at least --skill-dir or --md-path")
    if tombstoned and new_skill is None:
        raise ManagerError(f"agent '{name}' was removed; re-registering needs --skill-dir")
    if new_skill:
        clash = next((n for n, r in visible.items() if n != name and r["skill_dir"] == new_skill), None)
        if clash and not override:
            raise ManagerError(
                f"conflict: the skill dir '{new_skill}' already belongs to agent '{clash}'. "
                f"Pass --override to let '{name}' share it."
            )
    final_skill = new_skill or (existing["skill_dir"] if existing else "")
    final_mds = new_mds if new_mds is not None else (existing["md_paths"] if existing else [])
    if existing is not None and not tombstoned:
        if existing["skill_dir"] == final_skill and existing["md_paths"] == final_mds:
            return "unchanged", f"skill: {final_skill}; md: {', '.join(final_mds) or 'none'}"
        if not override:
            raise ManagerError(
                f"conflict: agent '{name}' is already registered as skill '{existing['skill_dir']}'"
                f", md [{', '.join(existing['md_paths']) or 'none'}]; the given values differ. "
                f"Pass --override to replace them."
            )
    conn = db_connect()
    try:
        conn.execute(
            "INSERT INTO agents (name, skill_dir, md_paths, origin, updated_at) VALUES (?, ?, ?, ?, ?) "
            "ON CONFLICT(name) DO UPDATE SET skill_dir = excluded.skill_dir, "
            "md_paths = excluded.md_paths, origin = excluded.origin, updated_at = excluded.updated_at",
            (name, final_skill, json.dumps(final_mds), "user",
             datetime.now().isoformat(timespec="seconds")),
        )
        conn.commit()
    finally:
        conn.close()
    _agents_cache_clear()
    status = "added" if existing is None else ("re-registered" if tombstoned else "updated")
    return status, f"skill: {final_skill}; md: {', '.join(final_mds) or 'none'}"


def agents_remove(name: str) -> str:
    """Remove an agent. Seeded defaults become tombstones so they never
    re-seed behind the user; user-registered rows are deleted outright."""
    name = name.strip().lower()
    if name not in agents_all():
        raise ManagerError(
            f"agent '{name}' is not in the agents table (known: "
            f"{', '.join(agent_names()) or 'none'})"
        )
    conn = db_connect()
    try:
        if name in AGENT_SKILL_SUBDIRS:
            conn.execute(
                "UPDATE agents SET origin = 'removed', skill_dir = '', md_paths = '[]', updated_at = ? "
                "WHERE name = ?",
                (datetime.now().isoformat(timespec="seconds"), name),
            )
        else:
            conn.execute("DELETE FROM agents WHERE name = ?", (name,))
        conn.commit()
    finally:
        conn.close()
    _agents_cache_clear()
    return "tombstoned" if name in AGENT_SKILL_SUBDIRS else "deleted"


def cmd_agents(args: argparse.Namespace) -> int:
    if getattr(args, "inventory", False):
        return cmd_agents_inventory(args)
    if args.set and args.remove:
        raise ManagerError("--set and --remove are exclusive")
    if args.remove:
        kind = agents_remove(args.remove)
        display_info(f"[agents] '{args.remove}' {kind} (deployments on disk were not touched)")
    if args.set:
        status, detail = agents_set(args.set, skill_dir=args.skill_dir,
                                    md_paths=args.md_path, override=args.override)
        display_info(f"[agents] {status} '{args.set}' - {detail}")
    if args.json:
        print(json.dumps(agents_all(), ensure_ascii=False, indent=2))
        return 0
    if not (args.set or args.remove or args.list):
        display_info("no action given; showing the table (see --help for --set/--remove)")
    rows = [[name, r["skill_dir"], " | ".join(r["md_paths"]) or "-", r["origin"]]
            for name, r in sorted(agents_all(include_removed=True).items())]
    display_table(["Agent", "Skill dir", "Instruction files", "Origin"], rows,
                  title=f"{len([r for r in rows if r[3] != 'removed'])} agents (agents table)",
                  always=True)
    return 0


def agent_skill_inventory(directory: Path, registry: Path) -> list[dict[str, Any]]:
    """Installed skills in one agent directory: name, kind, source.
    Links resolve; managed hard copies carry their record's origin."""
    out: list[dict[str, Any]] = []
    try:
        entries = sorted(directory.iterdir(), key=lambda p: p.name.lower())
    except OSError:
        return out
    for entry in entries:
        if entry.name.startswith("."):
            continue
        if is_link_like(entry):
            kind = "symlink" if entry.is_symlink() else "junction"
            if not has_skill(entry):
                kind = "broken-link"
            out.append({"name": entry.name, "kind": kind,
                        "source": os.path.realpath(entry)})
        elif entry.is_dir() and has_skill(entry):
            rec = get_record(registry, entry)
            out.append({"name": entry.name,
                        "kind": "managed-copy" if rec else "unmanaged-dir",
                        "source": rec.source if rec else str(entry)})
    return out


def cmd_agents_inventory(args: argparse.Namespace) -> int:
    registry = (args.registry or REGISTRY).expanduser().resolve()
    data = {}
    rows: list[list[str]] = []
    for name in agent_names():
        directory = agent_skill_dir(name)
        items = agent_skill_inventory(directory, registry)
        data[name] = {"dir": str(directory), "skills": items}
        if not directory.is_dir():
            rows.append([name, "-", "-", "dir absent"])
            continue
        if not items:
            rows.append([name, "-", "-", "no skills installed"])
        for item in items:
            rows.append([name, item["name"], item["kind"], item["source"]])
    if args.json:
        print(json.dumps(data, ensure_ascii=False, indent=2))
        return 0
    total = sum(len(v["skills"]) for v in data.values())
    display_table(["Agent", "Skill", "Kind", "Source"], rows,
                  title=f"agent inventory ({len(data)} agents, {total} installed skills)",
                  always=True)
    return 0


def resolve_agent_dir(raw: str) -> tuple[Path, str]:
    """An agents-table name, or a direct folder path."""
    name = raw.strip().lower()
    if name in agents_all():
        return agent_skill_dir(name), name
    path = Path(raw).expanduser().absolute()
    return path, f"path:{path.as_posix()}"


def cmd_claim(args: argparse.Namespace, registry: Path) -> int:
    """Claim X into Y: Y ends with X's skill set."""
    from .deploy import deploy_skill

    src_dir, src_label = resolve_agent_dir(args.from_agent)
    dst_dir, dst_label = resolve_agent_dir(args.into_agent)
    if same_path(src_dir, dst_dir):
        raise ManagerError("claim source and destination are the same folder")
    if is_under(dst_dir, registry):
        raise ManagerError("refusing to claim INTO the registry itself")
    if args.append and args.force:
        raise ManagerError("--append never removes; --force is meaningless with it")
    if not src_dir.is_dir():
        raise ManagerError(f"source '{src_label}' has no skills folder at {src_dir}")
    src_items = agent_skill_inventory(src_dir, registry)
    if not src_items:
        raise ManagerError(
            f"source '{src_label}' has no installed skills - refusing to claim an empty "
            f"set into '{dst_label}' (name a populated source, or remove entries explicitly)")
    src_items = [i for i in src_items if i["kind"] != "broken-link"]

    rows: list[list[str]] = []
    counts: Counter[str] = Counter()
    failures = 0
    dst_dir.parent.mkdir(parents=True, exist_ok=True)
    src_names = {i["name"] for i in src_items}
    for item in src_items:
        dest = dst_dir / item["name"]
        existing = is_link_like(dest) or dest.is_dir()
        if args.append and existing:
            rows.append([item["name"], src_label, dst_label, "kept",
                         "already installed (append never touches existing)"])
            counts["kept"] += 1
            continue
        mode = "symlink" if item["kind"] in ("symlink", "junction") else "hard-copy"
        source = Path(item["source"])
        # override replaces a same-named UNMANAGED folder: back it up first
        note_extra = ""
        if (existing and not args.append and not args.dry_run
                and not is_link_like(dest) and dest.is_dir()
                and get_record(registry, dest) is None):
            if not args.no_backup:
                archive = backup_dirs([dest], "claim-replace-backup")
                if archive is not None:
                    note_extra = f"; replaced unmanaged folder backed up as {archive.name}"
        status, detail = deploy_skill(
            source, dest, mode=mode, force=not args.append, agent=dst_label,
            registry=registry, dry_run=args.dry_run)
        rows.append([item["name"], str(source), dst_label, status, detail + note_extra])
        counts[status] += 1
        if status == "failed":
            failures += 1

    removed = 0
    if not args.append:
        for extra in agent_skill_inventory(dst_dir, registry):
            if extra["name"] in src_names:
                continue
            entry = dst_dir / extra["name"]
            if extra["kind"] == "broken-link" or is_link_like(entry):
                if not args.dry_run:
                    remove_entry(entry)
                rows.append([extra["name"], dst_label, "-",
                             "would unlink" if args.dry_run else "unlinked", "extra entry removed"])
                removed += 1
            elif extra["kind"] == "managed-copy":
                archive = None
                if not args.dry_run:
                    if not args.no_backup:
                        archive = backup_dirs([entry], "claim-remove-backup")
                    remove_tree_local(entry)
                    drop_record(registry, entry)
                rows.append([extra["name"], dst_label, "-",
                             "would remove copy" if args.dry_run else "removed copy",
                             "managed extra" + (f"; backup {archive.name}" if archive else "")])
                removed += 1
            elif args.force:
                archive = None
                if not args.dry_run:
                    if not args.no_backup:
                        archive = backup_dirs([entry], "claim-remove-backup")
                    remove_tree_local(entry)
                rows.append([extra["name"], dst_label, "-",
                             ("would remove" if args.dry_run else "removed") + " unmanaged",
                             "forced" + (f"; backup {archive.name}" if archive else "")])
                removed += 1
            else:
                rows.append([extra["name"], dst_label, "-", "protected",
                             "unmanaged folder not in source (use --force)"])
                counts["protected"] += 1
    counts["removed"] = removed
    display_table(["Skill", "From", "To", "Action", "Detail"], rows,
                  title=f"claim {src_label} -> {dst_label} "
                        f"({'append' if args.append else 'override'})",
                  always=True)
    display_counts(counts)
    summary = (f"[claim] {dst_label} now has {len(src_names)} of {src_label}'s skill set; "
               f"{counts.get('kept', 0)} kept, {removed} extra(s) removed")
    if args.dry_run:
        summary += " (dry run - nothing changed)"
    display_info(summary)
    return 1 if failures else 0
