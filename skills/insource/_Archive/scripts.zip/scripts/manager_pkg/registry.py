"""Registry discovery, skill classification, frontmatter, hashing, git, and semver tracking."""

from __future__ import annotations

import hashlib
import os
import re
import subprocess
from collections import Counter
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable, Iterable

from .config import (
    INITIAL_VERSION,
    ManagerError,
    SEMVER_RE,
    SKILL_SUPPORT_DIRS,
    SKIP_NAMES,
    yaml,
)
from .storage import (
    has_skill,
    is_link_like,
    is_under,
    kv_get,
    kv_set,
    same_path,
)


FRONTMATTER_RE = re.compile(r"^\ufeff?---[ \t]*\r?\n(.*?)\r?\n---[ \t]*(?:\r?\n|$)", re.S)


def parse_minimal_frontmatter(raw: str) -> dict[str, str]:
    """Tiny YAML subset fallback: scalar keys, quotes and block scalars."""
    data: dict[str, str] = {}
    lines = raw.splitlines()
    index = 0
    while index < len(lines):
        match = re.match(r"^([A-Za-z0-9_-]+):\s*(.*)$", lines[index])
        if not match:
            index += 1
            continue
        key, value = match.group(1), match.group(2).strip()
        if value in {"|", ">", "|-", ">-", "|+", ">+"}:
            block: list[str] = []
            index += 1
            while index < len(lines):
                line = lines[index]
                if line.strip() and not line.startswith((" ", "\t")):
                    break
                block.append(line.strip())
                index += 1
            joiner = " " if value.startswith(">") else "\n"
            data[key] = joiner.join(block).strip()
            continue
        if len(value) >= 2 and value[0] == value[-1] and value[0] in "'\"":
            inner = value[1:-1]
            data[key] = inner.replace("''", "'") if value[0] == "'" else inner
        else:
            data[key] = value
        index += 1
    return data


def read_frontmatter(path: Path) -> tuple[dict[str, Any] | None, str | None]:
    try:
        text = path.read_text(encoding="utf-8", errors="replace")
    except OSError as exc:
        return None, f"unreadable ({exc.__class__.__name__})"
    match = FRONTMATTER_RE.match(text)
    if not match:
        return None, "no frontmatter"
    raw = match.group(1)
    if yaml is not None:
        try:
            data = yaml.safe_load(raw)
        except yaml.YAMLError as exc:
            mark = getattr(exc, "problem_mark", None)
            location = f" at line {mark.line + 2}" if mark is not None else ""
            return None, f"invalid YAML{location}"
        if isinstance(data, dict):
            return data, None
        return None, "frontmatter must be a mapping"
    parsed = parse_minimal_frontmatter(raw)
    return (parsed, None) if parsed else (None, "frontmatter is empty or unparsable")


def iter_files(root: Path) -> Iterable[Path]:
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [
            name
            for name in dirnames
            if name not in SKIP_NAMES
            and not name.startswith(".")
            and not is_link_like(Path(dirpath) / name)
        ]
        for filename in sorted(filenames):
            path = Path(dirpath) / filename
            if not is_link_like(path):
                yield path


def hash_file(path: Path) -> str | None:
    digest = hashlib.sha256()
    try:
        with path.open("rb") as handle:
            for chunk in iter(lambda: handle.read(1024 * 1024), b""):
                digest.update(chunk)
    except OSError:
        return None
    return digest.hexdigest()


def fingerprint_path(path: Path) -> tuple[str, int] | None:
    """Hash a file or directory tree. Returns (fingerprint, file_count)."""
    if not path.exists():
        return None
    if path.is_file():
        digest = hash_file(path)
        return (digest, 1) if digest else None
    if not path.is_dir():
        return None
    entries: list[str] = []
    for file_path in iter_files(path):
        rel = file_path.relative_to(path).as_posix()
        digest = hash_file(file_path)
        entries.append(f"{rel}:{digest or 'unreadable'}")
    combined = hashlib.sha256("\n".join(sorted(entries)).encode("utf-8")).hexdigest()
    return combined, len(entries)


def map_concurrent(func: Callable[[Any], Any], items: Iterable[Any], jobs: int) -> list[Any]:
    values = list(items)
    if len(values) <= 1 or jobs <= 1:
        return [func(value) for value in values]
    with ThreadPoolExecutor(max_workers=min(jobs, len(values))) as pool:
        return list(pool.map(func, values))


def walk_skills(root: Path, *, prune: bool = True) -> list[Path]:
    """Return directories containing SKILL.md without following links."""
    found: list[Path] = []
    owned: set[Path] = set()
    for dirpath, dirnames, _ in os.walk(root):
        current = Path(dirpath)
        if has_skill(current):
            owned.add(current)
            if current != root:
                found.append(current)
                if prune:
                    dirnames[:] = []
                    continue
        inside_skill = current in owned or current.parent in owned
        if inside_skill:
            owned.add(current)
        dirnames[:] = sorted(
            name for name in dirnames
            if name not in SKIP_NAMES and not name.startswith(".")
            and not is_link_like(current / name)
            and (not inside_skill or name.lower() not in SKILL_SUPPORT_DIRS
                 or has_skill(current / name))
        )
    return found


def registry_skills(root: Path) -> dict[str, Path]:
    """name -> path, shallowest wins (so top-level beats Groups copies)."""
    best: dict[str, Path] = {}
    for path in walk_skills(root):
        name = path.name
        previous = best.get(name)
        if previous is None or len(path.relative_to(root).parts) < len(previous.relative_to(root).parts):
            best[name] = path
    return best


def nested_skill_index(root: Path) -> dict[str, Path]:
    """Uniquely-nested skills (meta-children): name -> path.

    registry_skills() lists only what an install can address by name; children
    installed as their own junction (scss under styling, ...) resolve here.
    Ambiguous names are left out so nothing is ever relinked to a guessed
    location. Used by the sync audit and `skill --refresh` to detect and repair
    links when a skill's tree moved inside the registry.
    """
    top = set(registry_skills(root))
    index: dict[str, list[Path]] = {}
    for path in walk_skills(root, prune=False):
        name = path.name
        if name in top:
            continue
        index.setdefault(name, []).append(path)
    return {name: paths[0] for name, paths in index.items() if len(paths) == 1}


@dataclass(frozen=True)
class SkillStructure:
    kind: str
    children: tuple[Path, ...] = ()
    modules: tuple[Path, ...] = ()
    issues: tuple[str, ...] = ()


def inspect_directory(path: Path) -> SkillStructure:
    if not path.is_dir():
        return SkillStructure("broken-link" if is_link_like(path) else "plain")
    children = tuple(walk_skills(path))
    if not has_skill(path):
        return SkillStructure("group" if children else "plain", children)

    modules: list[Path] = []

    def visit(parent: Path) -> None:
        for branch in sorted(parent.iterdir()):
            if (not branch.is_dir() or is_link_like(branch) or has_skill(branch)
                    or branch.name in SKIP_NAMES or branch.name.startswith(".")
                    or branch.name.lower() in SKILL_SUPPORT_DIRS):
                continue
            if any(is_under(child, branch) for child in children):
                visit(branch)
            elif any(file.suffix.lower() == ".md" for file in iter_files(branch)):
                modules.append(branch)

    visit(path)
    kind = "meta-skill" if children else "battery-skill" if modules else "skill"
    issues = ()
    if children and modules:
        names = ", ".join(p.relative_to(path).as_posix() for p in modules)
        issues = (f"mixed composition: independent sub-skills and internal modules ({names}); "
                  "choose meta children with SKILL.md or battery modules without it",)
    return SkillStructure(kind, children, tuple(modules), issues)


def classify_directory(path: Path) -> str:
    return inspect_directory(path).kind


def skill_parent(path: Path, skills: Iterable[Path]) -> Path | None:
    parents = [parent for parent in skills if parent != path and is_under(path, parent)]
    return max(parents, key=lambda parent: len(parent.parts)) if parents else None


def diagnose_missing_skill(name: str, cwd: Path, registry_root: Path) -> str:
    """Provide detailed, actionable diagnostic feedback when a requested skill cannot be resolved."""
    roots: list[Path] = []
    for root in (cwd, registry_root):
        if root and root.is_dir() and not any(same_path(root, r) for r in roots):
            roots.append(root)

    # 1. Check if the name points to an existing directory
    for root in roots:
        candidate = (root / name) if not Path(name).is_absolute() else Path(name)
        if candidate.is_dir():
            structure = inspect_directory(candidate)
            if structure.kind == "group":
                child_count = len(structure.children)
                return (
                    f"'{name}' is an organizational group folder holding {child_count} skill(s), "
                    f"not an independent skill.\n"
                    f"Deploy individual skills instead, or run 'manager.py find {name}' to inspect them."
                )

            parent = skill_parent(candidate, (p for p in candidate.parents if has_skill(p)))
            if parent and any(same_path(candidate, m) for m in inspect_directory(parent).modules):
                return (
                    f"'{name}' is an internal module of the '{parent.name}' battery-skill, "
                    f"not an independent skill.\n"
                    f"Deploy the parent skill instead: 'manager.py skill {parent.name}'"
                )

            if not has_skill(candidate):
                return (
                    f"directory '{name}' exists but has no SKILL.md entrypoint; "
                    f"it cannot be deployed as an independent skill."
                )

    # 2. Check if the requested name matches an internal module of any battery-skill
    search_roots: list[Path] = []
    for root in (cwd, registry_root):
        if root and root.is_dir() and not any(same_path(root, r) for r in search_roots):
            search_roots.append(root)

    for root in search_roots:
        for skill_path in walk_skills(root, prune=False):
            structure = inspect_directory(skill_path)
            for module in structure.modules:
                if module.name == name or module.name.lower() == name.lower():
                    return (
                        f"'{name}' is an internal module of the '{skill_path.name}' battery-skill, "
                        f"not an independent skill.\n"
                        f"Deploy the parent skill instead: 'manager.py skill {skill_path.name}'"
                    )

    # Default fallback
    return f"no skill named '{name}' found in {cwd} or the registry {registry_root}"


def resolve_skill(name: str, cwd: Path, registry_root: Path) -> Path:
    candidate = Path(name).expanduser()
    if candidate.is_dir() and has_skill(candidate):
        return candidate.resolve()

    local = cwd / name
    if local.is_dir() and has_skill(local):
        return local.resolve()

    matches = [path for path in walk_skills(cwd, prune=False) if path.name == name]
    if len(matches) == 1:
        return matches[0].resolve()
    if len(matches) > 1:
        listing = "\n  ".join(str(path) for path in matches)
        raise ManagerError(f"'{name}' is ambiguous under {cwd}:\n  {listing}")

    fallback = registry_skills(registry_root).get(name)
    if fallback is not None:
        return fallback.resolve()

    raise ManagerError(diagnose_missing_skill(name, cwd, registry_root))


def load_versions(registry: Path) -> dict[str, Any]:
    data = kv_get(registry, "versions")
    if not isinstance(data, dict):
        return {"version": 1, "skills": {}}
    data.setdefault("version", 1)
    if not isinstance(data.get("skills"), dict):
        data["skills"] = {}
    return data


def save_versions(registry: Path, data: dict[str, Any]) -> None:
    kv_set(registry, "versions", data)


def _git(cwd: Path, *args: str, strip: bool = True) -> str | None:
    try:
        proc = subprocess.run(
            ["git", "-C", str(cwd), *args],
            capture_output=True, text=True, encoding="utf-8", errors="replace",
            timeout=30,
        )
    except (OSError, subprocess.SubprocessError):
        return None
    if proc.returncode != 0:
        return None
    return proc.stdout.strip() if strip else proc.stdout


def git_root(registry: Path) -> Path | None:
    out = _git(registry, "rev-parse", "--show-toplevel")
    return Path(out) if out else None


def git_head(registry: Path) -> str | None:
    return _git(registry, "rev-parse", "HEAD")


def git_status_map(registry: Path) -> dict[str, str]:
    """Working-tree changes keyed by path relative to the registry."""
    root = git_root(registry)
    if root is None:
        return {}
    out = _git(root, "status", "--porcelain", strip=False)
    if not out:
        return {}
    try:
        reg_rel = registry.resolve().relative_to(root.resolve()).as_posix()
    except ValueError:
        reg_rel = "."
    prefix = "" if reg_rel == "." else reg_rel.rstrip("/") + "/"
    changes: dict[str, str] = {}
    for line in out.splitlines():
        if len(line) < 4:
            continue
        code, path = line[:2], line[3:]
        if " -> " in path:
            path = path.split(" -> ", 1)[1]
        path = path.strip().strip('"')
        if prefix:
            if not path.startswith(prefix):
                continue
            path = path[len(prefix):]
        changes[path] = code
    return changes


def git_last_commit(registry: Path, rel: str) -> str | None:
    out = _git(registry, "log", "-1", "--format=%h %cs", "--", rel)
    return out or None


def skill_git_state(rel: str, status_map: dict[str, str]) -> str:
    if not status_map:
        return "clean"
    prefix = rel.rstrip("/") + "/"
    codes = [code for path, code in status_map.items() if path == rel or path.startswith(prefix)]
    if not codes:
        return "clean"
    if all(code == "??" for code in codes):
        return "untracked"
    if any(code == "??" for code in codes):
        return "mixed"
    return "modified"


def skill_snapshot(path: Path) -> dict[str, Any]:
    files: dict[str, str] = {}
    for file_path in iter_files(path):
        rel = file_path.relative_to(path).as_posix()
        files[rel] = hash_file(file_path) or "unreadable"
    combined = hashlib.sha256(
        "\n".join(f"{rel}:{files[rel]}" for rel in sorted(files)).encode("utf-8")
    ).hexdigest()
    return {"files": files, "fingerprint": combined, "file_count": len(files)}


def classify_change(old_files: dict[str, str], new_files: dict[str, str]) -> tuple[str | None, str]:
    """Suggest a semver bump from a per-file hash diff. Returns (suggestion, reason).

    Rules: edited/renamed files -> patch; new files -> minor; files both added and
    removed (a merge or rewrite) -> major. Renames are paired by identical hash so
    they read as patch, not as add+remove. This is a suggestion, never an auto-bump.
    """
    old_keys, new_keys = set(old_files), set(new_files)
    added = new_keys - old_keys
    deleted = old_keys - new_keys
    modified = {k for k in old_keys & new_keys if old_files[k] != new_files[k]}
    added_by_hash: dict[str, list[str]] = {}
    for k in added:
        added_by_hash.setdefault(new_files[k], []).append(k)
    renames: list[tuple[str, str]] = []
    remaining_deleted: set[str] = set()
    for k in deleted:
        bucket = added_by_hash.get(old_files[k])
        if bucket:
            renames.append((k, bucket.pop()))
        else:
            remaining_deleted.add(k)
    remaining_added = {k for bucket in added_by_hash.values() for k in bucket}
    if remaining_added and remaining_deleted:
        return "major", "files added and removed (possible merge or rewrite)"
    if remaining_added:
        return "minor", "new files added"
    if remaining_deleted:
        return "minor", "files removed"
    if renames and not modified:
        return "patch", "files renamed"
    if modified or renames:
        return "patch", "files edited"
    return None, "no change"


def _is_rename(old_files: dict[str, str], new_files: dict[str, str]) -> bool:
    """True when two snapshots are the same skill under a new name.

    A rename changes the ``name:`` field in SKILL.md, so the tree fingerprint is not
    identical. Treat it as a rename when the file set matches and every file except
    SKILL.md is byte-identical (SKILL.md may differ only by its name field).
    """
    if not old_files or set(old_files) != set(new_files):
        return False
    return all(old_files[k] == new_files[k] for k in old_files if k != "SKILL.md")


def _build_entry(name: str, rel: str, version: str | None, snap: dict[str, Any],
                 head: str | None, files: dict[str, str] | None = None,
                 fingerprint: str | None = None) -> dict[str, Any]:
    return {
        "version": version,
        "name": name,
        "path": rel,
        "commit": head,
        "fingerprint": fingerprint if fingerprint is not None else snap["fingerprint"],
        "file_count": snap["file_count"],
        "files": files if files is not None else snap["files"],
    }


def _norm_version(value: Any) -> str | None:
    if value is None:
        return None
    text = str(value).strip()
    return text or None


def check_versions(registry: Path, jobs: int) -> tuple[list[tuple[str, str, str, str, str]], Counter]:
    """Track registry skill versions against a stored baseline.

    Warns when a skill changed (committed or working-tree) without a version bump,
    suggesting patch/minor/major from the change shape. A move (same name, new path,
    unchanged content) needs no bump; a rename suggests patch. New skills are recorded
    as a baseline. The state file is updated: bumps and moves rebaseline, unbumped
    changes keep the old baseline so the warning persists.
    """
    skills = registry_skills(registry)
    state = load_versions(registry)
    old_entries = state.get("skills", {})
    head = git_head(registry)
    names = sorted(skills)
    snaps = map_concurrent(lambda n: skill_snapshot(skills[n]), names, jobs)
    frontmatters = map_concurrent(lambda n: read_frontmatter(skills[n] / "SKILL.md"), names, jobs)
    current: dict[str, dict[str, Any]] = {}
    for n, snap, (data, _err) in zip(names, snaps, frontmatters):
        current[n] = {
            "rel": skills[n].relative_to(registry).as_posix(),
            "ver": _norm_version(data.get("version") if isinstance(data, dict) else None),
            "snap": snap,
        }
    by_fp: dict[str, str] = {}
    for n, e in old_entries.items():
        if e.get("fingerprint"):
            by_fp.setdefault(e["fingerprint"], n)
    cur_names = set(current)
    warnings: list[tuple[str, str, str, str, str]] = []
    stats: Counter = Counter()
    new_entries: dict[str, Any] = {}
    consumed: set[str] = set()

    for n in names:
        c = current[n]
        snap, rel, ver = c["snap"], c["rel"], c["ver"]
        valid = ver is not None and SEMVER_RE.match(ver) is not None
        if ver is None:
            warnings.append((n, "-", f"set {INITIAL_VERSION}", "missing version", rel))
            stats["missing_version"] += 1
        elif not valid:
            warnings.append((n, ver, "fix to X.Y.Z", "invalid version (expected semver X.Y.Z)", rel))
            stats["invalid_version"] += 1

        if n in old_entries:
            match, kind = n, "name"
        else:
            match, kind = None, "new"
            fp_name = by_fp.get(snap["fingerprint"])
            if fp_name and fp_name not in cur_names and fp_name not in consumed:
                match, kind = fp_name, "rename"
            else:
                for sn in sorted(old_entries):
                    if sn in cur_names or sn in consumed:
                        continue
                    if _is_rename(old_entries[sn].get("files", {}), snap["files"]):
                        match, kind = sn, "rename"
                        break

        if kind == "new":
            stats["new"] += 1
            new_entries[n] = _build_entry(n, rel, ver, snap, head)
            continue

        consumed.add(match)
        e = old_entries[match]
        old_ver = _norm_version(e.get("version"))
        old_files = e.get("files", {})
        old_fp = e.get("fingerprint")
        old_path = e.get("path")
        sugg, reason = classify_change(old_files, snap["files"])
        path_changed = old_path != rel
        bumped = valid and ver != old_ver

        if kind == "rename":
            if bumped:
                stats["bumped"] += 1
                sv, sf, sfp = ver, snap["files"], snap["fingerprint"]
            else:
                stats["unbumped"] += 1
                warnings.append((n, ver or "-", "patch", "skill renamed", rel))
                sv, sf, sfp = old_ver, old_files, old_fp
        elif sugg is None and path_changed:
            stats["moved"] += 1
            sv, sf, sfp = (ver if valid else old_ver), snap["files"], snap["fingerprint"]
        elif sugg is None:
            stats["unchanged"] += 1
            sv, sf, sfp = (ver if valid else old_ver), snap["files"], snap["fingerprint"]
        elif bumped:
            stats["bumped"] += 1
            sv, sf, sfp = ver, snap["files"], snap["fingerprint"]
        else:
            stats["unbumped"] += 1
            extra = f"; moved from {old_path}" if path_changed else ""
            warnings.append((n, ver or "-", sugg or "patch", reason + extra, rel))
            sv, sf, sfp = old_ver, old_files, old_fp
        new_entries[n] = _build_entry(n, rel, sv, snap, head, files=sf, fingerprint=sfp)

    for n in old_entries:
        if n not in consumed:
            stats["deleted"] += 1

    new_state = {"version": 1, "skills": new_entries}
    if new_state != state:
        save_versions(registry, new_state)
    return warnings, stats
