"""Git-backed remote skill repositories outside the local registry."""

from __future__ import annotations

import argparse
import json
import os
import re
import shutil
import stat
import subprocess
from datetime import datetime
from pathlib import Path
from typing import Any

from .agents import agent_names, agent_skill_dir
from .config import ManagerError, REMOTE_NAME_RE, REMOTE_URL_RE
from .registry import _git, walk_skills
from .reporting import display_error, display_info, display_table, display_warn
from .storage import db_connect, db_path, has_skill, is_link_like


def remote_cache_root() -> Path:
    return db_path().parent / "remotes"


def _clear_readonly(func, path, *args) -> None:
    try:
        os.chmod(path, stat.S_IWRITE)
        func(path)
    except OSError:
        pass


def remove_checkout_tree(path: Path) -> None:
    """Delete a manager-owned checkout. Git keeps loose objects read-only,
    which silently defeats rmtree(ignore_errors=True) on Windows."""
    if not path.exists():
        return
    try:
        shutil.rmtree(path, onexc=_clear_readonly)
    except TypeError:  # Python without onexc
        shutil.rmtree(path, onerror=_clear_readonly)


def remotes_all() -> dict[str, dict[str, Any]]:
    conn = db_connect()
    try:
        rows = conn.execute(
            "SELECT name, url, subpath, ref, head, added_at, updated_at FROM remotes ORDER BY name"
        ).fetchall()
    finally:
        conn.close()
    return {r[0]: {"name": r[0], "url": r[1], "subpath": r[2], "ref": r[3],
                   "head": r[4], "added_at": r[5], "updated_at": r[6]} for r in rows}


def remote_get(name: str) -> dict[str, Any] | None:
    return remotes_all().get(name.strip().lower())


def remote_upsert(name: str, url: str, subpath: str, ref: str, force: bool) -> str:
    """Register (or re-register) a remote. Returns added/updated/unchanged."""
    if not REMOTE_URL_RE.match(url) and not (os.path.isabs(url) and os.path.exists(url)):
        raise ManagerError(
            f"unsupported remote url '{url}': need https://, ssh://, git@host:path or an "
            "existing absolute local repo path")
    if not REMOTE_NAME_RE.match(name):
        raise ManagerError(f"invalid remote name '{name}': lowercase letters, digits, dot, "
                           "dash, underscore, max 64")
    existing = remote_get(name)
    if existing and existing["url"] != url and not force:
        raise ManagerError(
            f"conflict: remote '{name}' already points at '{existing['url']}'; "
            f"pass --force to re-point it to '{url}'.")
    status = "added" if existing is None else (
        "unchanged" if (existing["url"], existing["subpath"], existing["ref"]) == (url, subpath, ref)
        else "updated")
    conn = db_connect()
    try:
        conn.execute(
            "INSERT INTO remotes (name, url, subpath, ref, added_at, updated_at) "
            "VALUES (?, ?, ?, ?, ?, ?) ON CONFLICT(name) DO UPDATE SET url = excluded.url, "
            "subpath = excluded.subpath, ref = excluded.ref, updated_at = excluded.updated_at",
            (name, url, subpath, ref, datetime.now().isoformat(timespec="seconds"),
             datetime.now().isoformat(timespec="seconds")),
        )
        conn.commit()
    finally:
        conn.close()
    return status


def remote_delete(name: str) -> None:
    conn = db_connect()
    try:
        cur = conn.execute("DELETE FROM remotes WHERE name = ?", (name,))
        conn.commit()
    finally:
        conn.close()
    if cur.rowcount == 0:
        raise ManagerError(f"no such remote '{name}' (known: "
                           f"{', '.join(remotes_all()) or 'none'})")


def derive_remote_name(url: str, subpath: str) -> str:
    def tail_of(raw: str) -> str:
        return raw.replace("\\", "/").rstrip("/").rsplit("/", 1)[-1]
    tail = tail_of(subpath or url)
    if tail in ("", "."):
        tail = tail_of(url)
    slug = re.sub(r"\.git$", "", tail)
    slug = re.sub(r"[^a-z0-9._-]+", "-", slug.lower()).strip("-.")[:64].strip("-.")
    return slug or "remote"


def remote_checkout(info: dict[str, Any]) -> Path:
    return remote_cache_root() / info["name"]


def remote_root(info: dict[str, Any]) -> Path | None:
    """The skill-search root inside the checkout (subpath), if fetched."""
    dest = remote_checkout(info) / info["subpath"] if info["subpath"] else remote_checkout(info)
    return dest if dest.is_dir() else None


def remote_skill_dirs(info: dict[str, Any]) -> list[Path]:
    root = remote_root(info)
    if root is None:
        return []
    if has_skill(root):
        return [root]
    return walk_skills(root)


def remote_fetch(info: dict[str, Any]) -> tuple[str, str]:
    """Clone or refresh the checkout. Manager owns this directory entirely."""
    name, url, ref = info["name"], info["url"], info["ref"]
    dest = remote_checkout(info)
    if (dest / ".git").exists():
        origin = _git(dest, "config", "--get", "remote.origin.url")
        if origin != url:
            remove_checkout_tree(dest)  # cache is manager-owned; re-clone
        else:
            before = _git(dest, "rev-parse", "HEAD")
            if ref:
                fetch_specs = [ref]
                resolve = "FETCH_HEAD"
            else:
                fetch_specs = ["+refs/heads/*:refs/remotes/origin/*"]
                resolve = "origin/HEAD"
            run = ["git", "-C", str(dest), "fetch", "--quiet", "--depth", "1", "origin",
                   *fetch_specs]
            proc = subprocess.run(run, capture_output=True, text=True,
                                  encoding="utf-8", errors="replace", timeout=180)
            if proc.returncode != 0:
                return "failed", f"fetch: {proc.stderr.strip()[:200]}"
            if not ref:
                subprocess.run(["git", "-C", str(dest), "remote", "set-head", "origin", "--auto"],
                               capture_output=True, text=True, encoding="utf-8",
                               errors="replace", timeout=60)
            proc = subprocess.run(["git", "-C", str(dest), "reset", "--quiet", "--hard",
                                   resolve], capture_output=True, text=True,
                                  encoding="utf-8", errors="replace", timeout=60)
            if proc.returncode != 0:
                return "failed", f"reset: {proc.stderr.strip()[:200]}"
            after = _git(dest, "rev-parse", "HEAD")
            conn = db_connect()
            try:
                conn.execute("UPDATE remotes SET head = ?, updated_at = ? WHERE name = ?",
                             (after, datetime.now().isoformat(timespec="seconds"), name))
                conn.commit()
            finally:
                conn.close()
            return ("updated" if after != before else "unchanged"), (after or "")[:9]
    dest.parent.mkdir(parents=True, exist_ok=True)
    cmd = ["git", "clone", "--quiet", "--depth", "1"]
    cmd += ["--branch", ref] if ref else []
    cmd += [url, str(dest)]
    proc = subprocess.run(cmd, capture_output=True, text=True,
                          encoding="utf-8", errors="replace", timeout=300)
    if proc.returncode != 0:
        remove_checkout_tree(dest)
        return "failed", f"clone: {proc.stderr.strip()[:200]}"
    head = _git(dest, "rev-parse", "HEAD")
    conn = db_connect()
    try:
        conn.execute("UPDATE remotes SET head = ?, updated_at = ? WHERE name = ?",
                     (head, datetime.now().isoformat(timespec="seconds"), name))
        conn.commit()
    finally:
        conn.close()
    return "cloned", (head or "")[:9]


def remote_skill_index() -> dict[str, Path]:
    """name -> skill dir, across fetched remotes (audit support)."""
    out: dict[str, Path] = {}
    for info in remotes_all().values():
        for d in remote_skill_dirs(info):
            out.setdefault(d.name, d)
    return out


def remote_sources(url: str, names: list[str]) -> list[Path]:
    """Resolve skill source dirs inside a remote checkout, registering and
    fetching the remote as needed. The registration key is the URL-derived
    name so `skill --remote` and `remote --add` agree on one entry."""
    rname = derive_remote_name(url, "")
    info = remote_get(rname)
    if info is not None and info["url"] != url:
        raise ManagerError(
            f"a remote named '{rname}' already points at '{info['url']}'; register this URL "
            f"under another name first: `manager.py remote --add {url} --name NAME`")
    if info is None:
        remote_upsert(rname, url, "", "", force=False)
        info = remote_get(rname)
        display_info(f"[remote] registered '{rname}' -> {url}")
    status, detail = remote_fetch(info)
    if status == "failed":
        raise ManagerError(f"remote fetch failed for '{rname}': {detail}")
    display_info(f"[remote] '{rname}': {status} ({detail})")
    dirs = remote_skill_dirs(info)
    if not dirs:
        raise ManagerError(
            f"no skill found in remote '{rname}' (checkout: {remote_checkout(info)}); if the "
            "skills live in a subfolder, register it first: "
            f"`manager.py remote --add {url} --path SUBPATH`")
    by_name = {d.name: d for d in dirs}
    if names:
        sources = []
        for raw in names:
            key = Path(raw.rstrip("/\\")).name
            hit = by_name.get(key)
            if hit is None:
                display_error(f"'{key}' is not a skill in remote '{rname}' "
                              f"(available: {', '.join(sorted(by_name))})")
            else:
                sources.append(hit)
        return sources
    if len(dirs) > 1:
        rows = [[d.name, d.relative_to(remote_checkout(info)).as_posix()] for d in dirs]
        display_table(["Skill", "Path in checkout"], rows, title=f"remote '{rname}' skills")
        raise ManagerError(
            f"remote '{rname}' holds {len(dirs)} skills; name the ones to install")
    return dirs


def cmd_remote(args: argparse.Namespace) -> int:
    if args.add and args.remove:
        raise ManagerError("--add and --remove are exclusive")
    if args.add:
        name = args.name or derive_remote_name(args.add, args.path or "")
        status = remote_upsert(name, args.add, args.path or "", args.ref or "", args.force)
        info = remote_get(name)
        fstatus, detail = remote_fetch(info)
        rows = [[name, args.add, args.path or "-", args.ref or "-", fstatus, detail]]
        display_table(["Remote", "URL", "Subpath", "Ref", "Fetch", "Head"], rows,
                      title=f"remote {status} '{name}'", always=True)
        return 0 if fstatus != "failed" else 1
    if args.remove:
        info = remote_get(args.remove)
        if info is None:
            raise ManagerError(f"no such remote '{args.remove}' (known: "
                               f"{', '.join(remotes_all()) or 'none'})")
        victims: list[str] = []
        for agent_dir in [agent_skill_dir(a) for a in agent_names()]:
            if not agent_dir.is_dir():
                continue
            for entry in agent_dir.iterdir():
                if is_link_like(entry):
                    try:
                        if os.path.commonpath([os.path.realpath(entry),
                                               str(remote_checkout(info))]) == str(remote_checkout(info)):
                            victims.append(f"{entry.parent.name}/{entry.name}")
                    except (ValueError, OSError):
                        pass
        remote_delete(args.remove)
        remove_checkout_tree(remote_checkout(info))
        display_info(f"[remote] '{args.remove}' unregistered and its manager-owned cache deleted")
        if victims:
            display_warn("agent links still point into the removed cache: "
                         + ", ".join(victims) + " - re-point with `skill --remote` or clean with `skill -U`")
        return 0
    if args.update:
        targets = args.names or sorted(remotes_all())
        if not targets:
            display_info("no remotes registered; nothing to update")
            return 0
        rows, failures = [], 0
        for name in targets:
            info = remote_get(name.lower())
            if info is None:
                display_error(f"no such remote '{name}'")
                failures += 1
                continue
            status, detail = remote_fetch(info)
            rows.append([name, info["url"], status, detail])
            if status == "failed":
                failures += 1
        display_table(["Remote", "URL", "Fetch", "Head"], rows, title="remote update", always=True)
        return 1 if failures else 0
    data = {}
    rows = []
    for info in remotes_all().values():
        dirs = remote_skill_dirs(info)
        data[info["name"]] = {**info, "cache": str(remote_checkout(info)),
                              "skills": [d.name for d in dirs]}
        rows.append([info["name"], info["url"], info["subpath"] or "-", info["ref"] or "-",
                     str(len(dirs)) if remote_root(info) else "not fetched",
                     info["updated_at"] or info["added_at"]])
    if args.json:
        print(json.dumps(data, ensure_ascii=False, indent=2))
        return 0
    display_table(["Remote", "URL", "Subpath", "Ref", "Skills", "Updated"], rows,
                  title=f"{len(rows)} remotes (remotes table)", always=True)
    if not rows:
        display_info("no remotes registered; add one with `manager.py remote --add URL` "
                     "or install directly: `manager.py skill --remote URL`")
    return 0
