"""Skill and agent-instruction deployment, synchronization audit, and Viber installs."""

from __future__ import annotations

import argparse
import json
import os
import shutil
from collections import Counter
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any, Sequence

from .agents import agent_md_targets, agent_names, agent_skill_dir, parse_agents
from .config import (
    AGENT_SOURCE,
    MIGRATION_AGENTS,
    ManagerError,
    SKIP_NAMES,
    VIBER_MANIFEST,
)
from .registry import (
    fingerprint_path,
    map_concurrent,
    nested_skill_index,
    registry_skills,
    resolve_skill,
    walk_skills,
)
from .remotes import remote_skill_index, remote_sources
from .reporting import (
    _DISPLAY,
    display_banner,
    display_counts,
    display_error,
    display_info,
    display_table,
    display_warn,
)
from .storage import (
    CopyRecord,
    _key,
    backup_dirs,
    clear_entries,
    drop_install,
    drop_record,
    get_record,
    has_skill,
    is_link_like,
    is_reparse,
    is_under,
    load_lockfile,
    load_records,
    make_link,
    prune_installs,
    record_copy,
    record_install,
    record_locks,
    remove_entry,
    remove_lock_entry,
    remove_tree_local,
    same_path,
)


@dataclass
class SyncIssue:
    kind: str  # "hard-copy", "link", "folder" or "agent-md"
    skill: str
    target: str
    state: str
    detail: str


def audit_all(registry: Path, agents: Sequence[str], jobs: int) -> list[SyncIssue]:
    """Check hard copies and links against their recorded/source state."""
    issues: list[SyncIssue] = []
    seen: set[tuple[str, str, str, str]] = set()

    def add(kind: str, skill: str, target: Path | str, state: str, detail: str) -> None:
        key = (kind, skill, str(target), state)
        if key in seen:
            return
        seen.add(key)
        issues.append(SyncIssue(kind, skill, str(target), state, detail))

    records = list(load_records(registry).values())
    paths = sorted({record.source for record in records} | {record.target for record in records})
    prints = dict(zip(paths, map_concurrent(lambda p: fingerprint_path(Path(p)), paths, jobs)))

    for record in records:
        source = Path(record.source)
        target = Path(record.target)
        if not source.exists():
            add("hard-copy", record.skill, target, "missing-source", "the recorded source no longer exists")
            continue
        if is_link_like(target):
            if target.exists():
                add("hard-copy", record.skill, target, "target-replaced",
                    f"a link now points at {os.path.realpath(target)}")
            else:
                add("hard-copy", record.skill, target, "missing-target", "the link at the copy location is broken")
            continue
        if not target.exists():
            add("hard-copy", record.skill, target, "missing-target", "the hard copy is missing")
            continue

        source_print = prints.get(record.source)
        target_print = prints.get(record.target)
        if source_print is None:
            add("hard-copy", record.skill, target, "source-unreadable", "cannot read the source to compare")
            continue
        if target_print is None:
            add("hard-copy", record.skill, target, "target-unreadable", "cannot read the copy to compare")
            continue

        source_changed = source_print[0] != record.fingerprint
        target_changed = target_print[0] != record.target_fingerprint
        if source_changed and target_changed:
            add("hard-copy", record.skill, target, "both-changed",
                "source and copy changed since the last copy; run `skill --refresh --force` after review")
        elif source_changed:
            add("hard-copy", record.skill, target, "source-changed",
                "source changed; run `skill --refresh` to re-copy")
        elif target_changed:
            add("hard-copy", record.skill, target, "target-modified",
                "copy was edited locally; `skill --refresh --force` overwrites it")

    known = registry_skills(registry)
    nested = nested_skill_index(registry)
    remote_index = remote_skill_index()
    locked = load_lockfile(registry).get("locked", {})
    record_keys = set(load_records(registry))
    expected_md = registry / AGENT_SOURCE
    for agent in agents:
        for md_target in agent_md_targets(agent):
            if is_link_like(md_target):
                if not md_target.exists():
                    add("agent-md", "AGENTS.md", md_target, "broken-link",
                        f"instruction link target is gone (expected {expected_md})")
                elif not same_path(md_target, expected_md):
                    add("agent-md", "AGENTS.md", md_target, "wrong-target",
                        f"points at {os.path.realpath(md_target)} instead of {expected_md}")
            elif md_target.is_file() and expected_md.is_file():
                if md_target.read_bytes() != expected_md.read_bytes():
                    add("agent-md", "AGENTS.md", md_target, "stale-copy",
                        f"content differs from {AGENT_SOURCE.as_posix()}; run `agent` to relink")
        root = agent_skill_dir(agent)
        if not root.is_dir():
            continue
        for direct in sorted(root.iterdir()):
            name = direct.name
            if not is_link_like(direct):
                if (direct.is_dir() and name not in SKIP_NAMES and not name.startswith(".")
                        and not has_skill(direct)):
                    nested_skills = sorted(p.relative_to(direct).as_posix() for p in walk_skills(direct))
                    detail = ("folder has no top-level SKILL.md"
                              + (f"; nested skill(s) below it: {', '.join(nested_skills)}" if nested_skills else ""))
                    add("folder", name, direct, "missing-skill", detail)
                continue
            source = known.get(name) or nested.get(name) or remote_index.get(name)
            if not direct.exists():
                detail = f"link target is gone (expected {source})" if source else "link target is gone; name is not in the registry"
                add("link", name, direct, "broken-link", detail)
            elif source is not None and not same_path(direct, source):
                add("link", name, direct, "wrong-target",
                    f"points at {os.path.realpath(direct)} instead of {source}")
            elif not has_skill(direct):
                add("link", name, direct, "missing-skill", "link target has no SKILL.md")
        for name, per_agent in locked.items():
            if agent not in per_agent or name not in known:
                continue
            direct = root / name
            if not direct.exists() and not is_link_like(direct) and _key(direct) not in record_keys:
                add("link", name, direct, "missing-locked",
                    f"locked skill is not present in {agent}'s skills folder")

    return issues


def display_sync_banner(issues: Sequence[SyncIssue]) -> None:
    """Display a structured warning banner summarizing synchronization issues."""
    if not issues:
        return
    counts = Counter(issue.state for issue in issues)
    summary = ", ".join(f"{count} {state}" for state, count in sorted(counts.items()))
    lines = [f"{len(issues)} entr{'y' if len(issues) == 1 else 'ies'} need attention: {summary}"]
    limit = len(issues) if (_DISPLAY.verbose or _DISPLAY.full) else 6
    for issue in issues[:limit]:
        lines.append(f"- {issue.skill} [{issue.state}] {issue.target}")
    if len(issues) > limit:
        lines.append(
            f"- ... and {len(issues) - limit} more; run `python manager.py lint` for the full report"
        )
    display_banner("sync check", lines, level="warning")


def install_copy(source: Path, target: Path) -> None:
    """Copy a file or tree into place through a staging path."""
    target.parent.mkdir(parents=True, exist_ok=True)
    staging = target.with_name(target.name + f".tmp-{os.getpid()}")
    if staging.exists() or is_link_like(staging):
        remove_entry(staging)
    if source.is_dir():
        shutil.copytree(
            source,
            staging,
            ignore=shutil.ignore_patterns(*SKIP_NAMES),
            symlinks=False,
        )
    else:
        shutil.copy2(source, staging)
    if target.exists() or is_link_like(target):
        remove_entry(target)
    os.replace(staging, target)


def remember_copy(registry: Path, skill: str, source: Path, target: Path) -> bool:
    source_print = fingerprint_path(source)
    target_print = fingerprint_path(target)
    if source_print is None or target_print is None:
        return False
    record_copy(
        registry,
        CopyRecord(
            skill=skill,
            source=str(source.resolve()),
            target=str(target.resolve()),
            kind="dir" if target.is_dir() else "file",
            fingerprint=source_print[0],
            target_fingerprint=target_print[0],
            files=source_print[1],
            copied_at=datetime.now().isoformat(timespec="seconds"),
        ),
    )
    return True


def _would(status: str) -> str:
    mapping = {
        "linked": "would link",
        "relinked": "would relink",
        "copied": "would copy",
        "updated": "would update",
        "restored": "would restore",
        "repaired": "would repair",
        "replaced": "would replace",
        "created": "would create",
    }
    return mapping.get(status, f"would {status}")


def deploy_skill(
    source: Path,
    dest: Path,
    *,
    mode: str,
    force: bool,
    agent: str | None,
    registry: Path,
    dry_run: bool,
) -> tuple[str, str]:
    """Link or hard-copy one skill. Returns (status, detail)."""
    src = source.resolve()

    if mode == "symlink":
        if is_link_like(dest) and same_path(dest, src):
            if dest.exists():
                if agent is None and not dry_run:
                    record_install(registry, dest, src, mode, dest.parent)
                return "unchanged", f"-> {src}"
            if not dry_run:
                remove_entry(dest)
                make_link(src, dest)
                if agent is None:
                    record_install(registry, dest, src, mode, dest.parent)
            return "repaired", f"broken link -> {src}"

        if is_link_like(dest):
            old = os.path.realpath(dest)
            if not dry_run:
                remove_entry(dest)
            status, detail = "relinked", f"{old} -> {src}"
        elif dest.exists() and dest.is_dir():
            if agent not in MIGRATION_AGENTS and not force:
                return "skipped", "real directory (use --force to replace)"
            if not dry_run:
                remove_entry(dest)
            status, detail = "replaced", f"real directory -> {src}"
        elif dest.exists():
            if not force:
                return "skipped", "real file (use --force to replace)"
            if not dry_run:
                remove_entry(dest)
            status, detail = "replaced", f"real file -> {src}"
        else:
            status, detail = "linked", f"-> {src}"

        if dry_run:
            return _would(status), detail
        try:
            make_link(src, dest)
        except OSError as exc:
            return "failed", str(exc)
        drop_record(registry, dest)
        if agent is None:
            record_install(registry, dest, src, mode, dest.parent)
        return status, detail

    # hard copy
    record = get_record(registry, dest)
    if is_link_like(dest):
        if not dry_run:
            remove_entry(dest)
        status, detail = "replaced", "link -> hard copy"
    elif dest.exists():
        if record is None:
            if not force:
                return "skipped", "real path is not a managed copy (use --force)"
            if not dry_run:
                remove_entry(dest)
            status, detail = "replaced", "unmanaged path -> hard copy"
        else:
            source_print = fingerprint_path(src)
            target_print = fingerprint_path(dest)
            if source_print is None:
                return "failed", "source unreadable"
            if target_print is None:
                return "failed", "copy unreadable"
            source_changed = source_print[0] != record.fingerprint
            target_changed = target_print[0] != record.target_fingerprint
            if not source_changed and not target_changed:
                return "unchanged", f"-> {dest}"
            if target_changed and not force:
                return "skipped", "copy was modified (use --force to overwrite)"
            if not dry_run:
                remove_entry(dest)
            status = "updated" if source_changed else "repaired"
            detail = "source changed" if source_changed else "copy repaired"
    else:
        status, detail = "copied", f"-> {dest}"

    if dry_run:
        return _would(status), detail
    try:
        install_copy(src, dest)
    except OSError as exc:
        return "failed", str(exc)
    if not remember_copy(registry, dest.name, src, dest):
        return "failed", "copied but could not fingerprint the result"
    if agent is None:
        record_install(registry, dest, src, mode, dest.parent)
    return status, detail


def deploy_agent_file(
    source: Path,
    target: Path,
    *,
    hard: bool,
    force: bool,
    registry: Path,
    dry_run: bool,
) -> tuple[str, str]:
    if not dry_run:
        target.parent.mkdir(parents=True, exist_ok=True)

    backup_note = ""
    if target.exists() or is_link_like(target):
        if is_link_like(target):
            if not dry_run:
                remove_entry(target)
            status, detail = "relinked", "replaced existing link"
        elif target.is_file():
            if not force:
                backup = target.with_suffix(".bak")
                if not backup.exists() and not dry_run:
                    shutil.copy2(target, backup)
                    backup_note = f"backup {backup}"
            if not dry_run:
                remove_entry(target)
            status, detail = "replaced", backup_note or "replaced existing file"
        else:
            return "failed", "path exists and is a directory"
    else:
        status, detail = ("copied" if hard else "linked"), f"-> {source}"

    if dry_run:
        return _would(status), detail
    try:
        if hard:
            install_copy(source, target)
        else:
            try:
                os.symlink(source, target)
            except OSError as exc:
                shutil.copy2(source, target)
                detail = f"copied (symlink failed: {exc})"
                hard = True
    except OSError as exc:
        return "failed", str(exc)

    if hard:
        if not remember_copy(registry, target.name, source, target):
            return "failed", "copied but could not fingerprint the result"
    else:
        drop_record(registry, target)
    return status, detail


def resolve_into(raw: str) -> Path:
    path = Path(raw).expanduser()
    if path.exists() and not path.is_dir():
        raise ManagerError(f"--into path is not a directory: {path}")
    return path.resolve()


def scan_existing(base: Path, known: set[str]) -> dict[str, list[Path]]:
    """Find existing skill entries under base whose names are in known."""
    matches: dict[str, list[Path]] = {}

    def visit(directory: Path) -> None:
        try:
            entries = sorted(directory.iterdir(), key=lambda item: item.name.lower())
        except OSError:
            return
        for entry in entries:
            try:
                if is_reparse(entry):
                    if entry.name in known:
                        matches.setdefault(entry.name, []).append(entry)
                    continue
                if not entry.is_dir():
                    continue
                if has_skill(entry):
                    if entry.name in known:
                        matches.setdefault(entry.name, []).append(entry)
                    continue
                visit(entry)
            except OSError:
                continue

    visit(base)
    return matches


def sync_copy(record: CopyRecord, registry: Path, *, force: bool, dry_run: bool) -> tuple[str, str]:
    source = Path(record.source)
    target = Path(record.target)
    if not source.exists():
        return "failed", "source no longer exists"
    source_print = fingerprint_path(source)
    if source_print is None:
        return "failed", "source unreadable"

    if is_link_like(target) or not target.exists():
        if not dry_run:
            if target.exists() or is_link_like(target):
                remove_entry(target)
            install_copy(source, target)
            remember_copy(registry, record.skill, source, target)
        return ("would restore" if dry_run else "restored"), f"-> {target}"

    target_print = fingerprint_path(target)
    if target_print is None:
        return "failed", "copy unreadable"
    source_changed = source_print[0] != record.fingerprint
    target_changed = target_print[0] != record.target_fingerprint
    if not source_changed and not target_changed:
        return "unchanged", "in sync"
    if target_changed and not force:
        return "skipped", "copy was modified (use --force to overwrite)"
    if dry_run:
        return "would update", "source changed"
    install_copy(source, target)
    remember_copy(registry, record.skill, source, target)
    return "updated", "source -> copy"


def cmd_skill(args: argparse.Namespace, registry: Path, jobs: int, invoked: set[str]) -> int:
    if args.remove and (args.refresh or args.list):
        raise ManagerError("--remove cannot combine with --refresh/--list")
    if args.remote and (args.remove or args.refresh or args.list):
        raise ManagerError("--remote cannot combine with --remove/--refresh/--list")
    if args.list:
        skills = registry_skills(registry)
        rows = [[name, str(path.relative_to(registry))] for name, path in sorted(skills.items())]
        display_table(["Skill", "Path"], rows, title=f"{len(skills)} registry skills", always=True)
        return 0

    into = resolve_into(args.into) if args.into else None
    if into is not None and ({"-A", "--agents"} & invoked):
        raise ManagerError("--into targets one folder; drop --agents")

    if args.remove:
        return cmd_skill_remove(args, registry, into)

    if args.refresh:
        if args.skills or args.all:
            raise ManagerError("--refresh cannot be combined with skill names or --all")
        return cmd_refresh(args, registry, jobs, into)

    hard = bool(args.hard_copy or args.mode == "copy")
    if args.hard_copy and args.mode == "symlink" and ({"-M", "--mode"} & invoked):
        raise ManagerError("--hard-copy and --mode symlink contradict each other")
    mode = "hard-copy" if hard else "symlink"

    if args.remote:
        if args.all:
            raise ManagerError("--remote takes its skill list from the checkout; drop --all")
        if args.lock:
            display_warn("--lock records registry skills only; remote installs are not locked")
        sources = remote_sources(args.remote, list(args.skills))
    else:
        if args.all:
            names = sorted(registry_skills(registry))
        else:
            names = list(args.skills)
        if not names:
            raise ManagerError("name at least one skill, or use --all / --refresh")

        sources = []
        for name in names:
            try:
                sources.append(resolve_skill(name, Path.cwd(), registry))
            except ManagerError as exc:
                display_error(str(exc))
    if not sources:
        return 1

    if into is not None:
        roots: list[tuple[str, Path, str | None]] = [(f"into {into}", into, None)]
        if args.lock:
            display_warn("--lock records agent installs only; ignored with --into")
    else:
        agents = parse_agents(args.agents)
        roots = [(agent, agent_skill_dir(agent), agent) for agent in agents]

    rows: list[list[str]] = []
    counts: Counter[str] = Counter()
    failures = 0
    successful: list[str] = []

    for label, root, agent in roots:
        existed = root.exists()
        if not existed:
            if not args.dry_run:
                try:
                    root.mkdir(parents=True, exist_ok=True)
                except OSError as exc:
                    display_error(f"cannot create {root}: {exc}")
                    failures += 1
                    continue
            rows.append([label, "-", mode, "would create" if args.dry_run else "created", str(root)])
        for source in sources:
            status, detail = deploy_skill(
                source,
                root / source.name,
                mode=mode,
                force=args.force,
                agent=agent,
                registry=registry,
                dry_run=args.dry_run,
            )
            rows.append([label, source.name, mode, status, detail])
            counts[status] += 1
            if status == "failed":
                failures += 1
            elif status != "skipped" and not args.dry_run and agent is not None:
                if source.name not in successful:
                    successful.append(source.name)

    display_table(["Target", "Skill", "Mode", "Status", "Detail"], rows, title="skill deployment")
    display_counts(counts)

    if args.lock and successful and not args.dry_run and not args.remote:
        record_locks(registry, successful, parse_agents(args.agents))
        display_info(f"[lock] recorded {len(successful)} skill(s) into the manager database")
    return 1 if failures else 0


def cmd_skill_remove(args: argparse.Namespace, registry: Path, into: Path | None) -> int:
    """Uninstall deployed skills - links, junctions and tracked hard copies -
    from agent folders or --into. Registry sources are never touched."""
    if args.all:
        names = sorted(registry_skills(registry))
    else:
        names = []
        for raw in args.skills:
            name = Path(raw.rstrip("/\\")).name
            if not name:
                raise ManagerError(f"--remove: cannot derive a skill name from '{raw}'")
            if name not in names:
                names.append(name)
    if not names:
        raise ManagerError("--remove: name at least one skill, or use --all")

    if into is not None:
        roots: list[tuple[str, Path, str | None]] = [(f"into {into}", into, None)]
    else:
        roots = [(agent, agent_skill_dir(agent), agent) for agent in parse_agents(args.agents)]

    rows: list[list[str]] = []
    counts: Counter[str] = Counter()
    failures = 0
    for label, root, agent in roots:
        for name in names:
            target = root / name
            exists_or_link = False
            try:
                exists_or_link = target.exists() or is_link_like(target)
            except OSError:
                pass
            if not exists_or_link:
                rows.append([label, name, "-", "absent", str(target)])
                counts["absent"] += 1
                continue
            if is_under(target, registry) or same_path(target, registry):
                rows.append([label, name, "-", "protected", "registry source is never removed here"])
                counts["protected"] += 1
                continue
            if is_link_like(target):
                kind = "symlink" if target.is_symlink() else "junction"
                detail = f"-> {os.path.realpath(target)}"
                if not args.dry_run:
                    try:
                        remove_entry(target)
                    except OSError as exc:
                        rows.append([label, name, kind, "failed", str(exc)])
                        counts["failed"] += 1
                        failures += 1
                        continue
                    drop_install(registry, target)
                    remove_lock_entry(registry, name, agent)
                rows.append([label, name, kind, "would unlink" if args.dry_run else "unlinked", detail])
                counts["unlinked"] += 1
                continue
            if target.is_file():
                if not args.force:
                    rows.append([label, name, "file", "skipped", "stray file, unmanaged (use --force)"])
                    counts["skipped"] += 1
                    continue
                if not args.dry_run:
                    remove_entry(target)
                rows.append([label, name, "file", "removed file" if not args.dry_run else "would remove file",
                             "unmanaged"])
                counts["removed"] += 1
                continue
            # real directory: managed copy, or unmanaged tree
            record = get_record(registry, target)
            managed = record is not None
            if not managed and not args.force:
                rows.append([label, name, "directory", "skipped",
                             "unmanaged directory, not a tracked copy (use --force)"])
                counts["skipped"] += 1
                continue
            action = ("would remove copy" if args.dry_run else "removed copy") if managed \
                else ("would remove tree" if args.dry_run else "removed tree")
            detail = "tracked in manager database" if managed else "unmanaged (forced)"
            if not args.dry_run:
                if not args.no_backup:
                    archive = backup_dirs([target], "skill-remove-backup")
                    if archive is not None:
                        detail += f"; backup {archive.name}"
                try:
                    remove_tree_local(target)
                except OSError as exc:
                    rows.append([label, name, "directory", "failed", str(exc)])
                    counts["failed"] += 1
                    failures += 1
                    continue
                drop_record(registry, target)
                drop_install(registry, target)
                remove_lock_entry(registry, name, agent)
            rows.append([label, name, "directory", action, detail])
            counts["removed"] += 1

    display_table(["Target", "Skill", "Kind", "Action", "Detail"], rows, title="skill removal")
    display_counts(counts)
    if not args.dry_run and counts.get("removed", 0) + counts.get("unlinked", 0):
        removed_rows = prune_installs(registry)
        if removed_rows:
            display_info(f"[installs] pruned {len(removed_rows)} stale index row(s)")
    return 1 if failures else 0


def cmd_refresh(args: argparse.Namespace, registry: Path, jobs: int, into: Path | None) -> int:
    known = registry_skills(registry)
    if not known:
        raise ManagerError(f"no skills found in registry {registry}")
    # Children installed as their own junction resolve through the nested
    # index, so a skill tree moved inside the registry is still repairable.
    repairable = {**nested_skill_index(registry), **known}

    if into is not None:
        roots: list[tuple[str, Path, str | None]] = [(f"into {into}", into, None)]
    else:
        roots = [(agent, agent_skill_dir(agent), agent) for agent in parse_agents(args.agents)]

    if not args.no_backup and not args.dry_run:
        existing = [root for _, root, _ in roots if root.exists()]
        archive = backup_dirs(existing)
        if archive:
            display_info(f"backup: {archive}")

    records = load_records(registry)
    locked = load_lockfile(registry).get("locked", {})
    rows: list[list[str]] = []
    counts: Counter[str] = Counter()
    failures = 0

    for label, root, agent in roots:
        if agent is not None:
            expected = registry / AGENT_SOURCE
            for md_target in agent_md_targets(agent):
                if not is_link_like(md_target):
                    continue
                if md_target.exists() and same_path(md_target, expected):
                    continue
                if not expected.is_file():
                    rows.append([label, "AGENTS.md", "failed", f"source missing: {expected}"])
                    counts["failed"] += 1
                    failures += 1
                    continue
                if not args.dry_run:
                    try:
                        remove_entry(md_target)
                        make_link(expected, md_target)
                    except OSError as exc:
                        rows.append([label, str(md_target), "failed", str(exc)])
                        counts["failed"] += 1
                        failures += 1
                        continue
                rows.append([label, "AGENTS.md", "would relink" if args.dry_run else "relinked",
                             f"{md_target} -> {expected}"])
                counts["would relink" if args.dry_run else "relinked"] += 1
        if not root.exists():
            rows.append([label, "-", "skipped", "skills folder is missing"])
            counts["skipped"] += 1
            continue

        for record in records.values():
            if record.kind == "dir" and is_under(Path(record.target), root):
                status, detail = sync_copy(
                    record, registry, force=args.force, dry_run=args.dry_run
                )
                rows.append([label, record.skill, status, detail])
                counts[status] += 1
                if status == "failed":
                    failures += 1

        if agent is not None:
            for name, per_agent in locked.items():
                if agent not in per_agent or name not in known:
                    continue
                direct = root / name
                if direct.exists() or is_link_like(direct) or _key(direct) in records:
                    continue
                if not args.dry_run:
                    try:
                        make_link(known[name], direct)
                    except OSError as exc:
                        rows.append([label, name, "failed", str(exc)])
                        counts["failed"] += 1
                        failures += 1
                        continue
                rows.append([label, name, "would restore" if args.dry_run else "restored",
                             f"locked -> {known[name]}"])
                counts["restored"] += 1

        for name, places in scan_existing(root, set(repairable)).items():
            direct = root / name
            if _key(direct) in records:
                continue
            source = repairable[name]
            if is_link_like(direct):
                if same_path(direct, source) and direct.exists():
                    rows.append([label, name, "unchanged", f"-> {source}"])
                    counts["unchanged"] += 1
                    continue
                if not args.dry_run:
                    clear_entries(places)
                    clear_entries([direct])
                    make_link(source, direct)
                rows.append([label, name, "would relink" if args.dry_run else "relinked", f"-> {source}"])
                counts["relinked"] += 1
                continue
            if direct.is_dir():
                if agent in MIGRATION_AGENTS or args.force:
                    if not args.dry_run:
                        clear_entries(places)
                        clear_entries([direct])
                        make_link(source, direct)
                    rows.append([label, name, "would replace" if args.dry_run else "replaced",
                                 f"real directory -> {source}"])
                    counts["replaced"] += 1
                else:
                    rows.append([label, name, "skipped", "real directory (use --force)"])
                    counts["skipped"] += 1
                continue
            if not args.dry_run:
                clear_entries(places)
                clear_entries([direct])
                make_link(source, direct)
            rows.append([label, name, "would relink" if args.dry_run else "relinked", f"-> {source}"])
            counts["relinked"] += 1

    display_table(["Target", "Skill", "Status", "Detail"], rows, title="refresh")
    display_counts(counts)
    return 1 if failures else 0


def cmd_agent(args: argparse.Namespace, registry: Path) -> int:
    source = registry / AGENT_SOURCE
    if not source.is_file():
        raise ManagerError(f"source AGENTS.md not found at {source}")

    hard = bool(args.hard_copy or args.mode == "copy")
    agents = parse_agents(args.agents)
    rows: list[list[str]] = []
    counts: Counter[str] = Counter()
    failures = 0

    for agent in agents:
        for target in agent_md_targets(agent):
            status, detail = deploy_agent_file(
                source,
                target,
                hard=hard,
                force=args.force,
                registry=registry,
                dry_run=args.dry_run,
            )
            rows.append([agent, str(target), status, detail])
            counts[status] += 1
            if status == "failed":
                failures += 1

    display_table(["Agent", "Target", "Status", "Detail"], rows, title="agent instructions")
    display_counts(counts)
    return 1 if failures else 0


def viber_plan(registry: Path) -> list[dict[str, Any]]:
    """Resolve the viber census into rows: phase, name, status, entry label, path (None = not in registry)."""
    manifest_file = registry / VIBER_MANIFEST
    if not manifest_file.is_file():
        raise ManagerError(f"viber manifest not found: {manifest_file}")
    try:
        manifest = json.loads(manifest_file.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise ManagerError(f"cannot read {manifest_file}: {exc}") from exc
    known = registry_skills(registry)
    manifest_dir = manifest_file.resolve().parent
    step_info: dict[str, dict[str, str]] = {}
    for step in manifest.get("lifecycle", []):
        for name in step.get("commands", []):
            step_info[name] = {"phase": step.get("step", "-"), "status": "command"}
    for name, entry in manifest.get("skills", {}).items():
        serves = entry.get("fit", {}).get("serves", [])
        if serves and name not in step_info:
            step_info[name] = {"phase": ", ".join(serves), "status": "mandatory"}
    rows: list[dict[str, Any]] = []
    for name, entry in manifest.get("skills", {}).items():
        info = step_info.get(name, {"phase": "-", "status": "-"})
        base = {"phase": info["phase"], "status": info["status"], "entry": name}
        path_str = entry.get("path")
        if path_str:
            base_dir = manifest_dir if entry.get("owned") else registry
            resolved = (base_dir / path_str).resolve()
            if has_skill(resolved):
                rows.append({**base, "name": name, "path": resolved})
            elif resolved.is_dir():
                for member in sorted(walk_skills(resolved), key=lambda p: p.name):
                    rows.append({**base, "name": member.name, "path": member})
            else:
                rows.append({**base, "name": name, "path": None})
        else:
            rows.append({**base, "name": name, "path": known.get(name)})
    return rows


def cmd_viber(args: argparse.Namespace, registry: Path, jobs: int, invoked: set[str]) -> int:
    rows = viber_plan(registry)
    if args.list:
        display_table(
            ["Phase", "Entry", "Skill", "Status", "Path"],
            [[row["phase"], row["entry"], row["name"], row["status"],
              str(row["path"].relative_to(registry)) if row["path"] and row["path"].is_relative_to(registry)
              else str(row["path"]) if row["path"] else "not in registry"] for row in rows],
            title=f"viber skills ({len({row['path'] for row in rows if row['path']})} installable)",
            always=True,
        )
        return 0
    missing = sorted({row["entry"] for row in rows if row["path"] is None})
    if missing:
        display_warn(f"viber names skills that are not in the registry yet, skipped: {', '.join(missing)}")
    sources: list[Path] = []
    for row in rows:
        if row["path"] is not None and row["path"] not in sources:
            sources.append(row["path"])
    if not sources:
        raise ManagerError("no viber skill resolves to the registry")
    args.skills = [str(path) for path in sources]
    return cmd_skill(args, registry, jobs, invoked)
