"""Modular package backing the insource skill and agent manager CLI.

Submodules
----------
- ``config``    -- constants, regex patterns, ``ManagerError``, optional deps
- ``reporting`` -- Rich + ANSI + Plain rendering, middle/path truncation, capping
- ``storage``   -- filesystem/link primitives, SQLite state store, manifests, locks
- ``registry``  -- skill discovery, classification, hashing, git, semver tracking
- ``agents``    -- agents table CRUD, installed-skill inventory, ``claim``
- ``remotes``   -- remote git checkout cache, fetch/update, ``remote``
- ``deploy``    -- deployment primitives, sync audit, ``skill``/``refresh``/``agent``/``viber``
- ``analysis``  -- frontmatter, README check, ``lint``/``report``/``find``/``crossreference``
- ``fixer``     -- safe/unsafe lint auto-fixer with selectable per-rule fix styles
- ``tui``       -- interactive multi-select checklist TUI
- ``cli``       -- argument parser, command routing, and ``main()``
"""

from .config import ManagerError, REGISTRY, __version__, set_registry

__all__ = ["ManagerError", "REGISTRY", "__version__", "set_registry"]
