"""CLI argument parser, command routing, flag summaries, and main() entrypoint."""

from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path
from typing import Sequence

from . import config as _config
from .agents import agent_names, cmd_agents, cmd_claim
from .analysis import cmd_crossreference, cmd_find, cmd_lint, cmd_report
from .config import (
    AGENT_SOURCE,
    COMMANDS,
    DEFAULT_DESCRIPTION_LIMIT,
    DEFAULT_TABLE_ROW_LIMIT,
    ManagerError,
    VIBER_MANIFEST,
    __version__,
)
from .deploy import audit_all, cmd_agent, cmd_skill, cmd_viber, display_sync_banner
from .remotes import cmd_remote
from .reporting import (
    configure_display,
    display_command_report,
    display_error,
    format_list_compact,
)
from .tui import cmd_interactive


def add_common(parser: argparse.ArgumentParser) -> None:
    """Attach shared global options (registry, concurrency, and display controls)."""
    parser.add_argument(
        "-r", "--registry", type=Path, default=None,
        help="registry root (default: the folder containing manager.py)",
    )
    parser.add_argument(
        "-j", "--jobs", type=int, default=None,
        help="concurrent reads for hashing and linting (default: CPU-based)",
    )
    parser.add_argument(
        "-q", "--quiet", action="store_true",
        help="suppress routine reports; warnings and errors still print",
    )
    parser.add_argument(
        "-v", "--verbose", action="store_true",
        help="show extra detail and expand capped lists in reports",
    )
    parser.add_argument(
        "-C", "--no-color", action="store_true",
        help="plain monochrome ASCII output, disabling Rich and ANSI colors",
    )
    parser.add_argument(
        "-F", "--full", action="store_true",
        help="disable row limits and middle-truncation on long names and paths",
    )
    parser.add_argument(
        "--limit", type=int, default=DEFAULT_TABLE_ROW_LIMIT, metavar="N",
        help=f"max rows shown per table before summarizing; 0 for unlimited (default: {DEFAULT_TABLE_ROW_LIMIT})",
    )


def add_deploy_flags(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("-f", "--force", action="store_true", help="replace real paths or modified copies")
    parser.add_argument("-d", "--dry-run", action="store_true", help="show what would happen, change nothing")


def add_mode_flag(parser: argparse.ArgumentParser) -> None:
    parser.add_argument(
        "-M", "--mode", choices=["symlink", "copy"], default="symlink",
        help="legacy alias: 'copy' is the same as --hard-copy (default: symlink)",
    )


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="manager.py",
        description="Deploy skills and agent instructions, lint and classify skills, locate installs, and discover crossreferences.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=(
            "examples:\n"
            "  python manager.py skill avatar\n"
            "  python manager.py avatar mine --agents opencode,gemini\n"
            "  python manager.py skill --all --lock\n"
            "  python manager.py skill avatar --into ./my-project --hard-copy\n"
            "  python manager.py skill --refresh\n"
            "  python manager.py agent --agents claude,opencode\n"
            "  python manager.py lint --strict\n"
            "  python manager.py lint --readme\n"
            "  python manager.py lint --fix\n"
            "  python manager.py lint --fix --unsafe --dry-run\n"
            "  python manager.py lint --fix --fix-style broken-link=remove,missing-locked=ignore\n"
            "  python manager.py lint --list-fixes\n"
            "  python manager.py report --sort files --reverse\n"
            "  python manager.py report techstack --json\n"
            "  python manager.py find techstack\n"
            "  python manager.py find pages revoke --quiet\n"
            "  python manager.py crossreference\n"
            "  python manager.py crossreference --json\n"
            "  python manager.py remote --add https://github.com/acme/skills -p skills/\n"
            "  python manager.py skill --remote https://github.com/acme/skills foo bar\n"
            "  python manager.py remote --update\n"
            "  python manager.py lint --remote\n"
            "  python manager.py interactive\n"
            "  python manager.py interactive --into ./my-project --hard-copy\n"
            "  python manager.py viber --into ./my-project --hard-copy\n"
        ),
    )
    parser.add_argument(
        "-V", "--version", action="version", version=f"%(prog)s {__version__}"
    )
    subparsers = parser.add_subparsers(dest="command", metavar="{skill,agent,agents,claim,remote,interactive,lint,viber,report,find,crossreference}")

    skill = subparsers.add_parser(
        "skill",
        help="link, copy, refresh, or remove skills (default command)",
        description="Link or copy named skills into global agent folders or a project folder; "
                    "--remove uninstalls them from wherever they are deployed "
                    "(symlinks, junctions, tracked hard copies).",
    )
    add_common(skill)
    add_deploy_flags(skill)
    add_mode_flag(skill)
    skill.add_argument("skills", nargs="*", help="skill name(s) or a path to a skill directory")
    skill.add_argument("-a", "--all", action="store_true", help="every skill in the registry")
    skill.add_argument("-A", "--agents", default="all", help="comma-separated agents or 'all'")
    skill.add_argument("-l", "--lock", action="store_true", help="record installs in the manager database")
    skill.add_argument("-R", "--refresh", action="store_true", help="repair existing and locked entries")
    skill.add_argument("-U", "--remove", action="store_true",
                       help="uninstall named skills from agent folders (or --into): links and "
                            "junctions are removed without touching sources, tracked hard copies "
                            "are removed (backed up first); unmanaged directories need --force; "
                            "registry sources are always protected")
    skill.add_argument("-i", "--into", default=None, help="project folder to install into instead of agent folders")
    skill.add_argument("-c", "--hard-copy", action="store_true", help="copy instead of link and track sync")
    skill.add_argument("-B", "--no-backup", action="store_true", help="skip the backup before --refresh or --remove of hard copies")
    skill.add_argument("-L", "--list", action="store_true", help="list registry skills and exit")
    skill.add_argument("-x", "--remote", metavar="URL", default=None,
                       help="take the named skills from a remote git repo instead of the "
                            "registry: registers the URL if new, fetches it, deploys from the "
                            "cache (links point into the cache; keep fresh with `remote --update`)")

    viber = subparsers.add_parser(
        "viber",
        help="install every skill the Viber lifecycle uses, in one shot",
        description=(
            "Link or copy the whole Viber skill set (listed in Groups/Viber/viber.json) into global "
            "agent folders or a project folder. Same flags and behaviour as `skill`; the skill list "
            "comes from the manifest instead of the command line."
        ),
    )
    add_common(viber)
    add_deploy_flags(viber)
    add_mode_flag(viber)
    viber.add_argument("-A", "--agents", default="all", help="comma-separated agents or 'all'")
    viber.add_argument("-l", "--lock", action="store_true", help="record installs in the manager database")
    viber.add_argument("-i", "--into", default=None, help="project folder to install into instead of agent folders")
    viber.add_argument("-c", "--hard-copy", action="store_true", help="copy instead of link and track sync")
    viber.add_argument("-L", "--list", action="store_true", help="list the viber skills and where they resolve, then exit")
    viber.set_defaults(skills=[], all=False, refresh=False, no_backup=False, remove=False, remote=None)

    agent = subparsers.add_parser(
        "agent",
        help="deploy AGENTS.md to agent configurations",
        description=f"Link or copy the registry's {AGENT_SOURCE.as_posix()} into each selected agent's global instruction file.",
    )
    add_common(agent)
    add_deploy_flags(agent)
    add_mode_flag(agent)
    agent.add_argument("-A", "--agents", default="all", help="comma-separated agents or 'all'")
    agent.add_argument("-c", "--hard-copy", action="store_true", help="copy instead of link and track sync")

    agents = subparsers.add_parser(
        "agents",
        help="manage the agents table: where each code agent lives",
        description="Code-agent locations are read from the agents table, seeded once from the "
                    "built-in defaults (qoder, junie, gemini, opencode, claude). --set registers or "
                    "updates a row; --remove unregisters without touching deployments on disk. "
                    "Every --agents use in skill/viber/agent reads this table.",
    )
    add_common(agents)
    agents.add_argument("-s", "--set", metavar="NAME", default=None,
                        help="register a new agent or update this one")
    agents.add_argument("-d", "--skill-dir", default=None, metavar="PATH",
                        help="skills folder for --set (relative paths resolve against the current folder)")
    agents.add_argument("-m", "--md-path", action="append", default=None, metavar="PATH",
                        help="instruction file for --set, repeatable; omit to keep existing ones on update")
    agents.add_argument("-x", "--remove", metavar="NAME", default=None,
                        help="unregister this agent; a seeded default stays removed (tombstone row)")
    agents.add_argument("-O", "--override", action="store_true",
                        help="replace differing existing values or share a skill dir despite the conflict")
    agents.add_argument("-L", "--list", action="store_true",
                        help="show the table explicitly (also the default with no action flag)")
    agents.add_argument("-I", "--inventory", action="store_true",
                        help="list the skills installed in each agent folder (name, kind, resolved source)")
    agents.add_argument("--json", action="store_true", help="print the table as JSON")

    claim = subparsers.add_parser(
        "claim",
        help="claim one agent's skill set into another: claim X into Y",
        description="Make Y end with X's skill set. Default mode is OVERRIDE: shared "
                    "names are replaced (unmanaged folders replaced are backed up first), "
                    "missing are added, and Y's extras are removed when manager-owned "
                    "(unmanaged extras are protected unless --force). --append adds only "
                    "what Y lacks, deduped by name, and never touches existing entries. "
                    "X and Y are agent names from the agents table or direct folder paths. "
                    "Deployment kind follows the source entry: links link, copies copy.",
    )
    add_common(claim)
    claim.add_argument("from_agent", metavar="FROM", help="source agent name or skills folder")
    claim.add_argument("into_agent", metavar="TO", help="destination agent name or skills folder")
    claim.add_argument("-a", "--append", action="store_true",
                       help="only add what the destination lacks; existing entries are kept untouched")
    claim.add_argument("-f", "--force", action="store_true",
                       help="override mode also removes UNMANAGED extra folders (backed up first)")
    claim.add_argument("-d", "--dry-run", action="store_true",
                       help="show what would happen, change nothing")
    claim.add_argument("-B", "--no-backup", action="store_true",
                       help="skip the automatic backup zips before replacing/removing real folders")

    remote = subparsers.add_parser(
        "remote",
        help="register and refresh git-backed remote skill sources",
        description="Remotes are git repositories outside this registry whose skills you can "
                    "install with `skill --remote URL`. Manager clones them shallow into its "
                    "cache (next to the database) and owns those copies entirely: a refresh "
                    "re-fetches and hard-resets; --remove deletes the cache with it. --add "
                    "registers + fetches once; --update refreshes one, several or all; with no "
                    "action flag this lists the remotes table and fetched skill counts.",
    )
    add_common(remote)
    remote.add_argument("-L", "--list", action="store_true",
                        help="show the remotes table explicitly (default with no action flag)")
    remote.add_argument("-a", "--add", metavar="URL", default=None,
                        help="register a remote git URL (https://, ssh://, git@host:path or a "
                             "local repo path for tests) and fetch it once")
    remote.add_argument("-n", "--name", default=None,
                        help="name for --add (default: derived from the URL/repo or --path slug)")
    remote.add_argument("-p", "--path", default="", metavar="SUBPATH",
                        help="path inside the repo holding the skill(s), e.g. skills/")
    remote.add_argument("--ref", default="",
                        help="branch or tag to track instead of the repo's default")
    remote.add_argument("-f", "--force", action="store_true",
                        help="--add: re-point an existing name at a different URL")
    remote.add_argument("-u", "--update", action="store_true",
                        help="re-fetch; named remotes follow, all remotes without")
    remote.add_argument("-x", "--remove", metavar="NAME", default=None,
                        help="unregister a remote and delete its manager-owned cache; agent "
                             "links left pointing into it are reported, not silently removed")
    remote.add_argument("names", nargs="*", help="remote name(s) for --update")
    remote.add_argument("--json", action="store_true", help="list mode: JSON instead of a table")

    interactive = subparsers.add_parser(
        "interactive",
        help="arrow-key checklist: pick which skills stay installed, confirm with [y/N]",
        description="Multi-select over every registry skill, pre-checked from what the target "
                    "folders currently hold. Space toggles, typing filters the list, ctrl-a "
                    "selects everything, ctrl-i inverts, enter plans: newly checked get "
                    "installed, unchecked-but-installed get uninstalled, everything else is "
                    "left alone. A plan table follows and NOTHING changes until you confirm "
                    "'Apply changes?'. --no-tui (or a piped terminal) falls back to a numbered "
                    "prompt. Uses questionary when it is installed for the coloured picker. "
                    "Skills installed that are not in the registry (hand-made, remote-only) "
                    "are never touched.",
    )
    add_common(interactive)
    add_deploy_flags(interactive)
    add_mode_flag(interactive)
    interactive.add_argument("-A", "--agents", default="all", help="comma-separated agents or 'all'")
    interactive.add_argument("-i", "--into", default=None,
                             help="project folder to reconcile instead of agent folders")
    interactive.add_argument("-c", "--hard-copy", action="store_true",
                             help="installs copy instead of linking")
    interactive.add_argument("-l", "--lock", action="store_true",
                             help="record installs in the manager database")
    interactive.add_argument("-B", "--no-backup", action="store_true",
                             help="skip the backup zips before uninstalling hard copies")
    interactive.add_argument("-T", "--no-tui", action="store_true",
                             help="numbered prompt instead of the arrow-key checklist")

    lint = subparsers.add_parser(
        "lint",
        help="validate skill metadata and installation synchronization",
        description="Check all independent SKILL.md metadata, classify Skill / Meta-Skill / "
                    "Battery-Skill, flag mixed independent/internal composition, and audit installs. "
                    "Support folders and internal modules are not independently linted skills.",
    )
    add_common(lint)
    lint.add_argument(
        "-i", "--into", action="append", default=None, metavar="PATH",
        help="extra project folder to scan (repeatable)",
    )
    lint.add_argument(
        "-m", "--max-description", type=int, default=DEFAULT_DESCRIPTION_LIMIT,
        help=f"description character limit (default: {DEFAULT_DESCRIPTION_LIMIT})",
    )
    lint.add_argument(
        "-S", "--strict", action="store_true",
        help="exit 1 on metadata, composition, version, sync or README findings",
    )
    lint.add_argument(
        "--readme", action="store_true",
        help="also check README.md against the registry: counts, entries, categories, "
             "descriptions, usage, nesting, archive list and links",
    )
    lint.add_argument(
        "--no-version", action="store_true",
        help="skip skill version tracking (missing-version and unbumped-change warnings)",
    )
    lint.add_argument(
        "-x", "--remote", action="store_true",
        help="also lint the skills inside every fetched remote checkout",
    )
    lint.add_argument(
        "--fix", action="store_true",
        help="automatically fix lint findings (safe fixes only by default; add --unsafe for risky/destructive fixes)",
    )
    lint.add_argument(
        "--unsafe", action="store_true",
        help="allow unsafe/destructive fixes when used with --fix (truncation, deletions, overwrites, lint-accept)",
    )
    lint.add_argument(
        "--fix-style", action="append", default=None, metavar="RULE=STYLE",
        help="choose fix style per rule (repeatable or comma-separated, e.g. broken-link=remove,missing-locked=ignore)",
    )
    lint.add_argument(
        "--only", action="append", default=None, metavar="RULE",
        help="limit --fix to specific lint rule(s) (repeatable or comma-separated)",
    )
    lint.add_argument(
        "--skip-fix", action="append", default=None, metavar="RULE",
        help="exclude specific lint rule(s) from --fix (repeatable or comma-separated)",
    )
    lint.add_argument(
        "--list-fixes", action="store_true",
        help="list every fixable lint condition, its safety tier (safe/unsafe), and selectable styles, then exit",
    )
    lint.add_argument(
        "-d", "--dry-run", action="store_true",
        help="with --fix: preview planned fixes without modifying files or database",
    )
    lint.add_argument(
        "-B", "--no-backup", action="store_true",
        help="with --fix --unsafe: skip automatic backup zips before destructive directory operations",
    )

    report = subparsers.add_parser(
        "report",
        help="report skill types, parents, file counts, description lengths, versions and git state",
        description="Report every independent skill, including meta children. Meta-Skill has "
                    "nested SKILL.md entrypoints; Battery-Skill has Markdown-backed internal "
                    "module folders without their own SKILL.md; Skill has neither. Standard "
                    "support folders (references, assets, scripts, etc.) do not make a battery. "
                    "Mixed composition is flagged. Per-row file counts include descendants; "
                    "the summary counts unique files. Sortable; optional JSON output.",
    )
    add_common(report)
    report.add_argument("skills", nargs="*", help="optional skill names to filter the report")
    report.add_argument(
        "--sort", choices=["name", "type", "files", "desc", "version"], default="name",
        help="sort column (default: name)",
    )
    report.add_argument("--reverse", action="store_true", help="sort descending")
    report.add_argument("--json", action="store_true", help="emit JSON instead of a table")
    report.add_argument("-x", "--remote", action="store_true",
                        help="also report skills from every fetched remote checkout "
                             "(paths prefixed remote:<name>/)")

    find = subparsers.add_parser(
        "find",
        help="locate a skill in the registry, agent folders, or recorded --into installs",
        description="Find skills, groups and internal modules in this registry, global agent "
                    "folders and recorded --into installs, with structural skill types. "
                    "Lock records are shown separately, not as live skills. Exit 0 when any "
                    "name or path resolves, 1 when none does. No skill files are changed; "
                    "stale --into records are pruned from the database.",
    )
    add_common(find)
    find.add_argument(
        "skills", nargs="+",
        help="skill/module/group name(s), or directory path(s) to classify",
    )
    find.add_argument("-x", "--remote", action="store_true",
                      help="also search fetched remote checkouts")

    crossreference = subparsers.add_parser(
        "crossreference",
        help="discover directed mentions among all registry skills with file/line evidence",
        description="Compare every active registry skill; takes no skill names. Scan "
                    ".md/.mdx/.txt/.rst documents once using a skill-name hash index. "
                    "Matches whole name tokens, case-insensitively, including slash commands "
                    "and Markdown links. Shows mentions, not proven dependencies. Meta "
                    "children own their files; battery modules belong to their parent. "
                    "Archives, resources outside skills, hidden files and links are skipped. "
                    "No database writes. Exit 1 on ambiguous targets or unreadable content; "
                    "otherwise 0, including an empty graph.",
    )
    add_common(crossreference)
    crossreference.add_argument("--json", action="store_true", help="emit all evidence and scan statistics as JSON")

    return parser


VALUE_FLAGS = {
    "-r", "--registry", "-j", "--jobs", "-A", "--agents",
    "-i", "--into", "-m", "--max-description", "--limit", "--fix-style", "--only", "--skip-fix",
}


def split_command(argv: Sequence[str]) -> tuple[str, list[str], bool]:
    """Return (command, remaining argv, implicit_default)."""
    index = 0
    while index < len(argv):
        token = argv[index]
        if token in COMMANDS:
            return token, list(argv[:index]) + list(argv[index + 1:]), False
        if token in VALUE_FLAGS:
            index += 2
            continue
        if token.startswith("-"):
            index += 1
            continue
        break
    return "skill", list(argv), True


def invoked_flags(argv: Sequence[str]) -> set[str]:
    return {token.split("=", 1)[0] for token in argv if token.startswith("-")}


def _common_flag_labels(args: argparse.Namespace) -> list[str]:
    labels: list[str] = []
    if getattr(args, "quiet", False):
        labels.append("-q/--quiet")
    if getattr(args, "verbose", False):
        labels.append("-v/--verbose")
    if getattr(args, "no_color", False):
        labels.append("-C/--no-color")
    if getattr(args, "full", False):
        labels.append("-F/--full")
    if getattr(args, "limit", DEFAULT_TABLE_ROW_LIMIT) != DEFAULT_TABLE_ROW_LIMIT:
        labels.append(f"--limit={args.limit}")
    return labels


def skill_flag_labels(args: argparse.Namespace) -> list[str]:
    labels: list[str] = []
    if args.all:
        labels.append("-a/--all")
    if args.agents != "all":
        labels.append("-A/--agents")
    if args.lock:
        labels.append("-l/--lock")
    if args.refresh:
        labels.append("-R/--refresh")
    if getattr(args, "remove", False):
        labels.append("-U/--remove")
    if args.into:
        labels.append("-i/--into")
    if args.hard_copy:
        labels.append("-c/--hard-copy")
    if args.mode != "symlink":
        labels.append("-M/--mode")
    if args.no_backup:
        labels.append("-B/--no-backup")
    if args.list:
        labels.append("-L/--list")
    if args.remote:
        labels.append("-x/--remote")
    if args.force:
        labels.append("-f/--force")
    if args.dry_run:
        labels.append("-d/--dry-run")
    labels.extend(_common_flag_labels(args))
    return labels


def skill_settings(args: argparse.Namespace, registry: Path) -> list[tuple[str, str]]:
    if args.refresh:
        action = "refresh"
    elif args.list:
        action = "list"
    elif args.all:
        action = "all registry skills"
    else:
        action = format_list_compact(args.skills) if args.skills else "none"
    destination = f"into {args.into}" if args.into else f"global agents ({args.agents})"
    mode = "hard-copy" if (args.hard_copy or args.mode == "copy") else "symlink"
    rows = [
        ("Registry", str(registry)),
        ("Destination", destination),
        ("Mode", mode),
        ("Skills", action),
    ]
    if getattr(args, "remote", None):
        rows.insert(1, ("Remote", args.remote))
    return rows


def lint_flag_labels(args: argparse.Namespace) -> list[str]:
    labels: list[str] = []
    if args.into:
        labels.append("-i/--into")
    if args.max_description != DEFAULT_DESCRIPTION_LIMIT:
        labels.append("-m/--max-description")
    if args.strict:
        labels.append("-S/--strict")
    if args.readme:
        labels.append("--readme")
    if args.no_version:
        labels.append("--no-version")
    if args.remote:
        labels.append("-x/--remote")
    if getattr(args, "fix", False):
        labels.append("--fix")
    if getattr(args, "unsafe", False):
        labels.append("--unsafe")
    if getattr(args, "fix_style", None):
        labels.append("--fix-style")
    if getattr(args, "only", None):
        labels.append("--only")
    if getattr(args, "skip_fix", None):
        labels.append("--skip-fix")
    if getattr(args, "dry_run", False):
        labels.append("-d/--dry-run")
    if getattr(args, "no_backup", False):
        labels.append("-B/--no-backup")
    if getattr(args, "list_fixes", False):
        labels.append("--list-fixes")
    labels.extend(_common_flag_labels(args))
    return labels


def report_flag_labels(args: argparse.Namespace) -> list[str]:
    labels: list[str] = []
    if args.skills:
        labels.append("skills filter")
    if args.sort != "name":
        labels.append("--sort")
    if args.reverse:
        labels.append("--reverse")
    if args.json:
        labels.append("--json")
    if args.remote:
        labels.append("-x/--remote")
    labels.extend(_common_flag_labels(args))
    return labels


def parse_cli_args(parser: argparse.ArgumentParser, argv: list[str]) -> argparse.Namespace:
    """Parse CLI arguments with helpful diagnostic hints for common shell mistakes."""
    try:
        return parser.parse_args(argv)
    except SystemExit as exc:
        if exc.code != 0:
            try:
                parsed, unknown = parser.parse_known_args(argv)
                hints: list[str] = []
                # Check for unquoted paths with spaces (e.g. --into or -i)
                into_val = getattr(parsed, "into", None)
                if into_val and isinstance(into_val, str) and unknown:
                    candidate = into_val
                    for tok in unknown:
                        candidate += " " + tok
                        if Path(candidate).expanduser().exists():
                            hints.append(
                                f"path argument '{into_val}' contains unquoted spaces and was split by your shell.\n"
                                f"  Wrap the target path in quotes: --into \"{candidate}\""
                            )
                            break
                if any(tok == "manager.py" or tok.endswith("manager.py") for tok in unknown):
                    hints.append("manager.py appeared inside the arguments, likely due to a duplicate pasted command.")
                if hints:
                    sys.stderr.write("\n[hint] " + "\n[hint] ".join(hints) + "\n\n")
            except Exception:
                pass
        raise


def main(argv: Sequence[str] | None = None) -> int:
    """CLI entrypoint: configure display, dispatch command, handle errors cleanly."""
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

    raw = list(sys.argv[1:] if argv is None else argv)
    parser = build_parser()
    if not raw or raw[0] in {"-h", "--help"}:
        parser.print_help()
        return 0
    if raw[0] in {"-V", "--version"}:
        print(f"manager.py {__version__}")
        return 0

    command, rest, implicit = split_command(raw)
    try:
        args = parse_cli_args(parser, [command] + rest)
    except SystemExit as exc:
        return int(exc.code or 0)

    is_json = bool(getattr(args, "json", False))
    configure_display(
        quiet=args.quiet or is_json,
        color=not args.no_color and not os.environ.get("NO_COLOR") and not is_json,
        verbose=args.verbose,
        full=args.full,
        max_rows=args.limit,
    )
    registry = (args.registry or _config.REGISTRY).expanduser().resolve()
    jobs = args.jobs if args.jobs is not None else min(32, (os.cpu_count() or 4) * 4)

    try:
        if not registry.is_dir():
            raise ManagerError(f"registry not found: {registry}")
        if jobs < 1:
            raise ManagerError("--jobs must be 1 or greater")
        if args.limit < 0:
            raise ManagerError("--limit must be 0 or greater")

        invoked = invoked_flags(rest)

        if command == "agents":
            return cmd_agents(args)
        if command == "claim":
            return cmd_claim(args, registry)
        if command == "remote":
            return cmd_remote(args)
        if command == "interactive":
            return cmd_interactive(args, registry, jobs, invoked)
        if command == "skill" and args.list:
            return cmd_skill(args, registry, jobs, invoked)
        if command == "viber" and args.list:
            return cmd_viber(args, registry, jobs, invoked)
        if command == "lint" and args.list_fixes:
            return cmd_lint(args, registry, jobs, [])

        if command in {"skill", "viber"}:
            settings = skill_settings(args, registry)
            if command == "viber":
                settings[-1] = ("Skills", f"viber set ({VIBER_MANIFEST.as_posix()})")
            display_command_report(
                command, settings=settings, flags=skill_flag_labels(args), implicit=implicit,
            )
        elif command == "agent":
            display_command_report(
                "agent",
                settings=[
                    ("Registry", str(registry)),
                    ("Agents", args.agents),
                    ("Source", str(registry / AGENT_SOURCE)),
                    ("Mode", "hard-copy" if (args.hard_copy or args.mode == "copy") else "symlink"),
                ],
                flags=[
                    label for label, active in [
                        ("-A/--agents", args.agents != "all"),
                        ("-c/--hard-copy", args.hard_copy),
                        ("-M/--mode", args.mode != "symlink"),
                        ("-f/--force", args.force),
                        ("-d/--dry-run", args.dry_run),
                    ] if active
                ] + _common_flag_labels(args),
                implicit=implicit,
            )
        elif command == "report":
            display_command_report(
                "report",
                settings=[
                    ("Registry", str(registry)),
                    ("Skills", format_list_compact(args.skills) if args.skills else "all registry skills"),
                    ("Sort", f"{args.sort}{' (desc)' if args.reverse else ' (asc)'}"),
                ],
                flags=report_flag_labels(args),
                implicit=implicit,
            )
            return cmd_report(args, registry, jobs)
        elif command == "find":
            display_command_report(
                "find",
                settings=[
                    ("Registry", str(registry)),
                    ("Skills", format_list_compact(args.skills)),
                ],
                flags=(["-x/--remote"] if args.remote else []) + _common_flag_labels(args),
                implicit=implicit,
            )
            return cmd_find(args, registry, jobs)
        elif command == "crossreference":
            return cmd_crossreference(args, registry)
        else:
            lint_settings = [
                ("Registry", str(registry)),
                ("Extra roots", format_list_compact(args.into) if args.into else "none"),
                ("Description limit", f"{args.max_description} characters"),
            ]
            if args.fix:
                mode_label = ("safe + unsafe" if args.unsafe else "safe only") + (" (dry-run)" if args.dry_run else "")
                lint_settings.append(("Fix mode", mode_label))
            display_command_report(
                "lint",
                settings=lint_settings,
                flags=lint_flag_labels(args),
                implicit=implicit,
            )

        issues = audit_all(registry, agent_names(), jobs)
        display_sync_banner(issues)

        if command == "skill":
            return cmd_skill(args, registry, jobs, invoked)
        if command == "viber":
            return cmd_viber(args, registry, jobs, invoked)
        if command == "agent":
            return cmd_agent(args, registry)
        return cmd_lint(args, registry, jobs, issues)
    except ManagerError as exc:
        display_error(str(exc))
        return 1
    except KeyboardInterrupt:
        display_error("interrupted")
        return 130
