#!/usr/bin/env python3
"""Unified skill and agent manager for the insource registry.

Entrypoint script delegating to the modular ``manager_pkg/`` package while
re-exporting all public symbols for full backward compatibility.
"""

from __future__ import annotations

import sys
from pathlib import Path

_HERE = Path(__file__).resolve().parent
if str(_HERE) not in sys.path:
    sys.path.insert(0, str(_HERE))

from manager_pkg import config as _config  # noqa: E402

_config.set_registry(_HERE)

from manager_pkg.agents import *  # noqa: E402, F401, F403
from manager_pkg.analysis import *  # noqa: E402, F401, F403
from manager_pkg.cli import *  # noqa: E402, F401, F403
from manager_pkg.config import *  # noqa: E402, F401, F403
from manager_pkg.deploy import *  # noqa: E402, F401, F403
from manager_pkg.fixer import *  # noqa: E402, F401, F403
from manager_pkg.registry import *  # noqa: E402, F401, F403
from manager_pkg.remotes import *  # noqa: E402, F401, F403
from manager_pkg.reporting import *  # noqa: E402, F401, F403
from manager_pkg.storage import *  # noqa: E402, F401, F403
from manager_pkg.tui import *  # noqa: E402, F401, F403

REGISTRY = _HERE

if __name__ == "__main__":
    raise SystemExit(main())
